//
// php_simple_serial.cpp 
//

#pragma once
#include "zend_config.w32.h"
#include "php.h"
#include "stdafx.h"

BOOL m_bEcho;
BOOL m_bNewLine;
HANDLE hCom;
int Port_Open=0;


PHP_FUNCTION(OpenSS);
PHP_FUNCTION(CloseSS);
PHP_FUNCTION(WriteSS);
PHP_FUNCTION(ReadSS);
PHP_FUNCTION(IsOpenSS);

zend_function_entry php_simple_serial_functions[] =
{
	PHP_FE(OpenSS, NULL)
	PHP_FE(CloseSS, NULL)
	PHP_FE(WriteSS, NULL)
	PHP_FE(ReadSS, NULL)
	PHP_FE(IsOpenSS, NULL)
	{NULL, NULL, NULL}
};


zend_module_entry php_simple_serial_module_entry =
{
    STANDARD_MODULE_HEADER,
    "php_simple_serial",
    php_simple_serial_functions,
    NULL, NULL, NULL, NULL, NULL,
    "estensione comunicazione seriale",
    STANDARD_MODULE_PROPERTIES

};
 
ZEND_GET_MODULE(php_simple_serial);

/*------------------
   APERTURA PORTA
 ------------------*/

PHP_FUNCTION(OpenSS)
{
char *Port;
int Port_len;
int StopBits=1, DataBits=8,Parity=0;
unsigned long Baud=115200;
COMMTIMEOUTS TimeOuts;
DCB Dcb;

if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s|l|l|l|l", &Port, &Port_len, &Baud, &DataBits, &StopBits, &Parity) == FAILURE)
		RETURN_STRING("e-95",1);

	hCom =CreateFile(Port, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING,NULL,NULL);
    if(hCom==INVALID_HANDLE_VALUE)
		RETURN_STRING("e-99",1);

    SetupComm(hCom,4096,4096);
    
	/* ---------------------------------------------------------------------------------------------------------
		A ReadIntervalTimeout value of MAXDWORD, combined with zero values for both the ReadTotalTimeoutConstant 
       and ReadTotalTimeoutMultiplier members, specifies that the read operation is to return immediately with 
       the bytes that have already been received, even if no bytes have been received.
	------------------------------------------------------------------------------------------------------------*/
	
	TimeOuts.ReadIntervalTimeout=MAXDWORD; 
	TimeOuts.ReadTotalTimeoutMultiplier=0; 
	TimeOuts.ReadTotalTimeoutConstant=100; /*  <--tarare questo valore sui cicli di risposta lunghi se si perdono dati per strada*/
	TimeOuts.WriteTotalTimeoutMultiplier=0;
	TimeOuts.WriteTotalTimeoutConstant=50;
    SetCommTimeouts(hCom, &TimeOuts);
    if(!GetCommState(hCom, &Dcb))
		RETURN_STRING("e-98",1);

	Dcb.fBinary=TRUE;
	Dcb.BaudRate = Baud; 
	switch (StopBits) 
	{
		case 1:
		  Dcb.StopBits  = ONESTOPBIT;
		  break;
		case 2:
		  Dcb.StopBits  = TWOSTOPBITS;
		  break;
		default: 
		  Dcb.StopBits  = ONESTOPBIT;
		  break;
	}
	Dcb.ByteSize = DataBits; 
    Dcb.Parity = Parity;                
    if(!SetCommState(hCom, &Dcb))
		RETURN_STRING("e-97",1);

   SetCommMask(hCom, EV_RXCHAR);
   Port_Open=1;
   RETURN_STRING("0",1);
} 

/* -----------------------------------------------------------------------------------------------

----------------
 RX DALLA PORTA 
---------------*/

PHP_FUNCTION(ReadSS)
{
	char buffer_in[14];
	int buffer_in_len;

if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &buffer_in, &buffer_in_len) == FAILURE)
	{
		RETURN_STRING("e-95",1);
    }

DWORD wCount=0;	
int counter = 0;
unsigned char c;
while(1)
	{ 
	   ReadFile(hCom,&c, 1, &wCount, NULL);
	   //ReadFile(hSerial, &c, 1, &dwBytesRead, NULL);
	   if(c != '\n') // il carattere non e' una newline ? aggiungiamolo
	   {
	     buffer_in[counter++] = c;
	   }
	   else
	   {
		 // il carattere e' una newline. Terminiamo la stringa e usciamo
	     buffer_in[counter] = '\0';
	     break;
	   }
	}

if(counter == 0)
{
	PurgeComm(hCom, PURGE_TXABORT| PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
	RETURN_STRING("a-99",1);
}

RETURN_STRING(buffer_in,1);

} 

/* -----------------------------------------------------------------------------------------------

 ---------------
  TX ALLA PORTA
 --------------*/

PHP_FUNCTION(WriteSS)
{
	char *buffer_out;
	unsigned long buffer_out_len;
	BOOL fState;
	//DWORD length=buffer_out_len;
	COMSTAT ComStat;
	DWORD dwErrorFlags;
	
if(zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &buffer_out, &buffer_out_len) == FAILURE)
		RETURN_STRING("e-95",1);
    
    ClearCommError(hCom,&dwErrorFlags,&ComStat);
    PurgeComm(hCom,PURGE_TXCLEAR);
    PurgeComm(hCom,PURGE_RXCLEAR);
	fState=WriteFile(hCom,buffer_out,buffer_out_len,&buffer_out_len,NULL);
    if(!fState)
	{
		RETURN_STRING("a-99",1);
	}
   	RETURN_STRING("0",1);
} 

/*-----------------------------------------------------------------------------------------------
----------------
 CHIUSURA PORTA
----------------*/

PHP_FUNCTION(CloseSS)
{
CloseHandle(hCom);
Port_Open=0;
switch (GetLastError())
     {
         case 0:
           	RETURN_STRING("0",1);
            break;
         case 6:
            RETURN_STRING("a-6",1);
            break;
         default:
            RETURN_STRING("a-99",1);
      }
} 


/* -----------------------------------------------------------------------------------------------

------------------------
 CHECK PER PORTA APERTA
------------------------*/

ZEND_FUNCTION(IsOpenSS)
{

if (Port_Open == 1)
 	{
		RETURN_STRING("1",1);	
	}
	else
     {   
         RETURN_STRING("0",1);
     }

} 
