<?php
	session_start();
	include("dati/status_services.php");
	include("dati/data_for_external_session.php");
	include("dati/data_for_external_watch.php");
	
	function last_elapsed_pin_in_survey($last_elapsed,$pos)
	{
		include("dati/data_for_external_watch.php");
		return ($last_elapsed=='l') ? $_SESSION['survey']['last'][$pos]: $_SESSION['survey']['elapsed'][$pos];
	}
	
	function check_pin_in_survey($item)
	{
		// aggiorniamo dal file remoto data_for_external_schedule.txt
		include("dati/data_for_external_watch.php");
		$ret_string="<b>*".$_SESSION["survey"]["name"][$item]."</b>&nbsp;&nbsp;<b>Stato corrente : </b>";
		$ret_string.=($_SESSION["survey"]["flag_action"][$item] == 0)? "Not Running<br>":"Running<br>";
		$ret_string.="<b>Comando : </b>".$_SESSION["survey"]["command"][$item]."<br>".
		"<b>Comando Human Read : </b>".$_SESSION["survey"]["human"][$item]."<br>".
		"<b>Tempo di sampling : </b>".$_SESSION["survey"]["elapse"][$item]." sec.".
		"<b>&nbsp;&nbsp;&nbsp;&nbsp;Pin di controllo Arduino : </b>".$_SESSION["survey"]["control_d_a"][$item].$_SESSION["survey"]["control_pin"][$item]."<br>".
		"<b>Operatore : </b>".$_SESSION["survey"]["control_operator"][$item] ."<b>   Valore di controllo : </b>".$_SESSION["survey"]["control_value"][$item]."<br>".
		"<b>Azione-></b>  <b>Pin</b> : ".$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item]."<b>   Set : </b> ".$_SESSION["survey"]["action_set_pin"][$item]."<b>   Value : </b>";
		if ($_SESSION["survey"]["action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["action_value"][$item];
		else
		$ret_string.=($_SESSION["survey"]["action_value"][$item] == 0) ? "LOW" : "HIGH";
		
		
		$ret_string.="<b>&nbsp;&nbsp;ReAz.-></b>  <b>Pin</b> : ".$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item]."<b>   Set : </b> ".$_SESSION["survey"]["re_action_set_pin"][$item]."<b>   Value : </b> ";
		if ($_SESSION["survey"]["re_action_value"][$item] > 1)  
			$ret_string.=$_SESSION["survey"]["re_action_value"][$item];
		else
			$ret_string.=($_SESSION["survey"]["re_action_value"][$item] == 0) ? "LOW<br>" : "HIGH<br>";

		return $ret_string;
	}
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - STATUS WATCHDOG 10 SEC.</title>
		<style>
			#containment-wrapper { width: 99%;z-index:0;}
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script>
			$(document).ready(function(){
				<?php if ($_SESSION['watch_running']!=false)
				{
				echo '$(function()
					{
				   var seconds = '.$_SESSION['refresh_watch'].';
				   setTimeout(updateCountdown_watch, 1000);

				   function updateCountdown_watch() {
					  seconds--;
					  if (seconds > 0) {
						 $("#countdown").text( seconds + " seconds to refresh");
						 setTimeout(updateCountdown_watch, 1000);
					  } 
					  else 
						window.location.reload();
				   }
				});';
				};?>
			});
		</script>
	</head>
	<body>
		<div id="main">
		<span id="remaining" style="display:block;text-align:left;">Remaining :<span id="countdown"></span>
		</div>
		<div id="containment-wrapper">
			<table cellpadding="0" cellspacing="3" width="99%">
				<tr>
					<td valign="top">
						<?php
							echo "Stato survey : ";
							echo ($_SESSION['watch_running']) ? "Running<br>" : "Not Running.<font color='red'>Nothing to watch here!</font><br>";
						?>
					</td>
					<td align="center">
						<input type="button" value="Close" onclick="window.close();"><input type="button" value="Reload" onclick="window.location.reload();">
					</td>
				</tr>
			</table>
			<table cellpadding="0" cellspacing="3" width="99%">
				<?php
					if ($_SESSION['watch_running'])
					{
						for ($z=0;$z<11;$z++)
						{
							if ($_SESSION['survey']['name'][$z]!='')
							{
								if (fmod($z,2)==0)
									echo '<tr bgcolor="#f2f2f2">';
								else
									echo '<tr bgcolor="#d2d2d2">';
								
								$value_watch=check_pin_in_survey($z);

								echo '<td>'.$value_watch."</td>";
								echo "<td>Watch : ".$_SESSION['survey']['control_operator'][$z].$_SESSION['survey']['control_value'][$z]."   Valore : ";
								echo ($_SESSION['survey']['control_d_a'][$z]=="d") ? 
								$_SESSION['val_digital_pin']['valore'][ $_SESSION['survey']['control_pin'][$z]].'<br>Last : '.str_ireplace("<br>"," - ",$_SESSION['val_digital_pin']['last'][$_SESSION['survey']['control_pin'][$z]]) :
								$_SESSION['val_analog_pin']['valore'][$_SESSION['survey']['control_pin'][$z]].'<br>Last : '.str_ireplace("<br>"," - ",$_SESSION['val_analog_pin']['last'][$_SESSION['survey']['control_pin'][$z]]) ;
								echo "</td><td>";
								echo ($_SESSION['survey']['flag_action'][$z]==1) ? '<img id="light_d'.$z.'" src="img/lightbulb_on.png">' : '<img id="light_d'.$z.'" src="img/lightbulb_off.png">';
								echo "</td></tr>";
							}
						}
					}
					else
					echo "Il WATCH e' fermo.Nessun dato!";
				?>		
			</table>
		</div>
	</body>
</html>										