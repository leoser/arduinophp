<?php
	session_start();
	if ($_SESSION['survey']['command'][0]=='')
	{
		echo $_SESSION['lang_no_watch_present'];
		die();
	}
	//$operators=array("<",">","=");
	if (!$_SESSION['watch_running'])
		$_SESSION['watch_running']=true;
		
	include("dati/timezone_".$_SESSION['lang'].".php");
	include_once("include_send.php");
	$r=(int)time();
	$risposta="";
	$from_survey=true;
	for ($arr_len=0;$arr_len < 11; $arr_len++)
	{
		## CONTROLLIAMO CHE I PIN CONTROL E ACTION NON SIANO DISABILITATI
		if (($_SESSION['survey']['control_d_a'][$arr_len]=='a') && ($_SESSION['val_analog_pin']['stato'][$_SESSION['survey']['control_pin'][$arr_len]]==-1))
		{
				$risposta.="<br>". $data_tempo[1]." ".$_SESSION['lang_control_label']." ".($arr_len+1) ." ".$_SESSION['lang_not_done'].".".
				$_SESSION['lang_survey_control_pin']." ".$_SESSION['survey']['control_pin'][$arr_len]." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!&&";
				break;
		}
		if (($_SESSION['survey']['action_d_a'][$arr_len]=='a') && ($_SESSION['val_analog_pin']['stato'][$_SESSION['survey']['control_pin'][$arr_len]]==-1))
		{
				$risposta.="<br>". $data_tempo[1]." ".$_SESSION['lang_control_label']." ".($arr_len+1)." ".$_SESSION['lang_done_no_alarm'].".<br>".
				$_SESSION['lang_survey_action_pin']." ".$_SESSION['survey']['action_pin'][$arr_len]." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!".$_SESSION['lang_value_get_the_same'].".";
		}
		if (($_SESSION['survey']['control_d_a'][$arr_len]=='d') && ($_SESSION['val_digital_pin']['stato'][$_SESSION['survey']['action_pin'][$arr_len]]==-1))
		{
				$risposta.="<br>". $data_tempo[1]." ".$_SESSION['lang_control_label']." ".($arr_len+1) ." ".$_SESSION['lang_not_done'].".".
				$_SESSION['lang_survey_control_pin']." ".$_SESSION['survey']['control_pin'][$arr_len]." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!&&";
				break;
		}
		if (($_SESSION['survey']['action_d_a'][$arr_len]=='d') && ($_SESSION['val_digital_pin']['stato'][$_SESSION['survey']['action_pin'][$arr_len]]==-1))
		{
				$risposta.="<br>". $data_tempo[1]." ".$_SESSION['lang_control_label']." ".($arr_len+1) ." ".$_SESSION['lang_done_no_alarm'].".<br>".
				$_SESSION['lang_survey_action_pin']." ".$_SESSION['survey']['action_pin'][$arr_len]." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!".$_SESSION['lang_value_get_the_same'].".";
		}
		if ($_SESSION['survey']['command'][$arr_len]!='')
		{
			if (($r - $_SESSION['survey']['last'][$arr_len]) > $_SESSION['survey']['elapse'][$arr_len])
			{
				#######################################################
				#### check se e' un controllo con control pwm 
				####  se si non si manda niente ad arduino e si va a prendere il valore in array digitali
				####  simuliamo la read e prepariamo il pacchetto di risposta
				#######################################################
				if ($_SESSION['survey']['control_d_a'][$arr_len]=='p')
				{
					$_SESSION['val_digital_pin']['current_type'][$_SESSION['survey']['control_pin'][$arr_len]]="p";
					$orario=date('d-m-y')."<br>".date('h:i:s');
					$readval=$_SESSION['val_digital_pin']['valore'][$_SESSION['survey']['control_pin'][$arr_len]]."%".$orario."
					%".$_SESSION['lang_survey_pwm_note'].":".$_SESSION['val_digital_pin']['valore'][$arr_len];
				}
				else
				{
					#-----------------------------------------------------------------------------------
					#  IMPORTANTISSIMO
					#  PER FARE LA READ DI UN ANALOGICO IMPOSTARE  postfix a 0    PER IL DIGITALE postfix=1
					#-----------------------------------------------------------------------------------
					
					$postfix=($_SESSION['survey']['control_d_a'][$arr_len] =="a") ? 0 : 1;
					
					####################  COSTRUZIONE PACCHETTO   #########################
					$packet=$_SESSION['survey']['control_d_a'][$arr_len].
							$_SESSION['survey']['control_pin'][$arr_len]."#".$postfix;
					#################################################################
					$readval=send_value($packet);
				}
				$read_val_array=explode("%",$readval);
				// $readval ARRIVA DA SEND_VALUE nel formato %valore$data<br>ora%stringa pannello messaggio arduino
				/* in read_val_Array[0] c'e il valore
				/* in read_val_Array[1] c'e la data e ora divisi da <br> */
				/* in read_val_Array[2] c'e la stringa per msg_panel */
				$data_tempo=explode("<br>",$read_val_array[1]);
				$_SESSION['survey']['last'][$arr_len]=$r;
				$control=
				$_SESSION['survey']['control_d_a'][$arr_len].
				$_SESSION['survey']['control_pin'][$arr_len].
				$_SESSION['survey']['control_operator'][$arr_len].
				$_SESSION['survey']['control_value'][$arr_len];
				$pin_to_print =	$_SESSION['survey']['control_d_a'][$arr_len].			
				$_SESSION['survey']['control_pin'][$arr_len];
				
				## qui dobbimano fare la comparazione dei valori secondo l'operatore
				switch ($_SESSION['survey']['control_operator'][$arr_len])
				{
				case ">":
					$check_cond=(int)$read_val_array[0] > (int)$_SESSION['survey']['control_value'][$arr_len];
				break;
				
				case "<":
					$check_cond=(int)$read_val_array[0] < (int)$_SESSION['survey']['control_value'][$arr_len];
				break;
				
				case "=":
					$check_cond=(int)$read_val_array[0] == (int)$_SESSION['survey']['control_value'][$arr_len];
				break;
				
				default:
					$check_cond=(int)$read_val_array[0] > (int)$_SESSION['survey']['control_value'][$arr_len];
				break;
				}

				if ($check_cond)
				{
					if ($_SESSION['val_digital_pin']['stato'][$_SESSION['survey']['action_pin'][$arr_len]]!=-1)
					{
						## VALORE OLTRE IL SURVEY
						## PREPARIAMO MESSAGIO E AZIONE PER IMPOSTARE IL VALORE DEL PIN ACTION
						
						$risposta.="<br>".$data_tempo[1]." - WARNING! <br>".
						$_SESSION['lang_control_label']." ".($arr_len+1).") ".$control."<br>".
						$_SESSION['lang_pin_sampled']." ".$pin_to_print." :".$read_val_array[0]."  Watch :".$_SESSION['survey']['control_value'][$arr_len]."#".$_SESSION['survey']['control_d_a'][$arr_len].$_SESSION['survey']['control_pin'][$arr_len]."#".$_SESSION['survey']['action_d_a'][$arr_len].$_SESSION['survey']['action_pin'][$arr_len]."#".$_SESSION['survey']['action_value'][$arr_len]."#".$read_val_array[0]."#".$read_val_array[1]."%".$read_val_array[2]."&&";
						
						## PREPARIAMO L'AZIONE
						$tipo_pin=($_SESSION['survey']['action_d_a'][$arr_len]=='p') ? "d" : $_SESSION['survey']['action_d_a'][$arr_len]; 
						$opt= $tipo_pin. 
						$_SESSION['survey']['action_pin'][$arr_len]."#".
						$_SESSION['survey']['action_set_pin'][$arr_len].
						$_SESSION['survey']['action_value'][$arr_len];
						send_value($opt);
						$_SESSION['survey']['flag_action'][$arr_len]="1";
						
						## CONTROLLIAMO SE IL SURVEY E' IMPOSTATO PER UNO SCHEDULE.
						##  CI SONO 2 CAMPI IN SCHEDULE  : WATCH_START E WATCH STOP
						## SE IL WATCH, NELLA CONDIZIONE "VERO" , CIOE' IN QUESTO PEZZO DI CODICE,
						## SODDISFA IL WATCH START O STOP ALLORA
						# 1) SE START E IL DEMONE SCHEDULE E' FERMO, LO DEVE FARE PARTIRE E ATTIVARE LO SCHEDULE REFERENZIATO
						# 2) SE STOP E IL DEMONE SCHEDULE E' FERMO NESSUN PROBLEMA.
						# 3) SE START O STOP E IL DEMONE SCHEDULE E' RUNNING AVVIA O FERMA LO SCHEDULE REFERENZIATO
						//for ($x=count($_SESSION['schedule']['name']);$x<20;$x++)
						//{
						//	if ($_SESSION['schedule']['name'][$x]='')
						//		break;
						//	if ($_SESSION['schedule']['enable'][$x]!='s')
						//		continue;
							##  1 per partenza   0 per stop   -  1 finale per start demone
						//	if ($_SESSION['schedule']['watch_start'][$x]=$arr_len)
						//	{
								#stringa per start
						//		$risposta.=($_SESSION['schedule_running']==true) ? "@SCHEDULE@".$x."@1@" : "@SCHEDULE@".$x."@1@1";
						//	}
						//	else if ($_SESSION['schedule']['watch_stop'][$x]=$arr_len)
						//	{
								#stringa per fermare
						//		$risposta.=($_SESSION['schedule_running']==true) ? "@SCHEDULE@".$x."@0@" : "@SCHEDULE@".$x."@1@1";
						//	}
						//}
					}
					else
					{
						$risposta.="<br>".$data_tempo[1]." - <font color='red'><b>WARNING</b></font>! <br>".
						$_SESSION['lang_control_label'] ." ".($arr_len+1).") ".$control."<br>".
						$_SESSION['lang_pin_sampled'].":".$pin_to_print." ".$_SESSION['lang_the value']." ".$read_val_array[0]."  Watch :".$_SESSION['survey']['control_value'][$arr_len]."#".$_SESSION['survey']['control_d_a'][$arr_len].$_SESSION['survey']['control_pin'][$arr_len]."#".$read_val_array[0]."#".$read_val_array[1]."%".$read_val_array[2]."&&";
					}
				}
				else
				{
					## VALORE A POSTO
					## FACCIAMO UN CHECK SE IL FLAG_ACTION E' A 1 E LO METTIAMO A 0
					## PREPARIAMO L'AZIONE PER REIMPOSTARE IL VALORE DEL PIN ACTION

					if ($_SESSION['survey']['flag_action'][$arr_len] == "1" )
					{
						#if ($_SESSION['survey']['control_d_a'][$arr_len]!='p')
						#{
							$tipo_pin=($_SESSION['survey']['action_d_a'][$arr_len]=='p') ? "d" : $_SESSION['survey']['action_d_a'][$arr_len]; 
							$opt= $tipo_pin. 
							$_SESSION['survey']['action_pin'][$arr_len]."#".
							$_SESSION['survey']['re_action_set_pin'][$arr_len].
							$_SESSION['survey']['re_action_value'][$arr_len];

							send_value($opt);
						#}
						$_SESSION['survey']['flag_action'][$arr_len]="0";
					}	
					$risposta.="<br>".$data_tempo[1]." ".$_SESSION['lang_control_label'] ." ".($arr_len+1)." ".$_SESSION['read_value'] .":".$read_val_array[0].".".$_SESSION['lang_no_action']."!"."#".$_SESSION['survey']['control_d_a'][$arr_len].$_SESSION['survey']['control_pin'][$arr_len]."#".$_SESSION['survey']['action_d_a'][$arr_len].$_SESSION['survey']['action_pin'][$arr_len]."#".$_SESSION['survey']['re_action_value'][$arr_len]."#".$read_val_array[0]."#".$read_val_array[1]."%".$read_val_array[2]."&&";
				}
			}
			else
			{
				$risposta.="<br>". date('h:i:s')." ".$_SESSION['lang_control_label'] ." ".($arr_len+1)." ".$_SESSION['lang_not_yet_expired'].".".$_SESSION['lang_no_action']."!&&";
			}
		}
	}
	if ($_POST['log'] == "s")
	{
	//$_SESSION['logfile']="dati/log.txt";
	//$_SESSION['logfile_open_mode']="a+";
	if (!$_SESSION['log_open'])
		$_SESSION['log_file'] = fopen($_SESSION['logfile'], $_SESSION['logfile_open_mode']);
		$risposta_log=str_ireplace("<br>"," ",$risposta);
		$risposta_log=str_ireplace("&&","",$risposta_log);
		fwrite($_SESSION['log_file'], "SURVEY  ** ".$risposta_log."\n");
	}
	echo $risposta;
?>			