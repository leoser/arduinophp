<?php
for ($x=0; $x<14; $x++)
{
	echo '
	$(function() {
		$( "#slider_tipo_d'.$x.'" ).slider({
			
			';
			if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
			echo "value:0,max: 1,min: 0,";
			else
			echo "value:0,max: 0,min: 0,";
			echo '
			stop: function( event, ui ) {
				$( "#tipo_d'.$x.'" ).val(  ui.value );
				switch (ui.value)
				{
					case 99:
					/* analog.nascondiamo SEND  H L N e PWM */
					if (document.getElementById("block_analog_d'.$x.'").style.display=="none")
					{
						document.getElementById("block_analog_d'.$x.'").style.display="block";
						$( "#slider_hilo_d'.$x.'" ).hide();
						document.getElementById("block_send_d'.$x.'").style.display="none";';
						
						if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
						{
							echo '
							$( "#slider_pwm_d'.$x.'" ).hide()
							document.getElementById("block_pwm_d'.$x.'").style.display="none";';
						}
						echo '
					}
					break;
					
					case 1:
					/* pwm.nascondiamo SEND  ANALOG H L N e visializziamo  lo slider pwm se il pin e anche pwm */
					';
					if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
					{
						echo '
						if (document.getElementById("block_pwm_d'.$x.'").style.display=="none")
						{
							$( "#stato_d'.$x.'" ).val(  ui.value );
							$( "#slider_hilo_d'.$x.'" ).hide();
							$( "#value_normal_d'.$x.'" ).hide();
							document.getElementById("block_send_d'.$x.'").style.display="none";
							$( "#slider_pwm_d'.$x.'" ).show();
							document.getElementById("block_pwm_d'.$x.'").style.display="block";
							/* document.getElementById("block_analog_d'.$x.'").style.display="none";*/
							/* INVIO AJAX PER CAMBIO IN ARRAY */
							$.ajax({
								type: "POST",
								url: "update_array.php",
								data: "data=d;'.$x.';"+ui.value+"&mode=t",
								async: false,
								success: function(msg){
								},
								error: function(msg){
								}
							})
						};';
					}
					echo '
					break;
					
					case 0:
					if (document.getElementById("block_send_d'.$x.'").style.display=="none")
					{
						
						/* document.getElementById("block_analog_d'.$x.'").style.display="none";*/
						document.getElementById("block_send_d'.$x.'").style.display="block";
						$( "#value_normal_d'.$x.'" ).show();
						$( "#slider_hilo_d'.$x.'" ).show();';
						
						if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
						{
						echo '
							$( "#slider_pwm_d'.$x.'" ).hide();
							document.getElementById("block_pwm_d'.$x.'").style.display="none";
									
							/* INVIO AJAX PER CAMBIO IN ARRAY */
							$.ajax({
								type: "POST",
								url: "update_array.php",
								data: "data=d;'.$x.';"+ui.value+"&mode=t",
								async: false,
								success: function(msg){
									
								},
								error: function(msg){
									
								}
							});';
						}
						echo '}
						break;
						default:
					}
				}
			});
			/* cambiando a ui 1.9 ho dovuto disabilitare questo. */
			/*$( "#tipo_d'.$x.'" ).val( $( "#slider_tipo_d'.$x.'0" ).slider( "value" ) );*/
		});
		
		$(function() {
			$( "#slider_stato_d'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 1,
				stop: function( event, ui ) {
					
							$( "#stato_d'.$x.'" ).val(  ui.value );
							if (document.getElementById("stato_d'.$x.'" ).value == "0")
							{
								$("#d'.$x.'").find("*").prop("disabled", false);
								$("#slider_hilo_d'.$x.'").slider( "option", "disabled", false );
								$("#slider_tipo_d'.$x.'" ).slider( "option", "disabled", false );
								$("#red_d'.$x.'").attr("src","img/green.png");
								$("#name_pin_d'.$x.'").attr("color","green");';
								
								if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
								{
									echo '$( "#slider_pwm_d'.$x.'" ).slider( "option", "disabled", false );';
								}
								echo '
							}
							else
							{
								$("#d'.$x.'").find("*").prop("disabled", true);
								$("#slider_hilo_d'.$x.'").slider( "option", "disabled", true );
								$("#slider_tipo_d'.$x.'" ).slider( "option", "disabled", true );
								$("#red_d'.$x.'").attr("src","img/red.png");';
								if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
								echo '$( "#slider_pwm_d'.$x.'" ).slider( "option", "disabled", true );';
								echo '
							}
						/* INVIO AJAX PER CAMBIO IN ARRAY */
						$.ajax({
						type: "POST",
						url: "update_array.php",
						data: "data=d;'.$x.';"+ui.value+"&mode=s",
						async: false,
						success: function(msg){
						},
						error: function(msg){
							
						}
					});
					$( "#stato_d'.$x.'" ).val( $( "#slider_stato_d'.$x.'" ).slider( "value" ) );
				}
			});
		});
		$(function() {
			$( "#slider_hilo_d'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 1,
				stop: function( event, ui ) {
					$( "#hilo_d'.$x.'" ).val( ui.value );
					if (document.getElementById("hilo_d'.$x.'" ).value < 2)
					send_value("d'.$x.'#1"+document.getElementById("hilo_d'.$x.'" ).value);
				}
			});
			$( "#hilo_d'.$x.'" ).val( $( "#slider_hilo_d'.$x.'" ).slider( "value" ) );
		});	
		';
		if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
		echo ' 
		$(function() {
			$( "#slider_pwm_d'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 255,
				orientation: "vertical",
				stop: function( event, ui ) {
					$( "#pwm_d'.$x.'" ).val( ui.value );
				},
				slide: function( event, ui ) {
					$( "#pwm_d'.$x.'" ).val(  ui.value );
					send_value("p'.$x.'#1"+document.getElementById("pwm_d'.$x.'" ).value);
				}
				
			});
			$( "#pwm_d'.$x.'" ).val( $( "#slider_pwm_d'.$x.'" ).slider( "value" ) );
			$( "#slider_pwm_d'.$x.'" ).hide();
		});	
		
		';
	}
	for ($x=0; $x<6; $x++)
	{
		echo '
		$(function() {
			$( "#slider_tipo_a'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 1,
				stop: function( event, ui ) {
					$( "#tipo_p_a'.$x.'" ).val(  ui.value );
					switch (ui.value)
					{
						case 0:
						/*  analogico; buona norma resettare prima il pin */
						/*  OCCHIO QUI CHE FORSE DA FARE */
						send_value("d'.($x+14).'#00");
						document.getElementById("hilo_a'.$x.'" ).value="";
						if (document.getElementById("block_map_a'.$x.'").style.display=="none")
						{
							document.getElementById("block_send_a'.$x.'").style.display="none";
							$( "#slider_hilo_a'.$x.'" ).hide();
							document.getElementById("label_a'.$x.'").style.display="block";
							document.getElementById("send_a'.$x.'").style.display="block";
							document.getElementById("buttons_map_con_a'.$x.'").style.display="block";
							
						}	
						break;
						
						case 1:
						/* DIGITAL .nascondiamo  ANALOG  e visializziamo  lo slider digital */
						if (document.getElementById("block_send_a'.$x.'").style.display=="none")
						{
							$( "#slider_hilo_a'.$x.'" ).show();
							document.getElementById("buttons_map_con_a'.$x.'").style.display="none";
							document.getElementById("block_send_a'.$x.'").style.display="block";
							document.getElementById("value_normal_a'.$x.'").style.display="block";
							document.getElementById("block_map_a'.$x.'").style.display="none";
							document.getElementById("block_con_a'.$x.'").style.display="none";
							document.getElementById("block_vref_a'.$x.'").style.display="none";
							document.getElementById("send_a'.$x.'").style.display="none";
							document.getElementById("label_a'.$x.'").style.display="none";
						}
						break;
						
						default:
						break;
					}
					/* INVIO AJAX PER CAMBIO IN ARRAY */
						$.ajax({
							type: "POST",
							url: "update_array.php",
							data: "data=a;'.$x.';"+ui.value+"&mode=t",
							async: false,
							success: function(msg){
							},
							error: function(msg){
								
							}
						});
				}
				
			});
			$( "#tipo_a'.$x.'" ).val( $( "#slider_tipo_a'.$x.'0" ).slider( "value" ) );
		});
		
		$(function() {
			$( "#slider_stato_a'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 1,
				stop: function( event, ui ) {
					$( "#tipo_p_a'.$x.'" ).val(  ui.value );
					/* INVIO AJAX PER CAMBIO IN ARRAY */
						$.ajax({
							type: "POST",
							url: "update_array.php",
							data: "data=a;'.$x.';"+ui.value+"&mode=s",
							async: false,
							success: function(msg){
							},
							error: function(msg){
								
							}
						});
					$( "#stato_a'.$x.'" ).val(  ui.value );
					if (document.getElementById("stato_a'.$x.'" ).value == "0")
					{
						$("#a'.$x.'").find("*").prop("disabled", false);
						$("#slider_tipo_a'.$x.'" ).slider( "option", "disabled", false );
						$("#red_a'.$x.'").attr("src","img/green.png");
					}
					else
					{
						$("#a'.$x.'").find("*").prop("disabled", true);
						$("#slider_tipo_a'.$x.'" ).slider( "option", "disabled", true );
						$("#red_a'.$x.'").attr("src","img/red.png");
					}
				}
			});
			$( "#stato_a'.$x.'" ).val( $( "#slider_stato_a'.$x.'" ).slider( "value" ) );
		});
		
		$(function() {
			$( "#slider_hilo_a'.$x.'" ).slider({
				value:0,
				min: 0,
				max: 1,
				stop: function( event, ui ) {
					$( "#hilo_a'.$x.'" ).val( ui.value );
					/*  qui vediamo di capire se � un vero analogico oppure un analogico camuffato da digitale */
					/*  lo possiamo sapere dal valore di "#tipo_p_a'.$x.'" (input nascosto) */
					if ($( "#tipo_p_a'.$x.'" ).val() ==1 )
					';
					$offset=14;
					echo '
					/* if (document.getElementById("hilo_a'.$x.'" ).value < 2) */
					send_value("d'.($x+$offset).'#1"+document.getElementById("hilo_a'.$x.'" ).value);
				}
			});
			$( "#hilo_a'.$x.'" ).val( $( "#slider_hilo_a'.$x.'" ).slider( "value" ) );
		});	
		';
	}
	
	echo '
	$(function() {
		$( "#slider_sampling_val" ).slider({
			value:10,
			min: 10,
			max: 120,
			step:5,
			slide: function( event, ui ) {
				$( "#sampling_val" ).val(  ui.value );
			}
		});
		$( "#sampling_val" ).val( $( "#slider_sampling_val" ).slider( "value" ) );
	});
	';