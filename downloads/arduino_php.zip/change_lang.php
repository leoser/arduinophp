<?php
	session_start();
	$retchange="";
	if (($_POST['lang'] != $_SESSION['lang']) || ($_POST['force']=='y'))
	{
		$_SESSION['lang']=$_POST['lang'];
		include("/lang/lang_".$_POST['lang'].".php");
		$retchange=file_get_contents("lang/lang_".$_POST['lang'].".php");
		
		$retchange=str_ireplace('";','',$retchange);
		$retchange=str_ireplace("\r\n",'@@@',$retchange);
		$retchange=str_ireplace("<?php",'',$retchange);
		$retchange=str_ireplace("?>",'',$retchange);
		$retchange=str_ireplace("\$_SESSION['","SESSION_",$retchange);
		$retchange=str_ireplace("']=",'|',$retchange);
		$retchange=str_ireplace('|"','|',$retchange);
	}
	echo $retchange;	
?>
								