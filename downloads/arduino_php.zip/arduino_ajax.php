<?php
	session_start();	
	include_once("include_send.php");

	if (!$_SESSION['start'])
	{
		
		##  ELENCHIAMO LE FUNZIONI.....POI SI TIRERA' VIA
		$functions = get_extension_funcs("php_simple_serial");
		$msg="<br>Funzioni disponibili nella estensione:<br>";
		foreach($functions as $func) 
		{
			$msg.= $func."<br>";
		}
		
		include_once("/dati/config.php");

		//for ($x=count($_SESSION['survey']['name']);$x<11;$x++)
		//{
		//	$_SESSION['survey']['name'][$x]='';
		//	$_SESSION['survey']['command'][$x]='';
		//	$_SESSION['survey']['control_d_a'][$x]='';
		//	$_SESSION['survey']['control_pin'][$x]='';
		//	$_SESSION['survey']['control_operator'][$x]='';
		//	$_SESSION['survey']['control_value'][$x]=0;
		//	$_SESSION['survey']['action_d_a'][$x]='';
		//	$_SESSION['survey']['action_pin'][$x]='';
		//	$_SESSION['survey']['action_set_pin'][$x]='';
		//	$_SESSION['survey']['action_value'][$x]='';
		//	$_SESSION['survey']['re_action_set_pin'][$x]='';
		//	$_SESSION['survey']['re_action_value'][$x]='';
		//	$_SESSION['survey']['flag_action'][$x]='0';
		//	$_SESSION['survey']['last'][$x]='00:00:00<br>00:00:00';
		//	$_SESSION['survey']['elapse'][$x]=10;
		//	$_SESSION['survey']['human'][$x]='';
		//	$_SESSION['survey']['enable'][$x]='s';
		//}
		
		//for ($x=count($_SESSION['schedule']['name']);$x<21;$x++)
		//{
		//	$_SESSION['schedule']['name'][$x]='';
		//	$_SESSION['schedule']['command_pin'][$x]='';
		//	$_SESSION['schedule']['date_start'][$x]='00:00:00';
		//	$_SESSION['schedule']['date_end'][$x]='00:00:00';
		//	$_SESSION['schedule']['time_start'][$x]='00:00';
		//	$_SESSION['schedule']['action_start'][$x]='';
		//	$_SESSION['schedule']['time_end'][$x]='00:00';
		//	$_SESSION['schedule']['action_end'][$x]='';
		//	$_SESSION['schedule']['days'][$x]='0';
		//	$_SESSION['schedule']['watch_start'][$x]=0;
		//	$_SESSION['schedule']['watch_stop'][$x]=0;
		//	$_SESSION['schedule']['flag_action'][$x]='0';
		//	$_SESSION['schedule']['date_time_started'][$x]=0;
		//	$_SESSION['schedule']['last'][$x]='00:00:00<br>00:00';
		//	$_SESSION['schedule']['elapsed'][$x]='00:00';
		//	$_SESSION['schedule']['enable'][$x]='s';
		//}
		
		$fp = fopen($_SESSION['com'], 'r');
		if(!$fp)
		{
			$msg_port="Problemi nell'apertura porta ".$_SESSION['com'].".Porta inesistente.";
			$msg_port_header=$msg_port;
			fclose($fp);
		}
		else
		{
			fclose($fp);
			$a=OpenSS($_SESSION['com'],$_SESSION['speed'],$_SESSION['bits'],$_SESSION['stop'],$_SESSION['parity']);
			switch ($a)
			{
				case '0':
				$_SESSION['start']="true";
				$msg_port="Porta ".$_SESSION['com']." aperta.";
				$msg_port_header=$msg_port;
				$msg_port.="<br>";
				## attendiamo che arduino vada in linea
				sleep(2);
				## check se e' connesso
				$a=WriteSS("*");
				$a=ReadSS("");
				if (strrpos($a, "**") != 0)
					$msg_port_header.= "Arduino non risponde!";
				else
					$msg_port_header.="Arduino READY.";
				include_once("testcom.php");
				break;
				
				case 'e-95':
				$msg_port="Parametri PORTA errati<br>";
				break;
				
				$msg_port="Porta ".$_SESSION['com']." aperta ma non ho trovato Arduino!";
				break;
				
				case 'e-99':
				$msg_port="Problemi nell'apertura porta ".$_SESSION['com'].".Porta inesistente o gia aperta.";
				$msg_port_header=$msg_port;
				break;
				
				default:
				break;
			}
		}
	}
	else
	{
		$fp = fopen($_SESSION['com'], 'r');
		/* con errore di apertura puo' significare che la porta e' gia aperta.facciamo un check di arduino ready*/
		if(!$fp)
		{
			# check arduino
			$a=WriteSS("*");
			$a=ReadSS("");
			if (strrpos($a, "**") != 0)
			{
				$msg_port="Problemi con la porta com.";
				$msg_port_header= $msg_port."Arduino non risponde!";
			}
			else
			{
				$msg_port="Porta ".$_SESSION['com']." aperta.";
				$msg_port_header=$msg_port."Arduino READY.";
			}
			
		}
		else
		{
			/* la porta e aperta dal file; quindi forse c'e un problema; dovremmo forzare la riapertura. */
			$msg_port="Porta ".$_SESSION['com']." aperta.";
			$msg_port_header.=$msg_port."Arduino READY.";
		}
		fclose($fp);
		$msg_port.="<br>";
	}
	//$watch_running=($_POST['watch_running']) ? $_POST['watch_running'] : 0;
	
	include("panel_ajax.php");
	
?>
