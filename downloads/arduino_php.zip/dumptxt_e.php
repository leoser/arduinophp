<?php
	session_start();
	include('dati/data_for_external_session.php');
?>
<html>
	<head>
		<meta http-equiv="refresh" content="<?php echo $_SESSION['refresh_dump_e'];?>" />
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - TABLE DUMP SESSION FOR EXTERNAL 240 SEC.</title>
		<style>
			body {margin-top:0; padding-top:0; font-family: times; font-size:11px; }
			td { font-family: times; font-size:11px; border:1px solid; vertical-align:top; }
			input, select, textarea {font-family: times ;font-size:  100%;}
			}
		</style>
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		
		<script>
			$(document).ready(function()
			{
				var seconds = <?php echo $_SESSION['refresh_dump'];?>;
			   setTimeout(updateCountdown_dump, 1000);

			   function updateCountdown_dump() {
				  seconds--;
				  if (seconds > 0) {
					 $("#countdown").text( seconds + " seconds to refresh");
					 setTimeout(updateCountdown_dump, 1000);
				  } 
				  else 
					window.location.reload();
			   }

			});
		</script>
	</head>
	<body>
		<input type="button" value="Close" onclick="window.close();"><input type="button" value="Reload" onclick="window.location.reload();">
		&nbsp;&nbsp;Remaining :<span id="countdown"></span>
		<p>&nbsp;</p>
		<div>
			<div style='float:left;padding-left:10px;'>
				SESSION[val_digital_pin]<br>
				<table border=1>
					<tr>
						<td align='right' bgcolor='azure'>
							Pin->
						</td>
						<?php 
							for ($x=0;$x<14;$x++) 
							{?>
							<td bgcolor='azure'>
								<?php echo $x;?>
							</td>
							<?php 
							} 
							foreach($_SESSION['val_digital_pin'] as $key => $element)
							{
							?>
							<tr>
								<td>
									<?php echo $key;?>
								</td>
								<?php 
									
									foreach($element as $subkey => $subelement)
									{
										
										if ($subelement != 0) 
										$bgcol="#d4d4d4";
										else
										$bgcol="#ffffff";
									?>
									<td bgcolor="<?php echo $bgcol;?>">
										<?php echo $subelement;?>
									</td>
								<?php } ?>
							</tr>
						<?php } ?>
					</table>
				</div>
				
				<div style='float:left;padding-left:10px;'>
					SESSION[val_analog_pin]<br>
					<table border=1>
						<tr>
							<td align='right' bgcolor='azure'>Pin-></td>
							<?php for ($x=0;$x<6;$x++) 
								{?>
								<td bgcolor='azure'><?php echo $x;?></td>
								<?php 
								} 
								foreach($_SESSION['val_analog_pin'] as $key => $element)
								{
								?>
								<tr>
									<td>
										<?php echo $key;?>
									</td>
									<?php 
										foreach($element as $subkey => $subelement)
										{if ($subelement != 0) 
											$bgcol="#d4d4d4";
											else
											$bgcol="#ffffff";
										?>
										<td bgcolor="<?php echo $bgcol;?>">
											<?php echo $subelement;?>
										</td>
									<?php } ?>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
				
				<div style='clear:both;'></div>
				
				<div style='float:left;padding-left:10px;'>
					SESSION[survey]<br>
					<table border=1>
						<tr>
							<td align='right' bgcolor='azure'>Survey-></td>
							<?php for ($x=0;$x<10;$x++) 
								{?>
								<td bgcolor='azure'>
									<?php echo ($x+1);?>
								</td>
								<?php } 
								
								foreach($_SESSION['survey'] as $key => $element)
								{
								?>
								<tr>
									<td>
										<?php echo $key;?>
									</td>
									<?php 
										foreach($element as $subkey => $subelement)
										{
											if ($subelement != 0) 
											$bgcol="#d4d4d4";
											else
											$bgcol="#ffffff";
										?>
										<td bgcolor="<?php echo $bgcol;?>">
											<?php echo $subelement;?>
										</td>
									<?php } ?>
								</tr>
							<?php } ?>
						</table>
					</div>
					
					<div style='clear:both;'></div>
					<br>
					<div style='float:left;padding-left:10px;'>
						SESSION[schedule]<br>
						<table border=1>
							<tr>
								<td align='right' bgcolor='azure'>Schedule-></td>
								<?php for ($x=0;$x<20;$x++) 
									{?>
									<td bgcolor='azure'>
										<?php echo ($x+1);?>
									</td>
									<?php } 
									
									foreach($_SESSION['schedule'] as $key => $element)
									{
									?>
									<tr>
										<td>
											<?php echo $key;?>
										</td>
										<?php 
											foreach($element as $subkey => $subelement)
											{
												if ($subelement != 0) 
												$bgcol="#d4d4d4";
												else
												$bgcol="#ffffff";
											?>
											<td bgcolor="<?php echo $bgcol;?>">
												<?php echo $subelement;?>
											</td>
										<?php } ?>
									</tr>
								<?php } ?>
							</table>
						</div>
						<div style='clear:both;'></div>
						<br>
					</body>
				</html>																																																			