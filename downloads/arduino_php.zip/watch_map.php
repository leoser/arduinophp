<?php
	session_start();
	
	###  prendiamo il file di configurazione e vediamo cosa c'e dentro
	$map_file_watch = fopen($_SESSION['mapfile_watch'], $_SESSION['mapfile_watch_open_mode']);
	$string_map = fread($map_file_watch,filesize($_SESSION['mapfile_watch']));
	fclose($map_file_watch);
	$string_map=explode("@@",$string_map);
	
	function check_pin_in_survey($pin)
	{
		$ret_string='Pin non attivo';
		for ($y=0;$y<11;$y++)
		{
			if ($pin == $_SESSION['survey']['control_d_a'][$y].$_SESSION['survey']['control_pin'][$y])
			{
				$ret_string=
				"<b>*".$_SESSION["survey"]["name"][$y]."</b><br>".
				"<b>Comando : </b>".$_SESSION["survey"]["command"][$y]."<br>".
				"<b>Comando Human Read : </b>".$_SESSION["survey"]["human"][$y]."<br>".
				"<b>Tempo di sampling : </b>".$_SESSION["survey"]["elapse"][$y]." sec.<br>".
				"<b>Pin di controllo Arduino : </b>".$_SESSION["survey"]["control_d_a"][$y].$_SESSION["survey"]["control_pin"][$y]."<br>".
				"<b>Operatore : </b>".$_SESSION["survey"]["control_operator"][$y] ."<b>   Valore di controllo : </b>".$_SESSION["survey"]["control_value"][$y]."<br>".
				
				
				"<div style='width:100%;'>
					<div style='float:left'>
					<b>Azione</b><br>
					<b>Pin : </b>".$_SESSION["survey"]["action_d_a"][$y].$_SESSION["survey"]["action_pin"][$y]."<b>   Set : </b> ".$_SESSION["survey"]["action_set_pin"][$y]."<b>   Value : </b>";
					if ($_SESSION["survey"]["action_value"][$y] > 1)  
					$ret_string.=$_SESSION["survey"]["action_value"][$y];
					else
					$ret_string.=($_SESSION["survey"]["action_value"][$y] == 0) ? "LOW" : "HIGH";
					$ret_string.="
					</div>
					<div style='float:right;'>
					<b>ReAzione</b><br>
					<b>Pin : </b>".$_SESSION["survey"]["action_d_a"][$y].$_SESSION["survey"]["action_pin"][$y]."<b>   Set : </b> ".$_SESSION["survey"]["re_action_set_pin"][$y]."<b>   Value : </b> ";
					if ($_SESSION["survey"]["re_action_value"][$y] > 1)  
						$ret_string.=$_SESSION["survey"]["re_action_value"][$y];
					else
						$ret_string.=($_SESSION["survey"]["re_action_value"][$y] == 0) ? "LOW" : "HIGH";
					$ret_string.="</div>
				</div>";
				#<div style='clear:both;'></div>";
				#$ret_string.="<b>Stato corrente : </b>";
				#$ret_string.=($_SESSION["survey"]["flag_action"][$y] == 0)? "Not Running":"Running";
				break;
			}
		}
		return $ret_string;
	}
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - MAPPA WATCHDOG</title>
		<style>
			
			#name_active_moved0, #name_active_moved1 , #name_active_moved2 , #name_active_moved3, #name_active_moved4, #name_active_moved5, #name_active_moved6, #name_active_moved7, #name_active_moved8, #name_active_moved9, #name_active_moved10, #name_active_moved11, #name_active_moved12, #name_active_moved13,#name_active_movea0, #name_active_movea1 , #name_active_movea2 , #name_active_movea3, #name_active_movea4, #name_active_movea5{
			z-index:0;
			width:103px;
			height:34px;
			background-color:pink;
			border:2px solid orange;
			padding: 2px; 
			-moz-opacity: 1.0; 
			opacity: 1.0;
			filter: alpha(opacity=100);
			position:absolute;
			}
			
			#name_inactive_moved0, #name_inactive_moved1 , #name_inactive_moved2 , #name_inactive_moved3, #name_inactive_moved4, #name_inactive_moved5, #name_inactive_moved6, #name_inactive_moved7, #name_inactive_moved8, #name_inactive_moved9, #name_inactive_moved10, #name_inactive_moved11, #name_inactive_moved12, #name_inactive_moved13, #name_inactive_movea0, #name_inactive_movea1 , #name_inactive_movea2 , #name_inactive_movea3, #name_inactive_movea4, #name_inactive_movea5{ 
			z-index:0;
			width:103px;
			height:34px;
			background-color:white;
			border:2px solid orange;
			padding: 2px; 
			-moz-opacity: 1.0; 
			opacity: 1.0;
			filter: alpha(opacity=100);
			color:blue;
			position:absolute;
			}
			
			#containment-wrapper { width: 95%; height:95%; z-index:0;}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		<link rel="stylesheet" href="css/jquery-ui.css">
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script>
			$(document).ready(function(){
				var startpos=0;
				$(function() {
					$( document ).tooltip();
				});
				
				<?php
					$base_image_lenght=950;
					$base_table_position=19;
					$offset_start_top=33;
					$width_element=103+9; // width da css + bordi e altro
					$type=array("d", "a");
					//  offset per il top valido per tutti
					$offset_element=43;
					//  offset per il left prima colonna (d)
					$offset_left_d=$base_image_lenght+$base_table_position;
					//  offset per il left seconda colonna (p)
					$offset_left_a=$base_image_lenght+$base_table_position+$width_element;
					
					for ($x=0; $x<2; $x++)
					{
						for ($z=0;$z<14;$z++)
						{
							if (($type[$x] == 'a') && ($z >5))
							break;
							$top=0;
							$left=0;
							for ($q=0;$q<count($string_map);$q++)
							{
								if ((strpos($string_map[$q],$type[$x].$z."#")) > -1)
								{
									$values=explode("#",$string_map[$q]);
									$top=$values[2];
									$left=$values[1];
									break;
								}
							}
							$value_sched=check_pin_in_survey($type[$x].$z);
							if ($value_sched !='Pin non attivo')
							echo '$( "#name_active_move'.$type[$x].$z.'" ).draggable({
							containment: "#containment-wrapper", scroll: false , opacity: 0.5,
							start: function(event, ui) {
							},
							stop: function(event, ui){
							},
							});	
							$("#name_active_move'.$type[$x].$z.'").dblclick(function() {
							$("#name_active_move'.$type[$x].$z.'").animate({
							top: '.($offset_start_top+($offset_element*$z)).',
							left: '.${"offset_left_".$type[$x]}.'
							}, 500, function() {
							});
							});
							';
							else
							echo '$( "#name_inactive_move'.$type[$x].$z.'" ).draggable({
							containment: "#containment-wrapper", scroll: false , opacity: 0.5,
							start: function(event, ui) {
							//var currentPos = $(this).position();
							//alert("left="+parseInt(currentPos.left)+" right"+parseInt(currentPos.top));
							},
							stop: function(event, ui){
							},
							});	
							$("#name_inactive_move'.$type[$x].$z.'").dblclick(function() {
							$("#name_inactive_move'.$type[$x].$z.'").animate({
							top: '.($offset_start_top+($offset_element*$z)).',
							left: '.${"offset_left_".$type[$x]}.'
							}, 500, function() {
							});
							});
							';
						}
					}
				?>	
				//$( "#draggable5" ).draggable({ containment: "parent" });
			});
		</script>
	</head>
	<body>
		<div id="containment-wrapper">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td align="left" valign="top" width="900">
						<img src="<?php echo $_SESSION['map_watch'];?>" style="z-index:0;"><br
					</td>
					<td align="center" valign="top" width="250">
							<font size=+1><b>Mappa Watchdog-PINS</b></font><br>
						<table cellpadding="0" cellspacing="3" width="226" bgcolor="#f2f2f2">
							<?php
								for ($z=0;$z<14;$z++)
								{
									echo '<tr style="height:40px;">';
									$value_sched=check_pin_in_survey("d".$z);
									echo '<input type="hidden" id="value_survey_d'.$z.'" value="'.$value_sched.'">';
									
									if ($value_sched !='Pin non attivo')
									{
										echo '
										<td width="103" valign="top">
										<div id="name_active_moved'.$z.'" class="ui-widget-content">
											<span style="font-size:12px;" id="value_survey_d'.$z.'" title="'.$value_sched.'">
												<img src="img/help0000.gif" style="position:relative;left:1px;top:-3px;">
											</span>
											<span style="font-size:12px;position:relative;left:10px;top:-4px;">pin D'.$z.'
											</span>
										<div style="position:relative;font-size:12px;text-align:center;">
										'.substr($value_sched,0,stripos($value_sched,"<br>",1)).'
										</div>
										</div>
										</td>';
									}
									else
									{
										echo '
										<td width="103" valign="top" style="border:1px black solid;">
										<div id="name_inactive_moved'.$z.'" class="ui-widget-content">
										<span style="font-size:12px;" id="value_survey_d'.$z.'" title="'.$value_sched.'">
										<img src="img/help0000.gif" style="position:relative;left:2px;top:3px;">
										</span>
										<div style="position:relative;font-size:12px;text-align:center;">
										D'.$z.'
										</div>
										</div>
										</td>';
									}
									
									if ($z <6)
									{
										$value_sched=check_pin_in_survey("a".$z);
										if ($value_sched !='Pin non attivo')
										{
											echo '
											<td width="103" valign="top">
											<div id="name_active_movea'.$z.'" class="ui-widget-content">
												<span style="font-size:12px;" id="value_survey_a'.$z.'" title="'.$value_sched.'">
													<img src="img/help0000.gif" style="position:relative;left:1px;top:-3px;">
												</span>
												<span style="font-size:12px;position:relative;left:10px;top:-4px;">pin A'.$z.'
												</span>
											<div style="position:relative;font-size:12px;text-align:center;">'
											.substr($value_sched,0,stripos($value_sched,"<br>",1)).'
											</div>
											</div>
											</td>';
										}
										else
										{
											echo '
											<td width="103" valign="top">
											<div id="name_inactive_movea'.$z.'" class="ui-widget-content">
											<span style="font-size:12px;" id="value_survey_a'.$z.'" title="'.$value_sched.'">
											<img src="img/help0000.gif" style="position:relative;left:2px;top:3px;">
											</span>
											<div style="position:relative;font-size:12px;text-align:center;">
											A'.$z.'
											</div>
											</div>
											</td>';
										}
									}
									else
									{
										echo '<td width="103" valign="top">&nbsp;</td>';
									}
									echo '</tr>';
								}	
							?>						
						</table>
						<br>
						<input type="button" value="Save" onclick="save_map();"><input type="button" value="Reset" onclick="reset_map();"><input type="button" value="Reload" onclick="window.location.reload();"><input type="button" value="Close" onclick="window.close();">
					</td>
				</tr>
			</table>
			
		</div>
		<script>
			<?php
				##  spostamento dei drag posizionati nella mappa
				for ($x=0; $x<2; $x++)
				{
					for ($z=0;$z<14;$z++)
					{
						for ($q=0;$q<count($string_map);$q++)
						{
							if ((strpos($string_map[$q],$type[$x].$z."#")) > -1)
							{
								$values=explode("#",$string_map[$q]);
								echo '
								if ($("#name_active_move'.$type[$x].$z.'").length > 0)
								{
								$("#name_active_move'.$type[$x].$z.'").animate({
								top: '.$values[2].',
								left: '.$values[1].'
								}, 500, function() {
								});
								}
								else
								{
								$("#name_inactive_move'.$type[$x].$z.'").animate({
								top: '.$values[2].',
								left: '.$values[1].'
								}, 500, function() {
								});
								}';
								echo "\n";
							}	
						}
					}
				}
			?>
		</script>
		<script>
			
			function  save_map()
			{
				var min_left_to_map_value=950;
				var current_map='';
				var type = new Array("d", "a");
				for (var z=0; z<2; z++)
				{
					for (var x=0; x<14; x++)
					{
						if ($("#name_active_move"+type[z]+x).length > 0) 
						{  
							var currentPos=$("#name_active_move"+type[z]+x).position()
							if (currentPos.left < min_left_to_map_value)
							{  
								current_map+= type[z]+x+"#"+parseInt(currentPos.left)+"#"+parseInt(currentPos.top)+"@@";
							}
							
						}
						if ($("#name_inactive_move"+type[z]+x).length > 0) 
						{  
							var currentPos=$("#name_inactive_move"+type[z]+x).position()
							if (currentPos.left < min_left_to_map_value)
							{  
								current_map+=type[z]+x+"#"+parseInt(currentPos.left)+"#"+parseInt(currentPos.top)+"@@";
							}
							
						}
					}
				}
				$.ajax({
					type: "POST",
					url: "update_array.php",
					data: "data="+current_map+"&mode=mapw",
					async: false,
					success: function(msg){
						alert("Mappa Salvata");
					},
					error: function(msg){
						alert("Problemi nel salvataggio");
					}
				});
			}
			
			function reset_map()
			{
				var current_map="";
				var type = new Array("d", "a");
				for (var z=0; z<1; z++)
				{
					for (var x=0; x<14; x++)
					{
						if ($("#move"+type[z]+x).length > 0) 
						$("#move"+type[z]+x).dblclick();
						
					}
				}
			}
		</script>
	</body>
</html>								