<?php
	session_start();	
	###########################################
	##  arriva con post:
	##  mode : cosa bisogna fare
	##  data  : stinga con tipo , numero pin , valore   delimitati da ;
	###########################################
	$string_data=explode(";",$_POST['data']);
	
	switch ($_POST['mode'])
	{
		case 'name':
		$valori_string_data=explode("@",$string_data[0]);
		$to_search=($valori_string_data[0] == "d") ? "val_digital_pin":"val_analog_pin";
		$_SESSION[$to_search]['name'][$valori_string_data[2]] = $valori_string_data[1];
		
		// mettiamo nel file config.php
		$file_content = file_get_contents($_SESSION['configfile']);
		$array_stack=explode("\n",$file_content);
		$indice=0;
		while ($indice <= count($array_stack) )
		{ 
			if (stripos($array_stack[$indice],$to_search)>-1)
			{
				$indice++;
				foreach($_SESSION[$to_search] as $key => $element)
				{
					$array_stack[$indice]="'".$key."'=>array(";
					foreach($element as $subkey => $subelement)
					{
						
					if (($key == 'stato') || ($key == 'valore'))
						$quote="";
					else
						$quote="'";
						
					$array_stack[$indice].=$quote.$subelement.$quote.",";
					} 
					$array_stack[$indice].="),";
					$indice++;
				}
			}
			$indice++;
		}	
		$file_content = implode("\n", $array_stack);
		file_put_contents($_SESSION['configfile'], $file_content); 
		echo "success";
		break;
		
		case 'mapd':
		$map_file_domo = fopen($_SESSION['mapfile_domo'], $_SESSION['mapfile_domo_open_mode_rw']);
		fwrite($map_file_domo, $string_data[0]);
		fclose($map_file_domo);
		echo "success";
		break;
		
		case 'mapw':
		$map_file_watch = fopen($_SESSION['mapfile_watch'], $_SESSION['mapfile_watch_open_mode_rw']);
		fwrite($map_file_watch, $string_data[0]);
		fclose($map_file_watch);
		echo "success";
		break;
	
		case 's':
		switch ($string_data[0])
		{
			case 'a':
			$_SESSION['val_analog_pin']['stato'][$string_data[1]]=~$_SESSION['val_analog_pin']['stato'][$string_data[1]];
			break;
			case 'd':
			$_SESSION['val_digital_pin']['stato'][$string_data[1]]=~$_SESSION['val_digital_pin']['stato'][$string_data[1]];		
			break;
		}
		echo "success";
		break;
		
		case 't':
		switch ($string_data[0])
		{
			case 'a':
			($_SESSION['val_analog_pin']['current_type'][$string_data[1]]=='a') ? $_SESSION['val_analog_pin']['current_type'][$string_data[1]]='d' : $_SESSION['val_analog_pin']['current_type'][$string_data[1]]='a';
			break;
			case 'd':
			($_SESSION['val_digital_pin']['current_type'][$string_data[1]]=='d') ? $_SESSION['val_digital_pin']['current_type'][$string_data[1]]='p' : $_SESSION['val_digital_pin']['current_type'][$string_data[1]]='d';
			break;
		}
		echo "success";
		break;
		
		case 'm':
		//save map
			$_SESSION['val_analog_pin']['map'][$string_data[1]] = $string_data[2] ;
			echo "success";
			break;
		
		case 'c':
		//save constrain
			$_SESSION['val_analog_pin']['constrain'][$string_data[1]] = $string_data[2] ;
			echo "success";
			break;
			
		case 'v':
		//save vref
			$_SESSION['val_analog_pin']['vref'][$string_data[1]] = $string_data[2] ;
			echo "success";
			break;
		
		default:
		echo "hummm";
		break;
	}
	
?>