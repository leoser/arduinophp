<?php
	session_start();
	####  BISOGNA TENERE CONTO CHE QUI MANCA LA TABELLA DEI PIN A LATO DELLA FIGURA
	####  I VALORI DI OFFSET PER POSIZIONARE I BOX DEVONO TENERE CONTO DELLO SPOSTAMENTO A DESTRA DELL'IMMAGINE
	####  E QUINDIBISOGNA AGGIUNGERE L'OFFSET DI TABELLA MANCANTE
	
	###  prendiamo il file di configurazione e vediamo cosa c'e dentro
	$map_file_watch = fopen($_SESSION['mapfile_watch'], $_SESSION['mapfile_watch_open_mode']);
	$string_map = fread($map_file_watch,filesize($_SESSION['mapfile_watch']));
	fclose($map_file_watch);
	$string_map=explode("@@",$string_map);
	
	function check_pin_in_survey($pin)
	{
		$ret_string='Pin non attivo';
		for ($y=0;$y<21;$y++)
		{
			if ($pin == $_SESSION['survey']['control_d_a'][$y].$_SESSION['survey']['control_pin'][$y])
			{
				$ret_string=$y."%%
				<b>*".$_SESSION["survey"]["name"][$y]."</b><br>".
				"<b>Comando : </b>".$_SESSION["survey"]["command"][$y]."<br>".
				"<b>Comando Human Read : </b>".$_SESSION["survey"]["human"][$y]."<br>".
				"<b>Tempo di sampling : </b>".$_SESSION["survey"]["elapse"][$y]." sec.<br>".
				"<b>Pin di controllo Arduino : </b>".$_SESSION["survey"]["control_d_a"][$y].$_SESSION["survey"]["control_pin"][$y]."<br>".
				"<b>Operatore : </b>".$_SESSION["survey"]["control_operator"][$y] ."<b>   Valore di controllo : </b>".$_SESSION["survey"]["control_value"][$y]."<br>".
				"<div>
				<div style='float:left'>
				<b>Azione</b><br>
				<b>Pin : </b>".$_SESSION["survey"]["action_d_a"][$y].$_SESSION["survey"]["action_pin"][$y]."<b>   Set : </b> ".$_SESSION["survey"]["action_set_pin"][$y]."<b>   Value : </b>";
				
				if ($_SESSION["survey"]["action_value"][$y] > 1)  
				$ret_string.=$_SESSION["survey"]["action_value"][$y];
				else
				$ret_string.=($_SESSION["survey"]["action_value"][$y] == 0) ? "LOW" : "HIGH";
				
				$ret_string.="
				</div>
				<div style='float:left;padding-left:20px;'>
				<b>ReAzione</b><br>
				<b>Pin : </b>".$_SESSION["survey"]["action_d_a"][$y].$_SESSION["survey"]["action_pin"][$y]."<b>   Set : </b> ".$_SESSION["survey"]["re_action_set_pin"][$y]."<b>   Value : </b> ";
				if ($_SESSION["survey"]["re_action_value"][$y] > 1)  
					$ret_string.=$_SESSION["survey"]["re_action_value"][$y];
				else
					$ret_string.=($_SESSION["survey"]["re_action_value"][$y] == 0) ? "LOW" : "HIGH";
				$ret_string.="</div></div>";
				$ret_string.="<b>Stato corrente : </b>";
				$ret_string.=($_SESSION["survey"]["flag_action"][$y] == 0)? "Not Running":"Running";
				break;
			}
		}
		return $ret_string;
	}
?>
<html>
	<head>
		<style>
			
			#name_active_moved0, #name_active_moved1 , #name_active_moved2 , #name_active_moved3, #name_active_moved4, #name_active_moved5, #name_active_moved6, #name_active_moved7, #name_active_moved8, #name_active_moved9, #name_active_moved10, #name_active_moved11, #name_active_moved12, #name_active_moved13,#name_active_movea0, #name_active_movea1 , #name_active_movea2 , #name_active_movea3, #name_active_movea4, #name_active_movea5{
			z-index:99;
			width:103px;
			height:34px;
			background-color:pink;
			border:2px solid orange;
			padding: 2px; 
			-moz-opacity: 1.0; 
			opacity: 1.0;
			filter: alpha(opacity=100);
			position:absolute;
			top:0px;
			}
			
			#containment-wrapper { width: 95%; height:95%; z-index:0;}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		<link rel="stylesheet" href="css/jquery-ui.css">
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script>
			$(document).ready(function(){
				$(function() {
					$( document ).tooltip();
				});
			});
		</script>
	</head>
	<body>
		<div id="main">
		</div>
		<div id="containment-wrapper">
			<table cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td align="left" valign="top" width="900">
						<img src="<?php echo $_SESSION['map_watch'];?>" style="z-index:0;">
					</td>
					<td align="center" valign="top" width="300" >
						<table cellpadding="0" cellspacing="3" width="100%" bgcolor="#f2f2f2">
							<tr height="600">
								<td valign="top">
									<?php
										echo "Stato survey : ";
										echo ($_SESSION['survey_running']) ? "Running<br>" : "Not Running<br>";
									?>
								</td>
							</tr>
							<tr>
								<td align="center">
									<input type="button" value="Close" onclick="window.close();"><input type="button" value="Stop survey" onclick="reset_map();"><input type="button" value="Reload" onclick="window.location.reload();">
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			
			<?php
				for ($z=0;$z<14;$z++)
				{
					$value_sched=check_pin_in_survey("d".$z);
					if (strpos($value_sched,"attivo")==false)
					{
						echo '<input type="hidden" id="value_survey_d'.$z.'" value="'.$value_sched.'">';
						echo '
						<div id="name_active_moved'.$z.'" class="ui-widget-content">
						<span id="info_d'.$z.'" title="'.
						substr($value_sched,stripos($value_sched,"%%")+2).
						'" >
						<img src="img/help0000.gif" style="position:relative;left:2px;top:0px;">
						</span>
						<span style="font-size:12px;">';
						echo ($_SESSION['survey']['flag_action'][substr($value_sched,0,strpos($value_sched,"%%"))] == 1) ? 
						'<img id="light_d'.$z.'" src="img/lightbulb_on.png">' :  
						'<img id="light_d'.$z.'" src="img/lightbulb_off.png">';
						echo '
						pin D'.$z.'
						</span>
						<div style="position:relative;font-size:12px;text-align:center;">
						'.substr($value_sched,stripos($value_sched,"%%")+2,stripos($value_sched,"<br>")-3).'
						</div>
						</div>';
					}
					//
					
					if ($z <6)
					{
						$value_sched=check_pin_in_survey("a".$z);
						if (strpos($value_sched,"attivo")==false)
						{
							echo '<input type="hidden" id="value_survey_a'.$z.'" value="'.$value_sched.'">';
							$array_pos_relative++;
							echo '
							<div id="name_active_movea'.$z.'" class="ui-widget-content">
							<span id="info_a'.$z.'" title="'.
							substr($value_sched,stripos($value_sched,"%%")+2).
							'" >
							<img src="img/help0000.gif" style="position:relative;left:2px;top:0px;">
							</span>
							<span style="font-size:12px;">';
							echo ($_SESSION['survey']['flag_action'][substr($value_sched,0,strpos($value_sched,"%%"))] == 1) ? 
							'<img id="light_a'.$z.'" src="img/lightbulb_on.png">' :  
							'<img id="light_a'.$z.'" src="img/lightbulb_off.png">';
							echo '
							pin A'.$z.'
							</span>
							<div style="position:relative;font-size:12px;text-align:center;">
							'.substr($value_sched,stripos($value_sched,"%%")+2,stripos($value_sched,"<br>")-3).'
							</div>
							</div>';
							$array_pos_relative++;
						
						}
					}
				}	
			?>					
		</div>
		<script>
			<?
				#if (!$_SESSION['domo_done'])
					#{
					$type=array("d", "a");
					$offset_top=0;
					$offset_left=0;
					
					for ($x=0; $x<2; $x++)
					{
						for ($z=0;$z<14;$z++)
						{
							for ($q=0;$q<count($string_map);$q++)
							{
								if ((strpos($string_map[$q],$type[$x].$z."#")) > -1)
								{
									$values=explode("#",$string_map[$q]);
									echo' $("#name_active_move'.$type[$x].$z.'").animate({
									top: '.$values[2].'+'.$offset_top.',
									left: '.$values[1].'+'.$offset_left.'
									}, 500, function() {
									});';
									echo "\n";
								}	
							}
						}
					}
					#$_SESSION['domo_done']=true;
					#}
				?>
			</script>
		</body>
	</html>									