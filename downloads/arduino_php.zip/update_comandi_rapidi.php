<?php
	session_start();	
	include("lang/lang_".$_SESSION['lang'].".php");
	$string_comando_rapido=explode(";",$_POST['comando_rapido']);
	switch ($_POST['mode'])
	{
		#case '0':
		#$_SESSION['schedule_running']=true;
		#$content=file_get_contents($_SESSION['status_services']);
		#if (strpos($content,"schedule_running']=false")>-1)
		#{
		#	$content=str_ireplace("['schedule_running']=false","['schedule_running']=true",$content);
		#	file_put_contents($_SESSION['status_services'], $content);
		#}
		#break;
		
		#case 's':
		#$reset_pins='';
		#include_once("include_send.php");
		#$_SESSION['schedule_running']=false;
		#$content=file_get_contents($_SESSION['status_services']);
		#if (strpos($content,"schedule_running']=true")>-1)
		#{
		#	$content=str_ireplace("['schedule_running']=true","['schedule_running']=false",$content);
		#	file_put_contents($_SESSION['status_services'], $content);
		#}
		#for ($x=0;$x<21;$x++)
		#{
		#	if ($_SESSION['schedule']['flag_action'][$x] >0)
		#	{	
		#		$opt= $_SESSION['schedule']['command_pin'][$x]."#1".$_SESSION['schedule']['action_end'][$x];
		#		send_value($opt);
		##		$reset_pins.=$_SESSION['schedule']['command_pin'][$x].";";
		#		$_SESSION['schedule']['flag_action'][$x]=0;
		#	}
		#}
		#echo $reset_pins;
		#break;
		
		case 'd':
		for ($x=$_POST['pos']-1;$x<21;$x++)
		{
			$_SESSION['shortcut']['name'][$x]=$_SESSION['shortcut']['name'][$x+1];
			$_SESSION['shortcut']['command'][$x]=$_SESSION['shortcut']['command'][$x+1];
			
		}
		$_SESSION['shortcut']['name'][$x]='';
		$_SESSION['shortcut']['command'][$x]='';
		echo "deleted ".$_POST['pos'];
		break;
		
		default:
		if ($_POST['mode']=="u")
		{
			$start=$_POST['pos']-1;
			$end=$_POST['pos'];
		}
		else
		{
			$start=0;
			$end=20;
		}
		
		for ($comandi_rapidi=$start; $comandi_rapidi < $end; $comandi_rapidi++)
		{
			if (($_SESSION['shortcut']['name'][$comandi_rapidi] != '') && ($_POST['mode']!="u"))
			{
				continue;
			}
			//$controls=explode(";",$string_comando_rapido[0]);
			
			$_SESSION['shortcut']['name'][$comandi_rapidi]=$string_comando_rapido[0];
			$_SESSION['shortcut']['command'][$comandi_rapidi]=$string_comando_rapido[1];
			$human=$end;
			break;
		}
		echo ($comandi_rapidi < 20) ? $_SESSION['lang_existing_fast_commands_saved']."@@".$human : $_SESSION['lang_limits_of_command']." (20)!";
		break;
	}			