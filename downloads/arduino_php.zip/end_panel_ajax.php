<?php
	
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - END WINDOW</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script type="text/javascript" src="script/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="script/jquery-ui-sliderAccess.js"></script>
		<link rel="stylesheet" href="css/sunny/jquery-ui-1.8.23.custom.css">
		
		<link rel="stylesheet" href="css/base/jquery.ui.tabs.css">
		<link rel="stylesheet" type="text/css" href="css/base/jquery-ui-timepicker-addon.css">
		
		<style>
			body {margin-top:0; padding-top:0; font-family: arial; font-size:12px; }
			td { font-family: arial; font-size:12px; border:1px solid; vertical-align:top; }
			INPUT { font-family: arial; font-size:12px; }
			
			/* IE  */
			INPUT[type="text"] {font-family: Arial; font-size:12px}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		
	</head>
	<body>
	<br>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>	
				<td style="border:none;" align="center" >
					<table width="50%" border="0">
						<tr>
							<td width="90%" style="border:none;">
								<img src="img/quadro.jpg">
							</td>
						</tr>
						<tr>
							<td height="253"  bgcolor="#e2e2e2" >
								<font size="8"><center>
									<strong>DOMINO</strong>
								</center></font>
								Port closed!Session ended! Thank you.
								<input type="button" onclick="location.href='index.php';" value="RESTART ME!">
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		
	</body>
</html> 
