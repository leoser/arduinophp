<?php
session_start();
$log_file_read = fopen($_SESSION['logfile'], "r") or exit("File non trovato!");
?>
<html>
<head>
<title>CONTROLLO ARDUINO - ESTENSIONE PHP - LOG FILE</title>
</head>
<body>
LOG FILE
<hr>
<?php
while(!feof($log_file_read))
  {
  echo fgets($log_file_read);
  echo "<hr />";
  }
fclose($log_file_read);
?> 
</body>
</html>
