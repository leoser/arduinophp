<?php
session_start();
include("lang/lang_".$_SESSION['lang'].".php");
$log_file_read = fopen($_SESSION['logfile'], "r") or exit("File not found!");
?>
<html>
<head>
<title><?php echo $_SESSION['lang_logfile_page_title'];?></title>
</head>
<body>
LOG FILE
<hr>
<?php
while(!feof($log_file_read))
  {
  echo fgets($log_file_read);
  echo "<hr />";
  }
fclose($log_file_read);
?> 
</body>
</html>
