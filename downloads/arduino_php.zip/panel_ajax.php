<?php
	include_once("functions_values.php");
	$content=file_get_contents($_SESSION['status_services']);
	if (strpos($content,"dump_running']=false")>-1)
	{
		$content=str_ireplace("['dump_running']=false","['dump_running']=true",$content);
		file_put_contents($_SESSION['status_services'], $content);
	}
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script type="text/javascript" src="script/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="script/jquery-ui-sliderAccess.js"></script>
		<link rel="stylesheet" href="css/sunny/jquery-ui-1.8.23.custom.css">
		
		<link rel="stylesheet" href="css/base/jquery.ui.tabs.css">
		<link rel="stylesheet" type="text/css" href="css/base/jquery-ui-timepicker-addon.css">
		
		
		<!-- JQUERY UI TABS -->
		<script>
			$(function() {
				$( "#tabs" ).tabs();
			});
		</script>
		
		<!-- JQUERY UI TIPS-->
		<script>
			$(document).ready(function(){
				$(function() {
					$( document ).tooltip();
				});
				
			$("#exit_app").click(function() 
				{
					// close survey
					$("#stop_survey").click();
					// close schedule
					$("#stop_schedule").click();
					// andiamo a mettere false a tutti i run nel file status_services.php 
					// meno che alla porta e alla session
					$.ajax({
						type: "POST",
						url: "update_dump.php",
						data: 'mode=s',
						async: false,
						success: function(msg){
						},
						error: function(msg){
						}
					})
					window.close();
					
				});
			});
		</script>
		
		<style>
			body {margin-top:0; padding-top:0; font-family: monospace; font-size:10px; }
			td { font-family: monospace; font-size:10px; border:1px solid; vertical-align:top; }
			INPUT { font-family: monospace; font-size:10px; }
			
			/* IE  */
			INPUT[type="text"] {font-family: monospace; font-size:10px}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		
		<!-- JQUERY SCRIPT PER WATCHDOG -->
		<?php  include"jquery_survey.php"; ?>
		
		<!-- JQUERY SCRIPT PER SCHEDULE-->
		<?php  include"jquery_schedule.php"; ?>
		
		<script>
			function send_value(opt)
			{
				var singolo=0;
				var ripetizioni=1;
				var delay=0;
				var globals=1;
				/* POSSONO ARRIVARE COMANDI VARI */
				/* tutto 	quello che ha dentro un # e' qualcosa che va ad un pin di arduino
					/* tutto 	quello senza va alla dll o a fare dei check/comandi con arduino
				/* in 		document.getElementById("all").value c'e un eventuale comando globale (, dato dai bottoni di shortcut */
				if (document.getElementById("all").value!='')
				{
					var stream_commands=document.getElementById("all").value.split(';');
					var globals=stream_commands.length;
					document.getElementById("all").value="";
				}
				for (var glob=0;glob<globals;glob++)
				{
					if (globals > 1)
					opt= stream_commands[glob];
					
					var valArray = opt.split('#');
					if (valArray.length ==1)
					{
						/* comando singolo non verso un pin */
						var singolo=1;
					}
					else
					{
						if (parseInt(valArray[0].substr(1)) > 13)
						{	   
							/* e' un analogico camuffsato da digitale
								decrementiamo di 14 il parseint e mettiamo a al posto di d 
							in modo da visualizzare il valore di ritorno sul pin analogico giusto */
							var z=parseInt(valArray[0].substr(1))-14;
							valArray[0]='a'+z;
						}
						if (valArray[0].charAt(0) == 'p')
						/* e' un digitale in pwm
							sistemiamo il primo carattere 
						in modo da visualizzare il valore di ritorno sul pin digitale giusto */
						valArray[0]=valArray[0].replace("p", "d");
						
						if (valArray[0].charAt(0) == 'a')
						document.getElementById("label_"+valArray[0]).innerHTML="V";
						
						
						/* e' un comando multiplo???  spezzettiamolo e mandiamo uno per uno */
						if (valArray[1].indexOf('*') != -1)
						{	   
							/* 
								in temp_array[0[ c'e il comando con il set
								in temp_array[1[ c'e il numero di ripetizioni
								in termp_array[2] c'e il reaction
							in temparray[3] c'e il delay */
							var temp_array = valArray[1].split('*');
							var ripetizioni=(temp_array[1]*2);
							var delay=temp_array[3]*1000;
						}
						for (i=0; i< ripetizioni;i++)
						{
							/* segnale di trasmissione */
							$( '#green_'+valArray[0]).attr('src','img/green.png');
							
							if (ripetizioni >1)
							opt=(i %2 == 0 ?  valArray[0]+"#"+temp_array[0] : valArray[0]+"#"+temp_array[0].substr(0,(temp_array[0].length-1))+temp_array[2] ) ;
							
							log=($('#log_arduino').is(':checked'))? 's' : 'n';
							$.ajax({
								type: "POST",
								url: "include_send.php",
								data: "data="+opt+"&delay="+delay+"&log="+log,
								async: false,
								success: function(msg){
									var valArray1 = msg.split('%');
									/*  	per comandi multipli (blink led)viene ritornata una stringa, in  valArray1[0] con valore ed i tre parametri della ripetizione
										tipo 1*3*0*500 
									per adesso riportiamo come valore  del pin da esporre il numero 2 (reset)  */
									if (valArray1[0].indexOf('*') != -1)
									{
										var temp_array = valArray1[0].split('*');
										valArray1[0]=temp_array[2];
									}	
									if (singolo == 0)
									{
										if ($('#block_pwm_'+valArray[0]).is(':visible'))
											$('#valore_pin_pwm_'+valArray[0]).html(valArray1[0]);
										else
											$('#valore_pin_'+valArray[0]).text(valArray1[0]);
										
										$('#last_valore_pin_'+valArray[0]).html(valArray1[1]);
										
										/* check se msg_dialog e' > 950 bytes */
										if ($('#msg_dialog').html().length > 9500)
											$('#msg_dialog').html('');
											
										$('#msg_dialog').html($('#msg_dialog').html()+valArray1[2]);
										/* segnale di fine trasmissione */
										$( '#green_'+valArray[0]).attr("src","img/off.png");
										if (globals >1)
										{
											/* se era un set di un digital o di un analog in digital mode nel comando multiplo, si dovrebbe dare il nuovo valore allo slider */
											if ($("#slider_hilo_" + valArray[0]).length > 0)
											{
												if ($("#slider_hilo_" + valArray[0]).is(':visible'))
												$('#slider_hilo_'+valArray[0]).slider({value:+valArray1[0] });
											}
										}
									}
									else
									/* check se msg_dialog e' > 950 bytes */
									if ($('#msg_dialog').html().length > 9500)
										$('#msg_dialog').html('');
									$('#msg_dialog').html($('#msg_dialog').html()+valArray1[0]);
								},
								error: function(msg){
									//alert("error");
								}
							});
						}
					}
				}
			}
			
			function send_value_system(opt)
			{
				/* qui arrivano i comandi di systema
					/* ho preferito gestirli  separati  dai comandi normali per evitare un eccessivo "intasamento" della funzione
				/* send_value e per predisporgli un php ad hoc */
				
				var valArray = opt.split(';');
				document.getElementById("system_command").value="";
				
				/* seganle di trasmissione generale */
				//$( '#green_general'+valArray[0]).attr('src','img/green.png');		
				$.ajax({
					type: "POST",
					url: "system_command.php",
					data: "command="+valArray[1],
					async: false,
					success: function(msg){
						//var val_Array1 = msg.split('%');
						// $( '#green_general').attr("src","img/off.png");
						switch (valArray[1]) 
						{
							case "a":
							location.reload(true);
							break;
							case "e":
							$('#msg_port_header').text(valArray[1]=='e'? 'Porta Chiusa' : '');
							$('#span_port').text(valArray[1]=='e'? 'Porta Chiusa' : 'Porta Aperta');
							$('#button_port').val(valArray[1]=='e'? 'Apri' : 'Chiudi');
							$('#button_port').attr('onclick',(valArray[1]=="e" ? 'document.getElementById("system_command").value="SYSTEM;a"; prep_send_value();' :  'document.getElementById("system_command").value="SYSTEM;e"; prep_send_value();' ) );
							$('#msg_ser_ok').html("");
							$('#msg_ard_ok').html("");
							$('#msg_pause_ard_ok').html("");
							if (msg.indexOf('chius') > 0)
							{
								/* la porta e' stata chiusa  
									mettiamo APRI al bottone porta   e Porta Chiusa al messaggio a fianco e rinfreschiamo il search delle porte
								e spegniamo tutto */
								//$('#span_port').html('Porta Chiusa');
								//$('#button_port').val('Apri');
								var msg1="";
								$.ajax({
									type: "POST",
									url: "testcom.php",
									data: "from_ajax=true",
									async: false,
									success: function(msg1){
									},
									error: function(msg1){
										//alert("error");
									}
								});
								/* si dovrebbero orbare tutti i controlli e spegnere il watch se running  lasciando solo il bottone apri o comparire in alto un bottone apri*/
								$("#stop_survey").click();  /* fermiamo survey comunque */
								$("#stop_schedule").click();  /* fermiamo survey comunque */
								
								$('input, textarea, select').attr('disabled', 'disabled');
								$('.ui-slider').hide();
								$("img").hide();
								$('#button_port').attr('disabled', false);
							}
							break;
							case "?":
							$('#msg_ser_ok').html("<font color='red'>"+msg+"</font>");
							var $msg1="<font color='red'>Test Seriale</font>";
							break;
							case '*':
							$('#msg_ard_ok').html("<font color='red'>"+msg+"</font>");
							var $msg1="<font color='red'>Arduino Ready</font>";
							break;
							default:
							break;
						}
						$('#msg_dialog').html("<font color='red'>"+opt+" ->"+msg1+"</font>");
					},
					error: function(msg){
						//alert("error");
					}
				});
			}
		</script>
	</head>
	<body onload="init();" bgcolor="#c4c4c4">
		
		<!--  UI SLIDERS -->
		<script src="write_slider.php"></script>
		
		<form name='arduino' method="POST" onsubmit="hide();">
			<input type="hidden" name="lastcommand" value="<?php echo $opt;?>">
			<input type="hidden" id="show_settings_panel" name="show_settings_panel" value="<?php echo $show_settings_panel;?>">
			<input type="hidden" id="show_watch_panel" name="show_watch_panel" value="<?php echo $show_watch_panel;?>">
			<input type="hidden" id="show_working_panel" name="show_working_panel" value="<?php echo $show_working_panel;?>">
			<input type="hidden" id="show_message_panel" name="show_message_panel" value="<?php echo $show_message_panel;?>">
			<input id="all" type="hidden"  name="all" value="">
			<input id="watch_running" type="hidden"  name="watch_running" value="<?php echo $watch_running;?>">
			
			<div id="tabs">
				<div style="float:left;width:450px;">
					<ul>
						<li><a href="#tabs-1">Watch</a></li>
						<li><a href="#tabs-2">Scheduler</a></li>
						<li><a href="#tabs-3">Shortcut</a></li>
						<li><a href="#tabs-4">Message</a></li>
						<li><a href="#tabs-5">Settings</a></li>
					</ul>
				</div>
				<div id="msg_port_header" style="float:left;margin-left:10px;margin-top:0px;">
					<?php echo $msg_port_header;?>
				</div>
				<div style="float:right;margin-top:0px;">
					<span id="exit_app" name="exit_app" style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';"><b><u><font color="red">* EXIT *</font></u></b></span> | 
					<span id="watch_map" name="watch_map" style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';"><b><u>Watch Map</u></b></span> - 
					<span id="realtime_watch" name="realtime_watch" style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';"><b><u>Watch 10 sec.</u></b></span> | 
					<span id="domo_map" name="domo_map" style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';"><b><u>Schedule Map</u></b></span> - 
					<span id="realtime_domo" name="realtime_domo" style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';"><b><u>Schedule 60 sec.</u></b></span> | 
					<a href="dump.php" target="dump"><b>SESSION 10 sec.</b></a>
				</ul>
			</div>
			
			<!--div id="tabs-1">
			<!--div id="working_panel" style="display:<?php echo $show_working_panel;?>;"-->	
			<table width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td width="100%" style="border:none;" colspan="3">
						<table width="100%">
							<tr>
								<td colspan="14" align="center"> 
									<font size="3"><strong>DIGITAL</strong></font>
								</td>
								<td colspan="6" align="center" style="vertical-align: middle;"> 
									<font size="3"><strong>ANALOG</strong></font>
								</td>
							</tr>
							<tr>
								<?php 
									for ($x=0;$x<14;$x++)
									{
									?>
									<!--td align="center" id="td_d<?php echo $x;?>" bgcolor="<?php if ($_SESSION['val_digital_pin']['stato'][$x] == -1) echo $_SESSION['bgcolor'][1]; else echo $_SESSION['bgcolor'][0];?>"-->
									<td align="center" id="td_d<?php echo $x;?>" bgcolor="#b2b2b2">
										<img id="img_show_d<?php echo $x;?>" style="display:none;" src="img/show.gif" onclick="show_pin('d<?php echo $x;?>');">
										<span id="txt_show_d<?php echo $x;?>" style="display:none;">
											<font size="3">
												<strong>P<br>i<br>n<br><?php echo $x;?></strong>
											</font>
										</span>
										
										<div id="d<?php echo $x;?>" style="display:block;">
											<span id="name_pin_d<?php echo $x;?>" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="show_name_pin(<?php echo $x;?>,'d')"; style="display:block;">
												<font size="3">
													<strong>
														<?php echo $_SESSION['val_digital_pin']['name'][$x];?>
													</strong>
												</font>
											</span>
											<span id="name_pin_assigned_d<?php echo $x;?>" style="display:none;">
												<font size="3">
													<input type="text" id="text_pin_d<?php echo $x;?>" name="text_pin_d<?php echo $x;?>" size="6" maxlength="6" ondblclick="change_pin_name('','d',<?php echo $x;?>)"; onkeypress="change_pin_name(event,'d',<?php echo $x;?>);">
												</font>
											</span>
											<span>
												<hr>
												STATO<br>
												<div style="margin:1px 3px;float:left;"><b>Enb</b></div>
												<div style="margin-right:1px;float:right;"><b>Dsb</b></div>
												<div style="clear:both;"></div>
												<div id="slider_stato_d<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;"></div>
												<input type="hidden" id="stato_d<?php echo $x;?>" name="stato_d<?php echo $x;?>" value="">
												<!--	D<input type="radio" name="enable_dc_<?php echo $x;?>" value="" <?php echo ($_SESSION['val_digital_pin']['stato'][$x]==0) ? ' checked' : ''?>><br>
												<input style="font-size:10;" type="button" value="CHG" onclick="javascript:change_val('*d<?php echo $x;?>');"-->
											</span>
											<span>
												<hr>
												TIPO<br>
												<?php echo(($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11)) ?
													'<div>
													<div style="margin:1px 4px;float:left;"><b>D</b></div>
													<!--div style="position:relative;float:left;margin-top:1px;margin-left:16px;"><b>D</b></div-->
													<div style="margin:1px 4px;float:right;"><b>P</b></div>
													</div>'
													:
													'<div style="margin:1px 4px;float:left;"><b>D</b></div>
												<!--div style="margin:1px 1px;float:right;"><b>D</b></div-->';?>
												
												<div style="clear:both;"></div>
												
												<div id="slider_tipo_d<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;"></div>
												<!-- SE IL PIN E' PWM ALLORA PUO' ESSERE IMPOSTATO AD ANALOG -->
												<input type="hidden" id="tipo_p_d<?php echo $x;?>" name="tipo_p_d<?php echo $x;?>" value="">
												<!--input id="current_set_a<?php echo $x;?>" type="radio" name="current_set_a<?php echo $x;?>" value="" <?php echo($_SESSION['val_digital_pin']['current_type'][$x]=='a') ?  ' checked' : ''?>><br-->
											</span>	
											<span id="block_send_d<?php echo $x;?>">
												<hr>
												SEND<br>
												<div>
													<div style="margin:1px 4px;float:left;"><b>L</b></div>
													<!--div style="position:relative;float:left;margin-top:1px;margin-left:16px;"><b>H</b></div-->
													<div style="margin:1px 4px;float:right;"><b>H</b></div>
												</div>
												
												<div style="clear:both;"></div>
												<div id="slider_hilo_d<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;"></div>
												<input type="hidden" id="hilo_d<?php echo $x;?>" name="hilo_d<?php echo $x;?>"  value="">
											</span>
											
											<?php if (($x==3) || ($x==5) || ($x==6) || ($x==9) || ($x==10) || ($x==11))
												{?>
												
												<span id="block_pwm_d<?php echo $x;?>" style="display:none;width:100%;margin:1px 0px 10px 0px;">
													<hr style="width=100%;">
													<center>
														<div style="height:73px;padding-left:0px;">
															<div id="slider_pwm_d<?php echo $x;?>" style="float:left;margin:3px 4px;width:8px;height:70px;">
															</div>
															<div style="margin-top:0px;">255</div>
															<div id="valore_pin_pwm_d<?php echo $x;?>" style="margin-top:20px;left:1px;font-size:13px;" >
																<?php echo $_SESSION['val_digital_pin']['valore'][$x];?>
															</div>
															<div style="position:relative;margin-top:20px;">0</div>
														</div>
														<input type="hidden" id="pwm_d<?php echo $x;?>" name="pwm_d<?php echo $x;?>" size="3" value="">
													</center>
												</span>
											<?php } ?>	
											<span id="value_normal_d<?php echo $x;?>" style="dislay:block";>
												<hr>
												<font size="4">
													<strong>
														<span id="valore_pin_d<?php echo $x;?>" >
															<?php echo $_SESSION['val_digital_pin']['valore'][$x];?>
														</span>
													</strong>
												</font>
											</span>
											<hr>
											LAST<br>
											<span id="last_valore_pin_d<?php echo $x;?>">
												00:00:00<br>
												00:00:00<br>
												<!--<?php echo $_SESSION['val_digital_pin']['orario'][$x];?>-->
											</span>
											<hr>
											<span id="<?php echo $x;?>_select">
												SEL.<input id="d_checked_<?php echo $x;?>" type="checkbox">
											</span>
											<hr>
											<p>
												<img id="red_d<?php echo $x;?>" src="img/green.png">
												<img id="green_d<?php echo $x;?>" src="img/off.png">
											</p>
											<hr>
											<div style="float:right;"> 
												HIDE <img src="img/hide.gif" onclick="show_pin('d<?php echo $x;?>');">
											</div>
											
										</div>
									</td>
									<?php } 
									for ($x=0;$x<6;$x++)
									{
									?>
									
									<td align="center" id="td_a<?php echo $x;?>" bgcolor="#d1d1d1">
										<img id="img_show_a<?php echo $x;?>" style="display:none;" src="img/show.gif" onclick="show_pin('a<?php echo $x;?>');">
										<span id="txt_show_a<?php echo $x;?>" style="display:none;">
											<font size="3">
												<strong>P<br>i<br>n<br><?php echo $x;?></strong>
											</font>
										</span>
										<div id="a<?php echo $x;?>" style="display:block;">
											<span id="name_pin_a<?php echo $x;?>" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="show_name_pin(<?php echo $x;?>,'a')"; style="display:block;">
												<font size="3">
													<strong>
														<?php echo $_SESSION['val_analog_pin']['name'][$x];?>
													</strong>
												</font>
											</span>
											<span id="name_pin_assigned_a<?php echo $x;?>" style="display:none;">
												<font size="3">
													<input type="text" id="text_pin_a<?php echo $x;?>" name="text_pin_a<?php echo $x;?>" size="6" maxlength="6" ondblclick="change_pin_name('','a',<?php echo $x;?>)"; onkeypress="change_pin_name(event,'a',<?php echo $x;?>);">
												</font>
											</span>
											<span>
												<hr>
												STATO<br>
												<div style="margin:1px 3px;float:left;"><b>Enb</b></div>
												<div style="margin-right:1px;float:right;"><b>Dsb</b></div>
												<div style="clear:both;"></div>
												<div id="slider_stato_a<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;"></div>
												<input type="hidden" id="stato_a<?php echo $x;?>" name="stato_a<?php echo $x;?>" value="">
											</span>
											<span>
												<hr>
												TIPO<br>
												<div>
													<div style="margin:1px 4px;float:left;"><b>A</b></div>
													<div style="margin:1px 4px;float:right;"><b>D</b></div>
												</div>
												<div style="clear:both;"></div>
												<div id="slider_tipo_a<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;"></div>
												<input type="hidden" id="tipo_p_a<?php echo $x;?>" name="tipo_p_a<?php echo $x;?>" value="">
											</span>	
											<hr>
											<div id="buttons_map_con_a<?php echo $x;?>" style="display:block;margin-bottom:3px;">
												<img id="image_map_a<?php echo $x;?>" src="img/m.png" onmouseover="this.src='img/m_on.png'" onmouseout="this.src='img/m.png'" onclick="show_map_con('a','<?php echo $x;?>','m');"><img id="image_con_a<?php echo $x;?>" src="img/c.png"  onmouseover="this.src='img/c_on.png'" onmouseout="this.src='img/c.png'" onclick="show_map_con('a','<?php echo $x;?>','c');"><img id="image_vref_a<?php echo $x;?>" src="img/v.png"  onmouseover="this.src='img/v_on.png'" onmouseout="this.src='img/v.png'" onclick="show_map_con('a','<?php echo $x;?>','v');">
											</div>
											<span id="block_map_a<?php echo $x;?>" style="display:none;">
												MAP<br>
												<?php $map=explode(":",$_SESSION['val_analog_pin']['map'][$x]);?>
												<input type="text" size="3" id="va_1_a<?php echo $x;?>" name="va_1_<?php echo $x;?>" value="<?php echo $map[0];?>"><input type="text" size="3" id="va_2_a<?php echo $x;?>" name="va_2_<?php echo $x;?>" value="<?php echo $map[1];?>"><br>
												<input type="text" size="3" id="va_3_a<?php echo $x;?>" name="va_3_<?php echo $x;?>" value="<?php echo $map[2];?>"><input type="text"size="3" id="va_4_a<?php echo $x;?>" name="va_4_<?php echo $x;?>" value="<?php echo $map[3];?>"> <br>
												<span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="update_map_con_vref('a',<?php echo $x;?>,'m');">Ok</span> | <span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="show_map_con('a','<?php echo $x;?>','m')";>Ann</span>
												
											</span>
											<span id="block_con_a<?php echo $x;?>" style="display:none;">
												CONSTR.<br>
												<?php $con=explode(":",$_SESSION['val_analog_pin']['constrain'][$x]);?>
												<input type="text" size="3" id="con_1_a<?php echo $x;?>" name="con_1_<?php echo $x;?>" value="<?php echo $con[0];?>"><input type="text" size="3" id="con_2_a<?php echo $x;?>" name="con_2_<?php echo $x;?>" value="<?php echo $con[1];?>"><br>
												<span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="update_map_con_vref('a',<?php echo $x;?>,'c');">Ok</span> | <span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="show_map_con('a','<?php echo $x;?>','c')";>Ann</span>
											</span>
											<span id="block_vref_a<?php echo $x;?>" style="display:none;">
												VREF<br>
												<?php $vref=$_SESSION['val_analog_pin']['vref'][$x];?>
												<span style="margin-right:-3px;">D</span><input type="radio" id="vref_1_a<?php echo $x;?>" name="vref_1_a<?php echo $x;?>" value="1" <?php echo ($vref=='1')? 'checked' : '';?>><input type="radio" id="vref_2_a<?php echo $x;?>" name="vref_1_a<?php echo $x;?>" value="2" <?php echo ($vref=='2')? 'checked' : '';?>><span style="margin-left:-3px;">I</span><br>
												<span style="margin-right:-3px;">E</span><input type="radio" id="vref_3_a<?php echo $x;?>" name="vref_1_a<?php echo $x;?>" value="3" <?php echo ($vref=='3')? 'checked' : '';?>><br>
												<span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="update_map_con_vref('a',<?php echo $x;?>,'v');">Ok</span> | <span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="show_map_con('a','<?php echo $x;?>','v')";>Ann</span>
											</span>
											<span id="block_send_a<?php echo $x;?>" style="display:none;">
												SEND<br>
												<div>
													<div style="margin:1px 4px;float:left;"><b>L</b></div>
													<!--div style="position:relative;float:left;margin-top:1px;margin-left:16px;"><b>H</b></div-->
													<div style="margin:1px 4px;float:right;"><b>H</b></div>
												</div>
												<!--div style="margin-left:1px;float:left;"><b>HI</b></div>
												<div style="margin:1px 3px;float:right;"><b>LO</b></div-->
												<div style="clear:both;">
												</div>
												<div id="slider_hilo_a<?php echo $x;?>" style="width:40px; margin:1px 4px 0px 2px;">
												</div>
												<input type="hidden" id="hilo_a<?php echo $x;?>" name="hilo_a<?php echo $x;?>"  value="">
												
											</span>
											
											<span id="send_a<?php echo $x;?>"><input style="font-size:10;" type="button" value="READ" onclick="send_value('a<?php echo $x;?>#0');"></span>
											
											<div id="value_normal_a<?php echo $x;?>">
												<hr>
												<font size="4">
													<div style="font-weight:bold;text-align:center;overflow:hide;z-index:1;" id="valore_pin_a<?php echo $x;?>">
														0
													</div>
													<div style="float:right;font-weight:bold;font-size:9px;margin-top:-8px;margin-right:1px;color:red;background : #FFFFD1;z-index:-1" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" style="cursor: pointer;" id="label_a<?php echo $x;?>" onclick="to_volt('<?php echo $x;?>')">
														V
													</div>
												</font>
											</div>
											<hr>
											LAST<br>
											<span id="last_valore_pin_a<?php echo $x;?>">
												00:00:00<br>
												00:00:00<br>
												<!--<?php echo $_SESSION['val_digital_pin']['orario'][$x];?>-->
											</span>
											<hr>
											<span id="<?php echo $x;?>_select">
												SEL.<input id="a_checked_<?php echo $x;?>" type="checkbox">
											</span>
											<hr>
											<p align="center">
												<img id="red_a<?php echo $x;?>" src="img/green.png" alt="">&nbsp;
												<img id="green_a<?php echo $x;?>" src="img/off.png" alt="">
											</p>
											<hr>
											<div style="float:right;"> 
												HIDE <img src="img/hide.gif" onclick="show_pin('a<?php echo $x;?>');">
											</div>
										</div>
										<input type="hidden" id="real_valore_pin_a<?php echo $x;?>" value="">
									</td>
								<?php } ?>
							</tr>
						</table>
					</td>
				</tr>
				<tr>	
					<td style="border:none;">
						<div id="tabs-1" style="height:250px;">
							<!--div id="watch_panel" style="display:<?php echo $show_watch_panel;?>;"-->	
							<table width="100%" border="0">
								<tr style="height:250px;">
									<td width="20%" bgcolor="#d2d2d2">
										
										<font size="2"><center><strong>MESSAGGI WATCHDOG</strong> (<a href="view_log.php" target="LOG">LOG</a> <input id="log_survey" type="checkbox" name="logsurvey">)</center></font>
										
										<div id="survey"></div>
										<center>
											<input style="font-size:10;margin-top:5px;" id="start_survey" type="button" value="START">
											<input style="font-size:10;margin-top:5px;" id="stop_survey" type="button" value="STOP" >
										</center>
									</td>
									<td width="40%" bgcolor="#d2d2d2" >
										<font size="2"><strong><center><span id="message_table_watch"><u><font color='blue'>INSERIMENTO</font></u>/MODIFICA/CANCELLAZIONE CONTROLLI</span></center></strong></font>
										<div style="width:100%; text-align:center;">
											<p>
												<b>Nome Controllo</b> <input type="text" name="nome_watch" id="nome_watch" size="30">
												&nbsp;&nbsp;Abilitato :<input id="watch_abilitato" type="radio" name="watch_abilitato" checked>SI <input id="watch_disabilitato" type="radio" name="watch_abilitato">NO
											</p>
											<span style="float:left;margin:2px;"><font size="1">SAMPLING OGNI (sec): </font>
												<input type="text" id="sampling_val" name="sampling_val" size="4" value=""> 
											</span>
											<div id="slider_sampling_val" style="float:right;width:60%; margin-top:2px;margin-right:20px;height:10px;">
												<div style="position:absolute;width:100%;margin-top:12px;">
													<div style="float:left;">10</div>
													<div style="float:right;">120</div>
												</div>
											</div>
										</div>
										<div style="clear:both;"></div>
										<!--div style="margin:8px;"-->
											<hr>
										<!--/div-->
										<div style="width:48%;float:left;margin-left:5px;">
											<font size="2"><strong><center>* CONTROLLO *</center></strong></font>
											<font size="1"><u>TIPO PIN</u></font>
											<input id="c_type_d" type="radio" name="type" value="d" onclick="dropdown_filter('c','d');">DIGIT.
											<input id="c_type_a" type="radio" name="type" value="a" onclick="dropdown_filter('c','a');">ANALOG.
											<input id="c_type_p" type="radio" name="type" value="p" onclick="dropdown_filter('c','p');"><font color="red">PWM</font>
											<br>
											<font size="1"><u>NUMERO PIN</u></font> <select id="c_numeropin"></select> 
											<!--input id="c_numeropin" type="text" name="numeropin" size="2" value=""-->
											<br>
											<font size="1"><u>OPERATORE</u></font>
											<input id="c_=" type="radio" name="oper" value="\\=">=
											<input id="c_lt" type="radio" name="oper" value="&lt;">&lt;
											<input id="c_gt" type="radio" name="oper" value="&gt;">&gt;
											<br>
											<font size="1"><u>VALORE COMPARAZIONE</u></font> <input type="text" id="c_val_compara" name="comparazione" size="4" value="">
											<p><font color="red">PWM</font> valore da array di sessione</p>
										</div>
										<div style="width:50%;float:right;">
											<font size="2"><strong><center>* AZIONE *</center></strong></font>
											<font size="1"><u>TIPO PIN</u></font>
											<input id="a_type_d" type="radio" name="a_type" value="d" onclick="dropdown_filter('a','d');">DIGIT.
											<input id="a_type_a" type="radio" name="a_type" value="a" onclick="dropdown_filter('a','a');">ANALOG.
											<input id="a_type_p" type="radio" name="a_type" value="p" onclick="dropdown_filter('a','p');">PWM
											<br>
											<font size="1"><u>NUMERO PIN</u></font> <select id="a_numeropin"></select>
											<!--input id="a_numeropin" type="text" name="a_numeropin" size="2" value=""-->
											<br>
											<font size="1"><u>SET</u></font> 
											<input id="a_high" type="radio" name="a_set" value="1">HI
											<input id="a_low" type="radio" name="a_set" value="0">LO
											<span id="val_set"  style="display:none;">
												<input id="a_val" type="radio" name="a_set" value="v">VAL:<input id="as_val_numeropin" type="text" name="a_set_val" size="4" value="">
											</span>
											<br>
											<font size="1"><u>RESET</u></font> 
											<input id="a_rst_none" type="radio" name="a_rst_none" value="">NONE
											<input id="a_rst_high" type="radio" name="a_rst_set" value="1">HI
											<input id="a_rst_low" type="radio" name="a_rst_set" value="0">LO
											<span id="val_rst_set"  style="display:none;">
												<input id="a_rst_val" type="radio" name="a_rst_set" value="v">VAL:<input id="as_rst_val_numeropin" type="text" name="a_rst_set_val_numeropin" size="4" value="">
											</span>
											
										</div>
										
										<div style="clear:both;text-align:center;">
											<hr>
											<input id="save_watch" type="button" value="SALVA">
											<input id="clear_watch" type="button" value="CLEAR" onclick="panel_watch_clear();">
										</div>
										
									</td>
									<td width="40%" align="left" bgcolor="#d2d2d2">
										<font size="2"><strong><center>CONTROLLI PRESENTI</center></strong></font>
										<div bgcolor="#d2d2d2" id="Layer0" style="width:99%; height:230px;z-index:1; overflow: auto;">
											<table width="100%" border="0" cellpadding="0" cellspacing="1">
												<tr>
													<td style="border:none;">N.</td>
													<td align="center" width="30%" style="border:none;">Nome</td>
													<td style="border:none;">Sec.</td>
													<td align="center" style="border:none;">Human Read</td>
													<td style="border:none;">&nbsp;</td>
													<td style="border:none;">&nbsp;</td>
												</tr>
												<?php 
													$controlli_attivi=0;
													for ($controlli=0; $controlli < 10; $controlli++)
													{
														echo "<tr>";
														echo "<td  style='border:none;' align='center'>".($controlli+1).") </td>";
														if ($_SESSION['survey']['command'][$controlli]!='')
														$controlli_attivi++;
														$info_item=
														$_SESSION['survey']['command'][$controlli].";".
														$_SESSION['survey']['elapse'][$controlli].";".
														$_SESSION['survey']['name'][$controlli];
														$values=values_pin_in_survey($controlli);
														echo "
														<td style='border:none;relative:absolute;' align='left'>
														<span title='".$values."' id='name_watch_".($controlli+1)."' OnMouseOver=\"this.style.cursor='pointer';\">".$_SESSION['survey']['name'][$controlli]."</span>";
														echo "<input type='hidden' name='control_watch_".($controlli+1)."' id='control_watch_".($controlli+1)."' value='".$info_item."'>
														</td>
														<td style='border:none;' align='center'><span id='elapse_watch_".($controlli+1)."'>".$_SESSION['survey']['elapse'][$controlli]."</span>
														</td>";
														echo "
														<td style='border:none;' align='left'><span id='human_watch_".($controlli+1)."'>".$_SESSION['survey']['human'][$controlli]."</span>
														</td>";
														
														echo "<td width='16' style='border:none;'><img id='img_tabwatch_c".($controlli+1)."' src='img/c.png' onmouseover='this.src=\"img/c_on.png \"'onmouseout='this.src=\"img/c.png\"' onclick='mod_watch(".($controlli+1).",\"d\")';></td>";
														echo "<td width='16' style='border:none;'><img id='img_tabwatch_m".($controlli+1)."' src='img/m.png' onmouseover='this.src=\"img/m_on.png \"' onmouseout='this.src=\"img/m.png\"' onclick='mod_watch(".($controlli+1).",\"u\")';></td>";
														echo "</tr>";
													}
												?>
												<tr>
													<td colspan="6" align="center" style="border: none;">
														<input type="button" name="SALVAWATCH" value="SALVA CONTROLLI" onclick="load_save_schewatch('w','s')";>
														<input type="button" name="CARICAWATCH" value="CARICA" onclick="load_save_schewatch('w','l')";>
													</td>
												</tr>
												<tr>
													<td colspan="3" align="center" style="border: none;">
														<br><img src='img/c.png'> Cancella 
													</td>
													<td colspan="3" align="center" style="border: none;">
														<br><img src='img/m.png'> Modifica
													</td>
												</tr>
											</table>
										</div>
									</td>
								</tr>
							</table>
						</div> <!-- FINE DEL watch PANEL -->
					</td>
					
					<td style="border:none;">
						<div id="tabs-2" style="height:250px;" >
							<!--div id="schedule_panel" style="display:<?php echo $show_schedule_panel;?>;"-->	
							<table width="100%" style="border:none;height:250px;" >
								<tr>
									<td width="20%" bgcolor="#d2d2d2">
										
										<font size="2"><center><strong>MESSAGGI SCHEDULER</strong> (<a href="view_log.php" target="LOG">LOG</a> <input id="log_schedule" type="checkbox" name="logschedule">)</center></font>
										
										<div id="schedule"></div>
										<center>
											<input style="font-size:10;margin-top:5px;" id="start_schedule" type="button" value="START">
											<input style="font-size:10;margin-top:5px;" id="stop_schedule" type="button" value="STOP" >
										</center>
									</td>
									<td width="40%" bgcolor="#d2d2d2">
										<font size="2"><strong><center><span id="message_table_schedule"><u><font color='blue'>INSERIMENTO</font></u>/MODIFICA/CANCELLAZIONE SCHEDULE</span></center></strong></font>
										
										<script>
											$(function() {
												$( "#datepick_1" ).datepicker({
													timeFormat: 'hh:mm',
													dateFormat: 'dd:mm:yy',
													monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
													dayNames: ['Domenica','Lunedi','Martedi','Mercoledi','Giovedi','Venerdi','Sabato'],
													dayNamesShort: ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'],
													dayNamesMin: ['Do','Lu','Ma','Me','Gi','Ve','Sa'],
													firstDay: 1,
												});
												
												$('#timepick_1').timepicker({
													hourGrid: 4,
													minuteGrid: 10
												});
												$( "#datepick_2" ).datepicker({
													timeFormat: 'hh:mm',
													dateFormat: 'dd:mm:yy',
													monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
													dayNames: ['Domenica','Lunedi','Martedi','Mercoledi','Giovedi','Venerdi','Sabato'],
													dayNamesShort: ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'],
													dayNamesMin: ['Do','Lu','Ma','Me','Gi','Ve','Sa'],
													firstDay: 1,
												});
												
												$('#timepick_2').timepicker({
													hourGrid: 4,
													minuteGrid: 10
												});
											});
										</script>
										<hr>
										<table border="0" cellpadding="0" width="100%" cellspacing="1">
											<tr>
												<td width="50%" style="border:none;">
													<b>Nome</b> 
													<input type="text" name="nome_schedule" id="nome_schedule" size="30" value="">
												</td>
												<td width="50%" style="border:none;" align="center">
													<font size="1"><u>TIPO PIN</u></font>
													<input id="schedule_type_d" type="radio" name="schedule_type_d" value="d" onclick="dropdown_filter('s','d');">DIGITAL
													&nbsp;&nbsp;<font size="1"><u>PIN</u></font> <select id="s_numeropin"></select> 
												</td>
											</tr>
											<tr>	
												<td colspan="2" style="border:none;">
													<hr>
												</td>
											</tr>
											<tr>
												<td width="50%" align="center" style="border:none;">
													<b>Data Attivita' Scheduler</b>
												</td>
												<td align="center" style="border:none;">
													<b>Ora  Attivita' Scheduler</b>
												</td>
											</tr>
											<tr>
												<td style="border:none;">
													Start <input name="datepick_1" id="datepick_1" type="text" size="10">&nbsp;&nbsp;Stop <input name="datepick_2" id="datepick_2" type="text" size="10">
												</td>
												
												<td style="border:none;">
													Start <input name="timepick_1" id="timepick_1" type="text" size="10">&nbsp;&nbsp;Stop <input name="timepick_2" id="timepick_2" type="text" size="10">
												</td>
											</tr>
											<tr>	
												<td colspan="2" style="border:none;">
													<hr>
												</td>
											</tr>
											<tr>
												
												<td colspan="2" align="center" style="border:none;">
													<b>Giorni: Lu<input type="checkbox" name="lu" id="dd0">&nbsp;Ma<input type="checkbox" name="ma" id="dd1">&nbsp;Me<input type="checkbox" name="me" id="dd2">&nbsp;Gi<input type="checkbox" name="gi" id="dd3">&nbsp;Ve<input type="checkbox" name="ve" id="dd4">&nbsp;Sa<input type="checkbox" name="sa" id="dd5">&nbsp;Do<input type="checkbox" name="do" id="dd6">&nbsp;Tutti<input type="checkbox" name="tu" id="dd7" onclick="schedule_all('1');">&nbsp;Nessuno<input type="checkbox" name="no" id="dd8" onclick="schedule_all('0');">
													</td>
												</tr>
												<tr>	
													<td colspan="2" style="border:none;">
														<hr>
													</td>
												</tr>
												<tr>
													<td align="center" style="border:none;">
														<b>Start Value</b><br>
														&nbsp;
														Hi<input name="schedule_start_value" id="schedule_start_value_hi" type="radio" >
														Lo<input name="schedule_start_value" id="schedule_start_value_lo" type="radio" >
														Value<input name="schedule_start_value" id="schedule_start_value_v" type="radio" size="5">
														<input name="schedule_start_value" id="schedule_start_value_val" type="text" size="5">
													</td>
													
													<td align="center" style="border:none;">
														<b>Stop Value</b> <br>
														&nbsp;
														Hi<input name="schedule_stop_value" id="schedule_stop_value_hi" type="radio" >
														Lo<input name="schedule_stop_value" id="schedule_stop_value_lo" type="radio" >
														Value<input name="schedule_stop_value" id="schedule_stop_value_v" type="radio" >
														<input name="schedule_stop_value" id="schedule_stop_value_val" type="text" size="5">
													</td>
												</tr>
												<tr>	
													<td colspan="2" style="border:none;">
														<hr>
													</td>
												</tr>
												<tr>
													<td colspan="2" width="100%" style="border:none;">
														<table width="100%" border="0">
															<tr>
																<td width="30%" align="center" style="border:none;">
																	WATCH START :<input id="numero_controllo_start" type="text" name="numero_controllo_start" size="5" value="" onclick="show_controlli();">
																</td>
																<td width="30%" align="center" style="border:none;">
																	WATCH STOP :<input id="numero_controllo_stop" type="text" name="numero_controllo_stop" size="5" value="" onclick="show_controlli();">
																</td>
																<td align="center" style="border:none;">
																	Abilitato :<input id="schedule_abilitato" type="radio" name="schedule_abilitato" checked> SI
																	<input id="schedule_disabilitato" type="radio" name="schedule_abilitato"> NO
																</td>
															</tr>
														</table>
													</tr>
												</table>
												<div style="clear:both;text-align:center;">
													<hr>
													<input id="save_schedule" type="button" value="SALVA">
													<input id="clear_schedule" type="button" value="CLEAR" onclick="panel_schedule_clear();">
												</div>
												
											</td>
											<td width="40%" align="center" bgcolor="#d2d2d2">
												<font size="2"><strong><center>SCHEDULE PRESENTI</center></strong></font>
												<div bgcolor="#d2d2d2" id="Layer1" style="position:absolute; width:39%; height:220px;z-index:1; overflow: auto;">
													<table width="100%" border="0" cellpadding="0" cellspacing="1">
														<tr>
															<td align="center" style="border:none;">N.</td>
															<td style="border:none;">Nome (mouseover per INFO)</td>
															<td align="center" style="border:none;">Start</td>
															<td align="center" style="border:none;">Stop</td>
															<td style="border:none;">&nbsp;</td>
															<td style="border:none;">&nbsp;</td>
															<td style="border:none;">&nbsp;</td>
														</tr>
														
														<?php 
															$schedule_attivi=0;
															for ($schedule=0; $schedule < 20; $schedule++)
															{
																echo "<tr>";
																echo "<td  style='border:none;' align='center'>".($schedule+1).") </td>";
																if ($_SESSION['schedule']['name'][$schedule]!='')
																$schedule_attivi++;
																$info_item=
																$_SESSION['schedule']['name'][$schedule]."#".
																$_SESSION['schedule']['command_pin'][$schedule]."#".
																$_SESSION['schedule']['date_start'][$schedule]."#".
																$_SESSION['schedule']['date_end'][$schedule]."#".
																$_SESSION['schedule']['time_start'][$schedule]."#".
																$_SESSION['schedule']['action_start'][$schedule]."#".
																$_SESSION['schedule']['time_end'][$schedule]."#".
																$_SESSION['schedule']['action_end'][$schedule]."#".
																$_SESSION['schedule']['days'][$schedule]."#".
																$_SESSION['schedule']['watch_start'][$schedule]."#".
																$_SESSION['schedule']['watch_stop'][$schedule]."#".
																$_SESSION['schedule']['enable'][$schedule];
																$values=values_pin_in_schedule($schedule);
																echo "
																<td style='border:none;'>
																<span title='".$values."' id='name_schedule_".($schedule+1)."'OnMouseOver=\"this.style.cursor='pointer';\">".$_SESSION['schedule']['name'][$schedule]."</span>";
																echo "<input type='hidden' name='control_schedule_".($schedule+1)."' id='control_schedule_".($schedule+1)."' value='".$info_item."'>
																</td>
																<td style='border:none;' align='center'><span id='time_start_schedule_".($schedule+1)."'>".$_SESSION['schedule']['time_start'][$schedule]."</span>
																</td>";
																echo "
																<td style='border:none;' align='center'><span id='time_end_schedule_".($schedule+1)."'>".$_SESSION['schedule']['time_end'][$schedule]."</span>
																</td>
																<td style='border:none;'> 
																<span id='enabled_schedule_".($schedule+1)."'>";
																if ($_SESSION['schedule']['enable'][$schedule] == "s") 
																echo "Abilitato"; 
																else
																echo "Disabilit.";
																echo " 
																</span>
																</td>";
																echo "<td width='16' style='border:none;'><img id='img_tabschedule_c'".($schedule+1)."' src='img/c.png' onmouseover='this.src=\"img/c_on.png \"'onmouseout='this.src=\"img/c.png\"' onclick='mod_schedule(".($schedule+1).",\"d\")';></td>";
																echo "<td width='16' style='border:none;'><img id='img_tabschedule_m'".($schedule+1)."' src='img/m.png' onmouseover='this.src=\"img/m_on.png \"' onmouseout='this.src=\"img/m.png\"' onclick='mod_schedule(".($schedule+1).",\"u\")';></td>";
																echo "</tr>";
															}
														?>
														<tr>
															<td colspan="7" align="center" style="border: none;">
																<hr>
																<input type="button" name="SALVASCHED" value="SALVA SCHEDULE" onclick="load_save_schewatch('s','s')";> 
																<input type="button" name="CARICASCHED" value="CARICA" onclick="load_save_schewatch('s','l')";> 
															</td>
														</tr>
														<tr>
															<td colspan="7" align="center" style="border: none;">
																<hr>
																<img src='img/c.png'> Cancella 
																&nbsp;&nbsp;
																<img src='img/m.png'> Modifica
															</td>
														</tr>
													</table>
												</div>
											</td>
										</tr>
									</table>
								</div> <!-- FINE DEL schedule PANEL -->
							</td>
							
							<td style="border:none;">
								<div id="tabs-3" style="height:250px;" >
									<table border="0" width="100%" style="height:250px;" >
										<tr>
											<td width="35%" align="center" bgcolor="#d2d2d2">
												<p>
													<font size="2"><strong>SHORTCUT SELEZIONI</strong></font><br>
													<input style="font-size:10;" type="button" value="DESELECT all DIGIT." onclick="javascript:all_select_family('d#d');">
													<input style="font-size:10;" type="button" value="DESELECT all ANALG." onclick="javascript:all_select_family('a#d');">
													<input style="font-size:10;" type="button" value="DESELECT all DIGIT.+ANALG." onclick="javascript:all_select_family('d;a#d');"><br>
													<input style="font-size:10;" type="button" value="SELECT all DIGIT." onclick="javascript:all_select_family('d#s');">
													<input style="font-size:10;" type="button" value="SELECT all ANALG." onclick="javascript:all_select_family('a#s');">
													<input style="font-size:10;" type="button" value="SELECT all DIGIT.+ANALG." onclick="javascript:all_select_family('d;a#s');">
												</p>
												<p>
													<font size="2"><center><strong>	AZIONI SU PIN SELEZIONATI</strong></center></font>
													<input style="font-size:10;" type="button" value="Set all DIGIT. to LOW" onclick="javascript:all_select('d#1#0');">
													<input style="font-size:10;" type="button" value="Set all DIGIT. to HIGH" onclick="javascript:all_select('d#1#1');"><br>
													<hr>
													<input style="font-size:10;" type="button" value="Read all DIGIT." onclick="javascript:all_select('d#1');">
													<input style="font-size:10;" type="button" value="Read all ANALG." onclick="javascript:all_select('a#0');">
												</p>	
												<!--font size="3"><center><strong>Pannelo SETTING <input style="font-size:10;" type="button" id="button_settings_panel" value="<?php if($show_settings_panel=='none') echo 'SCOPRI'; else echo 'NASCONDI';?>" onclick="javascript:show_hide('settings_panel');"><br>
													Pannelo WATCH <input style="font-size:10;" type="button" id="button_watch_panel" value="<?php if($show_watch_panel=='none') echo 'SCOPRI'; else echo 'NASCONDI';?>" onclick="javascript:show_hide('watch_panel');"><br>
													Pannelo WORKING <input style="font-size:10;" type="button" id="button_working_panel" value="<?php if($show_working_panel=='none') echo 'SCOPRI'; else echo 'NASCONDI';?>" onclick="javascript:show_hide('working_panel');"><br>
													Pannelo MESSAGE <input style="font-size:10;" type="button" id="button_message_panel" value="<?php if($show_message_panel=='none') echo 'SCOPRI'; else echo 'NASCONDI';?>" onclick="javascript:show_hide('message_panel');">
												</strong></center></font-->
											</td>
											<td width="30%" bgcolor="#d2d2d2">
												<font size="2"><center><strong>	COMANDI RAPIDI </strong></center></font>
												<table border="0" width="100%">
													<tr>
														<td  style="border:none;">
															<input type="radio" name="val" value="a0#0">  RD ANALOG 0 </br>
															<input type="radio" name="val" value="a3#0">  RD ANALOG 3 </br>
															<input type="radio" name="val" value="d12#11">  HIGH PIN12   </br>
															<input type="radio" name="val" value="d12#10">  LOW PIN12  </br>
															<input type="radio" name="val" value="d12#11*3*0*500*" > BLINK PIN12 3 VOLTE </br>
															
														</td>
														<td  style="border:none;">
															Digita comando <input type="text" name="val1" size="8">
														</td>
													</tr>
													<tr>
														<td colspan="2" align="center"  style="border:none;">
															<div id="send" style="border-top:solid 1px;">
																<input id="button_shortcut_command" style="font-size:10;margin-top:5px;" type="button" value="Invia Comando" onclick="prep_send_value();">
															</div>
														</td>
													</tr>
												</table>
											</td>
											
											<td width="25%" bgcolor="#d2d2d2">
												<font size="2"><center><strong>STATUS PORTA SERIALE</strong></center></font>
												<input type="button" id="button_port" name="command0" value='Chiudi' onclick="document.getElementById('system_command').value='SYSTEM;e'; prep_send_value();" > 											
												<span id="span_port">
													<?php echo $msg_port;?>
												</span>
												
												<span id="info">
													<?php
														
													?>
												</span>
												<br>
												<font size="2"><center><strong>COMANDI SISTEMA</strong></center></font>
												<table width="100%">
													<tr>
														<td>
															CHECK PORTA SERIALE <span id="msg_ser_ok" style="float:right;margin-right:3px;"></span>
														</td>
														<td width=20%>
															<input type="button" name="command1" value="CHECK" onclick="document.getElementById('system_command').value='SYSTEM;?'; prep_send_value()";>
														</td>
													</tr>
													<tr>
														<td>
															CHECK ARDUINO READY <span id="msg_ard_ok" style="float:right;margin-right:3px;"></span>
														</td>
														<td>
															<input type="button" name="command2" value="CHECK" onclick="document.getElementById('system_command').value='SYSTEM;*'; prep_send_value()";>
														</td>
													</tr>
													<tr>
														<td>
															PAUSE ARDUINO<span id="msg_pause_ard_ok" style="float:right;margin-right:3px;"></span>
														</td>
														<td>
															<input type="button" name="command3" value="CHECK" onclick="document.getElementById('system_command').value='SYSTEM;p'; prep_send_value()";>
														</td>
													</tr>
													<tr>
														<td>
															END SESSION AND STOP ARDUINO
														</td>
														<td>
															<input style="background:red;color:white;" 
															type="button" 
															name="command4" 
															value="PANIC!" 
															onclick="document.getElementById('system_command').value='SYSTEM;e'; prep_send_value();">
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</div>
							</td>
							
							
						</tr>
					</table>
					<!--/div> <!-- FINE DEL WORKING PANEL -->
					<div id="tabs-4" style="height:250px;" >
						<!--div id="message_panel"-->
						<table width="100%" height="250px">
							<tr>
								<td width="60%" bgcolor="#d2d2d2">
									<font size="2"><center>
										<strong>DIALOGO CON ARDUINO</strong> (<a href="view_log.php" target="log">LOG</a><input type="checkbox" id="log_arduino" name="log_arduino" value="<?php echo $_SESSION['dialog_to_file'];?>">) | 
										<a href="dati/log.txt" target="viewlog">VIEW LOG</a>  | 
										<span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="clear_save_log('s');"><u>SAVE LOG</u></span> |
										<span style="cursor: pointer;" OnMouseOver="this.style.cursor='pointer';" OnMouseOut="this.style.cursor='default';" onclick="clear_save_log('c');"><u>CLEAR LOG</u></span>
									</center></font>
									<div bgcolor="#d2d2d2" id="msg_dialog" style="width:99%; height:230px;z-index:1; overflow: auto;">
									<?php echo $_SESSION['msg_dialog'];?>
									</div>
								</td>
								<td width="20%" bgcolor="#d2d2d2">
									<font size="2"><center><strong>PANNELLO MESSAGGI</strong></center></font><br>
									<?php echo $msg;?>
								</td>
								<td width="20%" bgcolor="#d2d2d2">
									<font size="2"><center><strong>PANNELLO ERRORI</strong></center></font><br>
									<?php echo $_SESSION['msg_error'];?>
								</td>
							</tr>
						</table>
					</div> <!-- FINE DEL MESSAGE PANEL -->
					
					<div id="tabs-5" style="height:250px;" >
						<!--div id="settings_panel" style="width:100%;display:<?php echo $show_settings_panel;?>;"-->
						<table width="100%" style="height:250px;" >
							<tr>
								<td align="center" style="vertical-align: middle;"> 
									<font size="4"><strong>S<br>E<br>T<br>U<br>P</strong></font>
								</td>
								<td align="center" style="vertical-align: middle;"> 
									IN COSTRUZIONE
								</td>
							</tr>
							<!--
								<?php 
									for ($x=0;$x<14;$x++)
									{
									?>
									<td id="pin_d_setup<?php echo $x;?>" bgcolor="<?php if ($_SESSION['val_analog_pin']['stato'][$x] == -1) echo $_SESSION['bgcolor'][1]; else echo $_SESSION['bgcolor'][0];?>">
									<center>
									<img id="img_show_d_setup<?php echo $x;?>" style="display:none;" src="img/show.gif" onclick="show_pin('d<?php echo $x;?>');">
									<span id="txt_show_d_setup<?php echo $x;?>" style="display:none;">
									<font size="4">
									<strong>P<br>i<br>n<br><?php echo $x;?></strong>
									</font>
									</span>
									</center>
									<div id="d_setup<?php echo $x;?>" style="display:block;">
									<center>
									<font size="4">
									<strong>Pin <?php echo $x;?>
									<div style="float:right;"> 
									<img src="img/hide.gif" onclick="show_pin('d<?php echo $x;?>');">
									</div>
									</strong>
									</font>
									</center>
									<p>
									<center> MODE</center>
									<input type="radio" id="type_io0" name="type_io0" value="1">IN 
									<br>
									<input type="radio" id="type_io0" name="type_io0" value="0">OUT 
									<hr>
									<center> DEFAULT</center>
									<input type="radio" id="def_0" name="def_0" value="1">1 
									<br>
									<input type="radio" id="def_0" name="def_0" value="0">0 
									<br>
									val :<input type="text" id="def_val_0" name="def_val_0" value="1" size="1">  
									<hr>
									<center>
									<input type="button" value="SEND" onclick="send(0);">
									<input type="button" value="RST" onclick="reset_pin(0);">
									</center>
									</p>
									</div>
									</td>
								<?php } ?>
								</tr>
								<tr>
								<td colspan="15" align="center">
								<input type="button" value="INVIA TUTTI I VALORI">
								</td>
							</tr-->
						</table>
					</div> <!-- FINE DEL SETTING PANEL -->	
					
					<input type='hidden' id='watch_mode' value="">
					<input type='hidden' id='watch_numbers_present' value="<?php echo $controlli_attivi;?>">
					<input type='hidden' id='watch_position' value="">
					<input type='hidden' id='schedule_mode' value="">
					<input type='hidden' id='schedule_numbers_present' value="<?php echo $schedule_attivi;?>">
					<input type='hidden' id='schedule_position' value="">
					<input type="hidden" id="chg" name="chg" value="">
					<input type='hidden' id='system_command' value="">
				</div>
			</form>
			<script>
				function update_map_con_vref(a, pin, b)
				{
					$('#block_con_'+a+pin).hide();
					$('#block_vref_'+a+pin).hide();
					$('#block_map_'+a+pin).hide();
					document.getElementById('image_vref_'+a+pin).src='img/v.png';
					document.getElementById('image_con_'+a+pin).src='img/c.png';
					document.getElementById('image_map_'+a+pin).src='img/m.png';
					$('#send_'+a+pin).show();
					$("#value_normal_a"+pin).show();
					
					switch (b)
					{
						case "m":
						/* effettuiamo l'update dei valori di map se necessario */
						var data=	document.getElementById('va_1_'+a+pin).value+":"+
						document.getElementById('va_2_'+a+pin).value+":"+
						document.getElementById('va_3_'+a+pin).value+":"+
						document.getElementById('va_4_'+a+pin).value;
						update_array("data="+a+";"+pin+";"+data+"&mode=m");
						
						break;
						
						case "c":
						/* effettuiamo l'update dei valori di constrain se necessario */
						var data=	document.getElementById('con_1_'+a+pin).value+":"+
						document.getElementById('con_2_'+a+pin).value;
						update_array("data="+a+";"+pin+";"+data+"&mode=c");		
						
						break;
						
						case "v":
						/* effettuiamo l'update dei valori di vref se necessario */
						var data=$('input:radio[name=vref_1_'+a+pin+']:checked').val();
						update_array("data="+a+";"+pin+";"+data+"&mode=v");		
						break;
						
						default:
						break;
					}
				}
				
				function show_map_con(a, pin, b)
				{
					$("#value_normal_a"+pin).hide();
					switch (b)
					{
						case "m":
						if (document.getElementById('block_map_'+a+pin).style.display=='none') 
						{
							if ($('#block_con_'+a+pin).is(':visible'))
							{
								$('#block_con_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_con_'+a+pin).src='img/c.png';
								
							}	
							if ($('#block_vref_'+a+pin).is(':visible'))
							{
								$('#block_vref_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_vref_'+a+pin).src='img/v.png';
							}	
							$('#block_map_'+a+pin).show();
							$('#send_'+a+pin).hide();
							
						}
						else
						{
							$("#value_normal_a"+pin).show();
							$('#block_map_'+a+pin).hide();
							$('#send_'+a+pin).show();
							document.getElementById('image_map_'+a+pin).src='img/m_on.png';
						}
						break;
						
						case "c":
						if (document.getElementById('block_con_'+a+pin).style.display=='none') 
						{
							if ($('#block_map_'+a+pin).is(':visible'))
							{
								$('#block_map_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_map_'+a+pin).src='img/m.png';
							}	
							if ($('#block_vref_'+a+pin).is(':visible'))
							{
								$('#block_vref_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_vref_'+a+pin).src='img/v.png';
							}	
							$('#block_con_'+a+pin).show();
							$('#send_'+a+pin).hide();
						}
						else
						{
							$("#value_normal_a"+pin).show();
							$('#block_con_'+a+pin).hide();
							$('#send_'+a+pin).show();
							document.getElementById('image_con_'+a+pin).src='img/c_on.png';
						}
						break;
						
						case "v":
						if (document.getElementById('block_vref_'+a+pin).style.display=='none') 
						{
							if ($('#block_map_'+a+pin).is(':visible'))
							{
								$('#block_map_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_map_'+a+pin).src='img/m.png';
							}	
							if ($('#block_con_'+a+pin).is(':visible'))
							{
								$('#block_con_'+a+pin).hide();
								$('#send_'+a+pin).show();
								document.getElementById('image_con_'+a+pin).src='img/c.png';
							}	
							$('#block_vref_'+a+pin).show();
							$('#send_'+a+pin).hide();
						}
						else
						{
							$("#value_normal_a"+pin).show();
							$('#block_vref_'+a+pin).hide();
							$('#send_'+a+pin).show();
							document.getElementById('image_vref_'+a+pin).src='img/v_on.png';
						}
						break;
						default:
						break;
					}
				}
				
				function change_val(item)
				{
					hide();
					document.getElementById("chg").value=item;
					arduino.submit();
				}
				
				function hide()
				{
					document.getElementById("send").style.display="none";
					//document.getElementById("rc_send").style.display="none";
					//document.getElementById("rc_receive").style.display="none";
					document.getElementById("info").innerHTML="Invio in corso.....";
				}
				
				function load_save_schewatch(type,mode)
				{
					var string="type="+type+"&mode="+mode;
					$.ajax({
						type: "POST",
						url: "save_load_schedwatch.php",
						data: string,
						async: false,
						success: function(msg){
							/* ricarichiamo la tabella dei controlli o dello schedule se e' stato richiesto il reload */
						},
						error: function(msg){
						}
					})
				}
				
				function update_array(string)
				{
					$.ajax({
						type: "POST",
						url: "update_array.php",
						data: string,
						async: false,
						success: function(msg){
						},
						error: function(msg){
						}
					})
				}
				
				function show_hide(a)
				{
					if (document.getElementById(a).style.display=='none') 
					{
						document.getElementById(a).style.display='block'; 
						document.getElementById('button_'+a).value='NASCONDI'; 
						document.getElementById('show_'+a).value='block'; 
					}
					else 
					{
						document.getElementById(a).style.display='none'; 
						document.getElementById('button_'+a).value='SCOPRI'; 
						document.getElementById('show_'+a).value='none'; 
					}
				}
				
				function all_select_family(value)
				{
					var x=0,z=0;
					var valArray = value.split('#');
					var set_desel=valArray[1];
					var ana_dig=valArray[0].split(';');
					for (z= 0; z< ana_dig.length; z++)
					{
						var n_pin=( ana_dig[z]=='d' ?  13 : 5);
						for (x= 0 ; x <=n_pin ; x++)
						document.getElementById(ana_dig[z]+'_checked_'+x.toString()).checked=( set_desel=='s' ?  true : false);
					}	
				}
				
				function all_select(value)
				{
					var x=0;
					var ret_str="";
					var valArray = value.split('#');
					var ana_dig=valArray[0];
					var type=valArray[1];
					var set_read=valArray[2];
					var set_value=( valArray.length == 3 ? valArray[2] : '');
					var n_pin=( ana_dig=='d' ?  13 : 5);
					
					for (x= 0 ; x <=n_pin ; x++)
					{
						if (document.getElementById(ana_dig+'_checked_'+x.toString()).checked == true)
						{
							if ((type=='1') || (type == 0))
							{
								ret_str+=ana_dig+x.toString()+'#'+type+set_value+';';
							}
							else
							{
								/* la struttura per set range e' diversa */
								/* ancora da completare */
								for (xx= 1 ; xx < 5 ; xx++)
								ret_str+=ana_dig+document.getElementById("va_"+xx.toString()+"_"+x.toString()).value+';'+type;
							}	
						}
					}	
					document.getElementById("all").value=ret_str;
					send_value(ret_str);
				}
				
				function show_pin(a)
				{
					// nasconde/visualizza colonna pin
					if (document.getElementById(a).style.display == 'block')
					{
						document.getElementById('td_'+a).style.width="2px";
						document.getElementById(a).style.display = 'none';
						document.getElementById('img_show_'+a).style.display = 'block';
						document.getElementById('txt_show_'+a).style.display = 'block';
					}
					else
					{
						document.getElementById('td_'+a).style.width="auto";
						document.getElementById('img_show_'+a).style.display = 'none';
						document.getElementById('txt_show_'+a).style.display = 'none';
						document.getElementById(a).style.display = 'block';
					}
				}
				
				function reset_pin(pin)
				{
					/* da implementare */
					document.getElementById('def_val_'+pin).value=1;
					document.getElementById('type_io'+pin).checked=0;
					document.getElementById('def_'+pin).checked=0;
				}
				
				function prep_send_value() 
				{
					if (document.getElementById("system_command").value.indexOf('SYSTEM') == 0)
					{
						send_value_system(document.getElementById("system_command").value);
					}
					else
					{
						if (document.forms["arduino"].val1.value !='')
						{
							var opt=document.forms["arduino"].val1.value;
							document.forms["arduino"].val1.value='';
						}
						else
						{
							var val_items = document.forms["arduino"].val.length;
							for (var i = 0; i < val_items; i++) 
							{
								if (document.forms["arduino"].val[i].checked) 
								{
									var opt=document.forms["arduino"].val[i].value;
									break;
								}
							}
						}
						if (opt !="")
						send_value(opt);
					}
				}
				function to_volt(analog_pin)
				{
					if (parseFloat(document.getElementById("valore_pin_a"+analog_pin).innerHTML) >0.00)
					{
						if ((document.getElementById("label_a"+analog_pin).innerHTML)=="V")
						{
							document.getElementById("label_a"+analog_pin).innerHTML="N";
							document.getElementById("real_valore_pin_a"+analog_pin).value=document.getElementById("valore_pin_a"+analog_pin).innerHTML;
							document.getElementById("valore_pin_a"+analog_pin).innerHTML=Math.round(parseFloat(document.getElementById("valore_pin_a"+analog_pin).innerHTML*0.0049)*100)/100;
						}
						else
						{
							document.getElementById("label_a"+analog_pin).innerHTML="V";
							document.getElementById("valore_pin_a"+analog_pin).innerHTML=document.getElementById("real_valore_pin_a"+analog_pin).value;
						}
					}
				}
				
				function dropdown_filter(control_action,type,selected)
				{
					var start_indice=0;
					var max_indice=0;
					var x;
					var select='';
					var selected=(selected == undefined ? '' : selected);
					
					if (type == "p")
					{
						start_indice=3;
						max_indice=12;
						if (control_action == "a")
						{
							$('#val_set').show();
							$('#val_rst_set').show();
						}
					}
					else
					{
						$('#val_set').hide();
						$('#val_rst_set').hide();
						if (control_action == "s")
						max_indice=20;
						else
						max_indice = (type=="a" ? 6 : 14);
					}
					for (x=start_indice;x<max_indice;x++)
					{
						if ((type =="p") && ((x==4) || (x==7) || (x==8)))
						continue;
						else
						{
						var post_text=((max_indice==20) && (x>13)? ' (a'+(x-14)+')' : '');
						select+=(x==selected ? "<option value='"+x+"' selected>"+x+"</option>": "<option value='"+x+"'>"+x+post_text+"</option>");
						}
					}
					$('#'+control_action+'_numeropin').html(select);
				}
				
				
				function popup(page)
				{
					jQuery('a.popup').live('click', function(){
					newwindow=window.open($(this).attr('href'),'','height=200,width=150');
					if (window.focus) {newwindow.focus()}
					return false;
				});
				}
				
				function schedule_all(type)
				{
					var x;
					for (x=0;x<7;x++)
					(type== 1 ? $('#dd'+x).attr('checked',true) : $('#dd'+x).attr('checked',false));
					
					(type== 1 ? $('#dd'+8).attr('checked',false) : $('#dd'+7).attr('checked',false) );
				}
				
				function show_name_pin(num,type)
				{
					document.getElementById('name_pin_'+type+num).style.display = 'none';
					document.getElementById('name_pin_assigned_'+type+num).style.display = 'block';
					document.getElementById('text_pin_'+type+num).focus();
				}
				
				function init()
				{
					panel_watch_clear();
					dropdown_filter('c','a')
					dropdown_filter('a','d');
					panel_schedule_clear();
					dropdown_filter('s','d');
				}
				
				function change_pin_name(e,type,num)
				{
					var characterCode;
					if (e=="")
					characterCode = 13;
					else
					{
						e = e;
						characterCode =(e && e.which) ? e.which : e.keyCode;
					}
					if (characterCode == 13) 
					{
						if (document.getElementById('text_pin_'+type+num).value == "")
							document.getElementById('text_pin_'+type+num).value='Pin'+num;
						
						/* alert("SALVIAMO"); */
						var valuez=document.getElementById('text_pin_'+type+num).value;
						$.ajax({
							type: 'POST',
							url: 'update_array.php',
							data: 'data='+type+'@'+valuez+'@'+num+'&mode=name',
							async: false,
							success: function(msg){
								/* alert("Nome pin Salvato"); */
								$("#name_pin_"+type+num).html('<font size=3><strong>'+document.getElementById('text_pin_'+type+num).value+'</strong></font>');
							},
							error: function(msg){
								alert("Problemi nel salvataggio nome");
							}
						});
						document.getElementById('name_pin_assigned_'+type+num).style.display="none";
						document.getElementById('name_pin_'+type+num).style.display="block";
						//if ($('#block_map_'+a+pin).is(':visible'))
					}
					if (characterCode == 27) 
					{
						document.getElementById('name_pin_assigned_'+type+num).style.display="none";
						document.getElementById('name_pin_'+type+num).style.display="block";
					}
					
				}
				
				function clear_save_log(mode)
				{
					$('#msg_dialog').html('');
					$.ajax({
						type: "POST",
						url: "clear_save_log.php",
						data: 'mode='+mode,
						async: false,
						success: function(msg){
						},
						error: function(msg){
						}
					})
				}
				
			</script>
			<div style="display:none;">
				<img src="img/red.png">
				<img src="img/green.png">
			</div>
		</body>
	</div>
</html> 
