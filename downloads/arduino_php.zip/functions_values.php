<?php
	# RITORNA una stringa con i valori del controllo o dello schedule
	# funzioni chiamate direttamente o con post da ajax
session_start();
	if ($_POST['item'])
		{
		if($_POST['mode']=='sv')
			$ret_string=values_pin_in_survey($_POST['item']-1);
		else
			$ret_string=values_pin_in_schedule($_POST['item']-1);
		echo $ret_string;
		}

	function values_pin_in_schedule($item)
	{
		$ret_string='
		<b><font size="2">*'.$_SESSION["schedule"]["name"][$item].'</b></font><br>
		<b>Pin di Arduino:</b> '.$_SESSION["schedule"]["command_pin"][$item].'<br>
		<b>Data Validita":</b> '.$_SESSION["schedule"]["date_start"][$item].' - '.$_SESSION["schedule"]["date_end"][$item].'<br>
		<b>Orari</b>&nbsp;&nbsp;&nbsp;Start: '.$_SESSION["schedule"]["time_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["time_end"][$item].'<br>
		<b>Valori Azioni</b>&nbsp;&nbsp;&nbsp;Start: ';
		
		if ($_SESSION["schedule"]["action_start"][$item] > 1)  
		$ret_string.=$_SESSION["schedule"]["action_start"][$item];
		else
		$ret_string.=($_SESSION["schedule"]["action_start"][$item] == 0) ? 'LOW' : 'HIGH';
		
		$ret_string.='&nbsp;&nbsp;&nbsp;Stop: ';
		
		if ($_SESSION["schedule"]["action_end"][$item] > 1)  
		$ret_string.=$_SESSION["schedule"]["action_end"][$item];
		else
		$ret_string.=($_SESSION["schedule"]["action_end"][$item] == 0) ? 'LOW' : 'HIGH';
		
		$ret_string.='<br>
		<b>Giorni di Attivazione:</b> ';
		$giorni=explode('@',$_SESSION["schedule"]["days"][$item]);
		if (count($giorni)-1 > 0)
		{
			for ($x=0; $x < count($giorni)-1; $x++)
			$ret_string.= $_SESSION["giorni_name"][$giorni[$x]].' ';
		}
		else
		$ret_string.=($_SESSION["schedule"]["days"][$item] == 7) ? 'Tutti' : 'Nessuno';
		
		$ret_string.='<br>
		<b>Watch di Controllo</b>&nbsp;&nbsp;&nbsp;Start: '.$_SESSION["schedule"]["watch_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["watch_stop"][$item];
		#'STATO CORRENTE<br>'.
		#'Running :'.$_SESSION["schedule"]["flag_action"][$item].'  dalle ore :'.$_SESSION["schedule"]["date_time_started"][$item].'<br>'.
		#'Ultimo passaggio :'.$_SESSION["schedule"]["last"][$item].'  Tempo trascordo dall"avvio :'.$_SESSION["schedule"]["elapse"][$item];
		return $ret_string;
	}
	
	function values_pin_in_survey($item)
	{
		$ret_string='
		<b><font size="2">*'.$_SESSION["survey"]["name"][$item].'</font></b><br>
		<b>Comando : </b>'.$_SESSION["survey"]["command"][$item].'<br>
		<b>Comando Human Read : </b>'.$_SESSION["survey"]["human"][$item].'<br>
		<b>Tempo di sampling : </b>'.$_SESSION["survey"]["elapse"][$item].' sec.<br>
		<b>Pin di controllo Arduino : </b>'.$_SESSION["survey"]["control_d_a"][$item].$_SESSION["survey"]["control_pin"][$item].'<br>
		<b>Operatore : </b>'.$_SESSION["survey"]["control_operator"][$item] .'<b>   Valore di controllo : </b>'.$_SESSION["survey"]["control_value"][$item].'<br>
		<div>
		<div style="float:left">
		<b>Azione</b><br>
		<b>Pin : </b>'.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'<b>   Set : </b> '.$_SESSION["survey"]["action_set_pin"][$item].'<b>
		Value : </b>';
		if ($_SESSION["survey"]["action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["action_value"][$item];
		else
		$ret_string.=($_SESSION["survey"]["action_value"][$item] == 0) ? 'LOW' : 'HIGH';
		$ret_string.='
		</div>
		<div style="float:left;padding-left:20px;">
		<b>ReAzione</b><br>
		<b>Pin : </b>'.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'<b>   Set : </b> '.$_SESSION["survey"]["re_action_set_pin"][$item].'<b>   Value : </b> ';
		
		if ($_SESSION["survey"]["re_action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["re_action_value"][$item];
		else
		$ret_string.=($_SESSION["survey"]["re_action_value"][$item] == 0) ? 'LOW' : 'HIGH';
		$ret_string.='</div></div><div style="clear:both;">';
		$ret_string.='
		<b>Stato corrente : </b>';
		$ret_string.=($_SESSION["survey"]["flag_action"][$item] == 0)? 'Not Running':'Running';
		return $ret_string;
	}	
?>