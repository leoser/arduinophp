<?php
	# RITORNA una stringa con i valori del controllo o dello schedule
	# funzioni chiamate direttamente o con post da ajax
	session_start();
	include("/lang/lang_".$_SESSION['lang'].".php");
	
	if ($_POST['item'])
		{
		if($_POST['mode']=='sv')
			$ret_string=values_pin_in_survey($_POST['item']-1);
		else
			$ret_string=values_pin_in_schedule($_POST['item']-1);
		echo $ret_string;
		}

	function values_pin_in_schedule($item)
	{
		$ret_string='
		<b><font size="2">*'.$_SESSION["schedule"]["name"][$item].'</b></font><br>
		<b>'.$_SESSION['lang_functions_values_arduino_pin'].':</b> '.$_SESSION["schedule"]["command_pin"][$item].'<br>
		<b>'.$_SESSION['lang_date_set'].':</b> '.$_SESSION["schedule"]["date_start"][$item].' - '.$_SESSION["schedule"]["date_end"][$item].'<br>
		<b>'.$_SESSION['lang_timing'].'</b>&nbsp;&nbsp;&nbsp;Start ';
		
		if ($_SESSION["schedule"]["time_at"][$item] == '0')
			$ret_string.=$_SESSION["schedule"]["time_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["time_end"][$item].'<br>';
		else
			$ret_string.=$_SESSION["schedule"]["time_at"][$item].'<br>';
		
		if ($_SESSION["schedule"]["start_stop"][$item] =='')
		{
			$ret_string.='<b>'.$_SESSION['lang_functions_values_action_values'].'</b>&nbsp;&nbsp;&nbsp;Start: ';
			$ret_string.=($_SESSION["schedule"]["action_start"][$item] == 0) ? 'LOW' : 'HIGH';
		}
		else
		{
			$ret_string.='
			<b>'.$_SESSION['lang_functions_values_start_at'].':</b> '.str_ireplace("$","#",$_SESSION["schedule"]["start_stop"][$item]);
		}
		
		if ($_SESSION["schedule"]["start_stop"][$item] =='')
		{
		$ret_string.='&nbsp;&nbsp;&nbsp;Stop: ';
		if ($_SESSION["schedule"]["action_end"][$item] > 1)  
			$ret_string.=$_SESSION["schedule"]["action_end"][$item];
		else
			$ret_string.=($_SESSION["schedule"]["action_end"][$item] == 0) ? 'LOW' : 'HIGH';
		}
		
		$ret_string.='<br>
		<b>'.$_SESSION['lang_days'].'</b> ';
		$giorni=explode('@',$_SESSION["schedule"]["days"][$item]);
		if (count($giorni)-1 > 0)
		{
			for ($x=0; $x < count($giorni)-1; $x++)
			$ret_string.= $_SESSION["giorni_name"][$giorni[$x]].' ';
		}
		else
		$ret_string.=($_SESSION["schedule"]["days"][$item] == 7) ? $_SESSION['lang_all'] : $_SESSION['lang_none'];
		
		$ret_string.='<br>
		<b>'.$_SESSION['lang_functions_values_control_watch'].'</b>&nbsp;&nbsp;&nbsp;Start: '.$_SESSION["schedule"]["watch_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["watch_stop"][$item];
		#'STATO CORRENTE<br>'.
		#'Running :'.$_SESSION["schedule"]["flag_action"][$item].'  dalle ore :'.$_SESSION["schedule"]["date_time_started"][$item].'<br>'.
		#'Ultimo passaggio :'.$_SESSION["schedule"]["last"][$item].'  Tempo trascordo dall"avvio :'.$_SESSION["schedule"]["elapse"][$item];
		return $ret_string;
	}
	
	function values_pin_in_survey($item)
	{
		$ret_string='
		<b><font size="2">*'.$_SESSION["survey"]["name"][$item].'</font></b><br>
		<b>'.$_SESSION['lang_command'].' : </b>'.$_SESSION["survey"]["command"][$item].'<br>
		<b> Human Read : </b>'.$_SESSION["survey"]["human"][$item].'<br>
		<b>'.$_SESSION['lang_sampling_time'].' : </b>'.$_SESSION["survey"]["elapse"][$item].' sec.<br>
		<b>'.$_SESSION['lang_functions_values_arduino_control_pin'].' : </b>'.$_SESSION["survey"]["control_d_a"][$item].$_SESSION["survey"]["control_pin"][$item].'<br>
		<b>'.$_SESSION['lang_operator'].' : </b>'.$_SESSION["survey"]["control_operator"][$item] .'<b> '.$_SESSION['lang_compare_value'].' : </b>'.$_SESSION["survey"]["control_value"][$item].'<br>
		<div>
		<div style="float:left">
		<b>'.$_SESSION['lang_action_label'].'</b><br>
		<b>Pin : </b>'.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'<b>   Set : </b> '.$_SESSION["survey"]["action_set_pin"][$item].'<b>
		Value : </b>';
		if ($_SESSION["survey"]["action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["action_value"][$item];
		else
		$ret_string.=($_SESSION["survey"]["action_value"][$item] == 0) ? 'LOW' : 'HIGH';
		$ret_string.='
		</div>
		<div style="float:left;padding-left:20px;">
		<b>'.$_SESSION['lang_reaction_label'].'</b><br>
		<b>Pin : </b>'.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'<b>   Set : </b> '.$_SESSION["survey"]["re_action_set_pin"][$item].'<b>   Value : </b> ';
		
		if ($_SESSION["survey"]["re_action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["re_action_value"][$item];
		else
		$ret_string.=($_SESSION["survey"]["re_action_value"][$item] == 0) ? 'LOW' : 'HIGH';
		$ret_string.='</div></div><div style="clear:both;">';
		$ret_string.='
		<b>'.$_SESSION['lang_status'].' : </b>';
		$ret_string.=($_SESSION["survey"]["flag_action"][$item] == 0)? 'Not Running':'Running';
		return $ret_string;
	}	
?>