<?php
	session_start();
	if ($_SESSION['schedule']['name'][0]=='')
	{
		echo "Nessuno SCHEDULE presente!";
		die();
	}
	if (!$_SESSION['schedule_running'])
		$_SESSION['schedule_running']=true;
		
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
	include_once("include_send.php");
	$risposta="";
	$from_schedule=true;
	$check_cond=false;
	
	$d_conf= strval(date("w"));
	//echo "datew ".$d_conf."<br>";
	
	
	for ($arr_len=0;$arr_len < 21; $arr_len++)
	{
		if ($_SESSION['schedule']['name'][$arr_len]=='')
		break;
		
		if (($_SESSION['schedule']['enable'][$arr_len]!='s') && ($_SESSION['schedule']['flag_action'][$arr_len]=='0'))
		{
			$risposta.=$risposta."<br>". date('H:i')." - Sched. ".$_SESSION['schedule']['name'][$arr_len]." DISABILITATO.&&";
			continue;
		}
		## CONTROLLIAMO CHE I PIN CONTROL E ACTION NON SIANO DISABILITATI
		## SE SONO DISABILITATI LI ABILITIAMO COMUNQUE
		//  il comando e' dxx oppure axx  oppure pxx
		// substr($_SESSION['schedule']['command'][$arr_len],0,1)  e' il tipo di pin //
		// substr($_SESSION['schedule']['command'][$arr_len],1)  e' il numero di pin //
		
		if ((substr($_SESSION['schedule']['command_pin'][$arr_len],0,1)=='a') && ($_SESSION['val_analog_pin']['stato'][substr($_SESSION['schedule']['command'][$arr_len],1)]==-1))
		{
			$risposta.="<br>". $data_tempo[1]." Controllo ".($arr_len+1) ." non effettuato.
			Il pin di schedule ".substr($_SESSION['schedule']['command'][$arr_len],1)." non e' abilitato!&&";
			break;
		}
		if ((substr($_SESSION['schedule']['command_pin'][$arr_len],0,1)=='d') && ($_SESSION['val_digital_pin']['stato'][substr($_SESSION['schedule']['command'][$arr_len],1)]==-1))
		{
			$risposta.="<br>". $data_tempo[1]." Controllo ".($arr_len+1) ." non effettuato.
			Il pin di schedule ".substr($_SESSION['schedule']['command'][$arr_len],1)." non e' abilitato!&&";
			break;
		}
		
		$data_ora=time();

		if ($_SESSION['schedule']['command_pin'][$arr_len]!='')
		{
			$check_cond=false;
			$giorni=explode("@",$_SESSION['schedule']['days'][$arr_len]);
			
			//echo "session_days ".$_SESSION['schedule']['days'][$arr_len]."<br>";
			if (count($giorni) == 1)
				$check_cond= ($giorni[0] == 8) ? false : true;
			else
			{
				###  vediamo se il giorno e' nella lista
				###  date(w) lavora con domenica = 0.......noi con lunedi'=0
				//echo "qui".strpos($_SESSION['schedule']['days'][$arr_len],$d_conf);
				if (strpos($_SESSION['schedule']['days'][$arr_len],$d_conf)>-1)
					{
						$check_cond=true;
					}
				if (!$check_cond)
				continue;
			}	

			//echo "fuori<br>";
			$t0=explode(":",date('H:i'));
			$d0=explode(":",date('d:m:Y'));
			$t1=explode(":",$_SESSION['schedule']['time_start'][$arr_len]);
			$d1=explode(":",$_SESSION['schedule']['date_start'][$arr_len]);
			$t2=explode(":",$_SESSION['schedule']['time_end'][$arr_len]);
			$d2=explode(":",$_SESSION['schedule']['date_end'][$arr_len]);
			
			## check se siamo nella validita' dello schedule, cioe' se la data di adesso e' compresa tra date_start e date_end
			$to_start=((mktime(0,0,0,$d0[1],$d0[0],$d0[2]) > mktime(0,0,0,$d1[1],$d1[0],$d1[2]) ) || (mktime(0,0,0,$d0[1],$d0[0],$d0[2]) < mktime(0,0,0,$d2[1],$d2[0],$d2[2])) ) ? true : false;
			$to_stop=((mktime(0,0,0,$d0[1],$d0[0],$d0[2]) > mktime(0,0,0,$d2[1],$d2[0],$d2[2]) )) ? true : false;
			
			### ORARI
			if ($t1[0] > $t2[0])
			{
				//echo "T1 > T2<BR>------------------------------------<BR>";
				//echo $_SESSION['schedule']['name'][$arr_len]."<br>";
				//echo "------------------------------------<BR>";
				//echo "time_start ".$_SESSION['schedule']['time_start'][$arr_len]."<br>";
				//echo "time_end ".$_SESSION['schedule']['time_end'][$arr_len]."<br>";
				//echo "------------------------------------<BR>";
				$time_corr=mktime($t0[0],$t0[1],0,0,0,0);		#23
				$time_start_corr=mktime($t1[0],$t1[1],0,0,0,0);    	#20
				$time_end_corr=mktime($t2[0],$t2[1],0,0,0,0);		#9
				//echo "t0 ".$time_corr."<br> t1 ".$time_start_corr."<br> t2 ".$time_end_corr;
				//echo "<br>differenza".($time_corr - $time_start_corr)."<br>";
				if ($time_corr > $time_start_corr)
				{
					//echo "<br>time_corr > time_start_corr<br>";
					$to_start=($time_corr >= $time_start_corr) ? true : false;					
				}
				else
				{
					//echo "<br>time_corr - time_start_corr <0 <br>";
					if ((($time_corr - $time_start_corr) <0) && ($time_corr < $time_end_corr))
					{
						$to_start=true;
						$to_stop=($time_corr >= $time_end_corr) ? true : false;			
					}
					else
					{
						//echo "qui<br>";
						$to_start=false;
						$to_stop=true;
					}
				}
			}
			else
			{
				####   CONDIZIONE NORMALE QUANDO LA DATA DI FINE E' MAGGIORE DELLA DATA DI INIZIO
				//echo "T2 > T1<BR>------------------------------------<BR>";
				//echo $_SESSION['schedule']['name'][$arr_len]."<br>";
				//echo "------------------------------------<BR>";
				//echo "time_start ".$_SESSION['schedule']['time_start'][$arr_len]."<br>";
				//echo "time_end ".$_SESSION['schedule']['time_end'][$arr_len]."<br>";
				//echo "-------------------------------------<BR>";
				$t0_corr=mktime($t0[0],$t0[1],0,0,0,0);		#23
				$t1_corr=mktime($t1[0],$t1[1],0,0,0,0);    	#20
				$t2_corr=mktime($t2[0],$t2[1],0,0,0,0);		#9
				
				$to_start=(($t0_corr >= $t1_corr) && ($t0_corr <= $t2_corr )) ? true : false;
				$to_stop =( $t0_corr > $t2_corr) ? true : false;
				
			}	
			
			//echo "<br> start:".$to_start."   stop:".$to_stop."<br>";
			
			#forziamo to_stop=true  se e' intervenuto un disable durante il running
			if (($_SESSION['schedule']['enable'][$arr_len]!='s') && ($_SESSION['schedule']['flag_action'][$arr_len]==1))
			{
				$to_start=false;
				$to_stop=true;
			}
			
			if(($to_start) || ($to_stop)) 
			{
				if ((($to_start) && ($_SESSION['schedule']['flag_action'][$arr_len]!="1")) || (($to_stop) && ($_SESSION['schedule']['flag_action'][$arr_len]=="1")))
				{
					## PREPARIAMO L'AZIONE
					$opt= ($to_start) ? 
					$_SESSION['schedule']['command_pin'][$arr_len]."#1".$_SESSION['schedule']['action_start'][$arr_len] :
					$_SESSION['schedule']['command_pin'][$arr_len]."#1".$_SESSION['schedule']['action_end'][$arr_len];
					
					$readval=send_value($opt);
					
					$read_val_array=explode("%",$readval);
					
					$risposta.="<br>". date('H:i')." - Sched. ".
					$_SESSION['schedule']['name'][$arr_len];
					$risposta.=($to_start) ? " ATTIVATO" : " DISATTIVATO";
					$risposta.=
					"#".$_SESSION['schedule']['command_pin'][$arr_len].
					"#".$read_val_array[0].
					"#".$read_val_array[1]."%";
					$risposta.=($to_start) ? $_SESSION['schedule']['action_start'][$arr_len]."&&" : $_SESSION['schedule']['action_end'][$arr_len]."&&";
					$_SESSION['schedule']['flag_action'][$arr_len] = ($to_start) ? "1" : "0";
					$_SESSION['schedule']['elapsed'][$arr_len] ="00:00";
					$_SESSION['schedule']['date_time_started'][$arr_len] = mktime($t0[0],$t0[1],0,0,0,0);
				}
				else
				{
					## SCHEDULE RUNNING ##
					if ($_SESSION['schedule']['flag_action'][$arr_len]=="1")
					{
						// AGGIORNIAMO ANCHE ELAPSE COME TEMPO TRASCORSO DALL'ATTIVAZIONE DEL CONTROLLO//
						$_SESSION['schedule']['elapsed'][$arr_len] =	mktime($t0[0],$t0[1],0,0,0,0)- $_SESSION['schedule']['date_time_started'][$arr_len];
						
						//$_SESSION['schedule']['date_time_started'][$arr_len])) / 3600))/0.01666);
						$_SESSION['schedule']['last'][$arr_len] = date('d:m:y')."<br>".date('H:i:s');
						$risposta.="<br>". date('H:i')." Sched. ".
						$_SESSION['schedule']['name'][$arr_len]." RUNNING!&&";
					}
				}
				
				}
			}
		}
		if ($_POST['log'] == "s")
		{
			//$_SESSION['logfile']="dati/log.txt";
			//$_SESSION['logfile_open_mode']="a+";
			if (!$_SESSION['log_open'])
			$_SESSION['log_file'] = fopen($_SESSION['logfile'], $_SESSION['logfile_open_mode']);
			
			fwrite($_SESSION['log_file'], "SCHEDULE  ** ".$risposta."\n");
		}
		echo $risposta;
	?>							