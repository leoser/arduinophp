<?php
	session_start();
	if ($_SESSION['schedule']['name'][0]=='')
	{
		echo $_SESSION['lang_no_schedule_present'];
		die();
	}
	if (!$_SESSION['schedule_running'])
	$_SESSION['schedule_running']=true;
	
	include_once("include_send.php");
	include("dati/timezone_".$_SESSION['lang'].".php");
	
	$risposta="";
	$from_schedule=true;
	$check_cond=false;
	
	$d_conf= strval(date("w"));
	//echo "datew ".$d_conf."<br>";
	
	for ($arr_len=0;$arr_len < 21; $arr_len++)
	{
		$by_watch=false;
		if ($_SESSION['schedule']['name'][$arr_len]=='')
		break;
		
		if (($_SESSION['schedule']['enable'][$arr_len]!='s') && ($_SESSION['schedule']['flag_action'][$arr_len]=='0'))
		{
			$risposta.=$risposta."<br>". date('H:i')." - Sched. ".$_SESSION['schedule']['name'][$arr_len]." ".$_SESSION['lang_disabled']."&&";
			continue;
		}
		
		## CONTROLLIAMO CHE I PIN CONTROL E ACTION NON SIANO DISABILITATI
		## SE SONO DISABILITATI LI ABILITIAMO COMUNQUE
		//  il comando e' dxx oppure axx  oppure pxx
		// substr($_SESSION['schedule']['command'][$arr_len],0,1)  e' il tipo di pin //
		// substr($_SESSION['schedule']['command'][$arr_len],1)  e' il numero di pin //
		
		
		if ((substr($_SESSION['schedule']['command_pin'][$arr_len],0,1)=='a') && ($_SESSION['val_analog_pin']['stato'][substr($_SESSION['schedule']['command_pin'][$arr_len],1)]==-1))
		{
			$risposta.="<br>". date('H:i')." ".$_SESSION['lang_schedule_label']." ".$_SESSION['schedule']['name'][$arr_len]." ".$_SESSION['lang_not_done_schedule'].".".
			$_SESSION['lang_schedule_ref_pin']." ".substr($_SESSION['schedule']['command_pin'][$arr_len],1)." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!&&";
			continue;
		}
		if ((substr($_SESSION['schedule']['command_pin'][$arr_len],0,1)=='d') && ($_SESSION['val_digital_pin']['stato'][substr($_SESSION['schedule']['command_pin'][$arr_len],1)]==-1))
		{
			$risposta.="<br>". date('H:i')." ".$_SESSION['lang_schedule_label']." ".$_SESSION['schedule']['name'][$arr_len] ." ".$_SESSION['lang_not_done_schedule'].".".
			$_SESSION['lang_schedule_ref_pin']." ".substr($_SESSION['schedule']['command_pin'][$arr_len],1)." ".$_SESSION['lang_is_not']." ".$_SESSION['lang_enabled']."!&&";
			continue;
		}
		$data_ora=time();
		
		if ($_SESSION['schedule']['command_pin'][$arr_len]!='')
		{
			$check_cond=false;
			$giorni=explode("@",$_SESSION['schedule']['days'][$arr_len]);
			
			//echo "session_days ".$_SESSION['schedule']['days'][$arr_len]."<br>";
			if (count($giorni) == 1)
			$check_cond= ($giorni[0] == 8) ? false : true;
			else
			{
				###  vediamo se il giorno e' nella lista
				###  date(w) lavora con domenica = 0.......noi con lunedi'=0
				//echo "qui".strpos($_SESSION['schedule']['days'][$arr_len],$d_conf);
				if (strpos($_SESSION['schedule']['days'][$arr_len],$d_conf)>-1)
				{
					$check_cond=true;
				}
				if (!$check_cond)
				continue;
			}	
			
			//echo "fuori<br>";
			$t0=explode(":",date('H:i'));
			$d0=explode(":",date('d:m:Y'));
			$t1=explode(":",$_SESSION['schedule']['time_start'][$arr_len]);
			$d1=explode(":",$_SESSION['schedule']['date_start'][$arr_len]);
			$t2=explode(":",$_SESSION['schedule']['time_end'][$arr_len]);
			$d2=explode(":",$_SESSION['schedule']['date_end'][$arr_len]);
			$dead=((mktime(0,0,0,$d0[1],$d0[0],$d0[2]) > mktime(0,0,0,$d2[1],$d2[0],$d2[2]) )) ? true : false;
			if ($dead)
			{
				$risposta.="<br>". date('H:i')." ". $_SESSION['lang_schedule_label']." ".$_SESSION['schedule']['name'][$arr_len]." ".$_SESSION['lang_expired']."!&&";
				continue;
			}
			
			## check se siamo nella validita' dello schedule, cioe' se la data di adesso e' compresa tra date_start e date_end
			$to_start=((mktime(0,0,0,$d0[1],$d0[0],$d0[2]) > mktime(0,0,0,$d1[1],$d1[0],$d1[2]) ) || (mktime(0,0,0,$d0[1],$d0[0],$d0[2]) < mktime(0,0,0,$d2[1],$d2[0],$d2[2])) ) ? true : false;
			$to_stop=((mktime(0,0,0,$d0[1],$d0[0],$d0[2]) > mktime(0,0,0,$d2[1],$d2[0],$d2[2]) )) ? true : false;
			
			$reply_check="";
			## CHECK STATUS OF WATCH STOP ATTACHED
			if (($_SESSION['schedule']['watch_stop'][$arr_len]) && ($_SESSION['schedule']['flag_action'][$arr_len] ==1))
			{
				$reply_check=check_watch($_SESSION['schedule']['watch_stop'][$arr_len]);
				if ($reply_check!="")
				{
					$_SESSION['schedule']['flag_action'][$arr_len] ==1;
					$reply_check="<br>". date('H:i')." ". $_SESSION['lang_schedule_label']." ".$_SESSION['schedule']['name'][$arr_len]." stopped by WATCH.".$reply_check;
					$to_start=false;
					$to_stop=true;
					$by_watch=true;
				}
			}
			## CHECK STATUS OF WATCH START ATTACHED
			#forziamo to_start=true  se il watch di start e' vero
			if (($_SESSION['schedule']['watch_start'][$arr_len]) && ($_SESSION['schedule']['flag_action'][$arr_len] ==0))
			{
				$reply_check=check_watch($arr_len);
				if ($reply_check!="")
				{
					$_SESSION['schedule']['flag_action'][$arr_len] =0;
					$reply_check="<br>". date('H:i')." ". $_SESSION['lang_schedule_label']." ".$_SESSION['schedule']['name'][$arr_len]." started by WATCH.".$reply_check;
					$to_start=true;
					$to_stop=false;
					$by_watch=true;
				}
			}
			
			### ORARI   saltiamomo se e' il watch che ha definito lo start o lo stop
			if (!$by_watch)
			{
				if ($_SESSION['schedule']['time_at'][$arr_len] == "")
				{
					$by_time_at="";
					if ($t1[0] >= $t2[0])
					{
						//echo "T1 > T2<BR>------------------------------------<BR>";
						//echo $_SESSION['schedule']['name'][$arr_len]."<br>";
						//echo "------------------------------------<BR>";
						//echo "time_start ".$_SESSION['schedule']['time_start'][$arr_len]."<br>";
						//echo "time_end ".$_SESSION['schedule']['time_end'][$arr_len]."<br>";
						//echo "------------------------------------<BR>";
						$time_corr=mktime($t0[0],$t0[1],0,0,0,0);		#23
						$time_start_corr=mktime($t1[0],$t1[1],0,0,0,0);    	#20
						$time_end_corr=mktime($t2[0],$t2[1],0,0,0,0);		#9
						//echo "t0 ".$time_corr."<br> t1 ".$time_start_corr."<br> t2 ".$time_end_corr;
						//echo "<br>differenza".($time_corr - $time_start_corr)."<br>";
						
						if ($time_corr > $time_start_corr)
						{
							//echo "<br>time_corr > time_start_corr<br>";
							$to_start=($time_corr >= $time_start_corr) ? true : false;					
						}
						else
						{
							//echo "<br>time_corr - time_start_corr <0 <br>";
							if ((($time_corr - $time_start_corr) <0) && ($time_corr < $time_end_corr))
							{
								$to_start=true;
								$to_stop=($time_corr >= $time_end_corr) ? true : false;			
							}
							else
							{
								//echo "qui<br>";
								$to_start=false;
								$to_stop=true;
							}
						}
					}
					else
					{
						####   CONDIZIONE NORMALE QUANDO LA DATA DI FINE E' MAGGIORE DELLA DATA DI INIZIO
						//echo "T2 > T1<BR>------------------------------------<BR>";
						//echo $_SESSION['schedule']['name'][$arr_len]."<br>";
						//echo "------------------------------------<BR>";
						//echo "time_start ".$_SESSION['schedule']['time_start'][$arr_len]."<br>";
						//echo "time_end ".$_SESSION['schedule']['time_end'][$arr_len]."<br>";
						//echo "-------------------------------------<BR>";
						$t0_corr=mktime($t0[0],$t0[1],0,0,0,0);		#23
						$t1_corr=mktime($t1[0],$t1[1],0,0,0,0);    	#20
						$t2_corr=mktime($t2[0],$t2[1],0,0,0,0);		#9
						
						$to_start=(($t0_corr >= $t1_corr) && ($t0_corr <= $t2_corr )) ? true : false;
						$to_stop =( $t0_corr > $t2_corr) ? true : false;
						
					}	
				}
				else
				{
					$to_start=false;
					$by_time_at=true;
					if ($t0[0].":".$t0[1] == $_SESSION['schedule']['time_at'][$arr_len])
					{
						$to_start=true;
					}
				}
			}
			//echo "<br> start:".$to_start."   stop:".$to_stop."<br>";
			
			
			#forziamo to_stop=true  se e' intervenuto un disable durante il running
			if (($_SESSION['schedule']['enable'][$arr_len]!='s') && ($_SESSION['schedule']['flag_action'][$arr_len]==1))
			{
				$to_start=false;
				$to_stop=true;
			}
			
			
			if(($to_start) || ($to_stop)) 
			{
				if (!$by_time_at)
				{
				if ((($to_start) && ($_SESSION['schedule']['flag_action'][$arr_len]!="1")) || (($to_stop) && ($_SESSION['schedule']['flag_action'][$arr_len]=="1")))
				{
					## PREPARIAMO L'AZIONE
					$opt= ($to_start) ? 
					$_SESSION['schedule']['command_pin'][$arr_len]."#1".$_SESSION['schedule']['action_start'][$arr_len] :
					$_SESSION['schedule']['command_pin'][$arr_len]."#1".$_SESSION['schedule']['action_end'][$arr_len];
					$readval=send_value($opt);
					$read_val_array=explode("%",$readval);
					$risposta.="<br>". date('H:i')." - ". $_SESSION['lang_schedule_label']." ".
					$_SESSION['schedule']['name'][$arr_len];
					$risposta.=($to_start) ? " ".$_SESSION['lang_schedule_activated'].$reply_check : " ".$_SESSION['lang_schedule_disactivated'].$reply_check;					
					
					$risposta.=
					"#".$_SESSION['schedule']['command_pin'][$arr_len].
					"#".$read_val_array[0].
					"#".$read_val_array[1]."%";
					$risposta.=($to_start) ? $_SESSION['schedule']['action_start'][$arr_len]."&&" : $_SESSION['schedule']['action_end'][$arr_len]."&&";
					$_SESSION['schedule']['flag_action'][$arr_len] = ($to_start) ? "1" : "0";
					$_SESSION['schedule']['elapsed'][$arr_len] ="00:00";
					$_SESSION['schedule']['date_time_started'][$arr_len] = mktime($t0[0],$t0[1],0,0,0,0);
				}
				else
				{
					## SCHEDULE RUNNING ##
					if ($_SESSION['schedule']['flag_action'][$arr_len]=="1")
					{
						// AGGIORNIAMO ANCHE ELAPSE COME TEMPO TRASCORSO DALL'ATTIVAZIONE DEL CONTROLLO//
						$_SESSION['schedule']['elapsed'][$arr_len] =	mktime($t0[0],$t0[1],0,0,0,0)- $_SESSION['schedule']['date_time_started'][$arr_len];
						
						//$_SESSION['schedule']['date_time_started'][$arr_len])) / 3600))/0.01666);
						$_SESSION['schedule']['last'][$arr_len] = date('d:m:y')."<br>".date('H:i:s');
						$risposta.="<br>". date('H:i')." ". $_SESSION['lang_schedule_label']." ".
						$_SESSION['schedule']['name'][$arr_len]." RUNNING!&&";
					}
				}
			}
			else
				{
					if ($to_start)
					{
					##  dobbiamo fare lo start e lo stop del run
					## PREPARIAMO L'AZIONE che e' nei comandi rapidi
					$opt=$_SESSION['shortcut']['command'][$_SESSION['schedule']['start_stop'][$arr_len]];
					$readval=WriteSS($opt);
					sleep(1);
					//$read_val_array=explode("%",$readval);
					$risposta.="<br>". date('H:i')." - ". $_SESSION['lang_schedule_label']." ".
					$_SESSION['schedule']['name'][$arr_len]." ".$_SESSION['lang_schedule_activated']."/".$_SESSION['lang_schedule_disactivated'] ." ".$_SESSION['lang_by_time_at']." (rcode=".$readval.")";
					
					//$risposta.=
					//"#".$_SESSION['schedule']['command_pin'][$arr_len].
					//"#".$read_val_array[0].
					//"#".$read_val_array[1]."%";
					//$risposta.=($to_start) ? $_SESSION['schedule']['action_start'][$arr_len]."&&" : $_SESSION['schedule']['action_end'][$arr_len]."&&";
					$_SESSION['schedule']['flag_action'][$arr_len] ="0";
					$_SESSION['schedule']['elapsed'][$arr_len] ="00:01";
					$_SESSION['schedule']['date_time_started'][$arr_len] = mktime($t0[0],$t0[1],0,0,0,0);
					$_SESSION['schedule']['last'][$arr_len] = date('d:m:y')."<br>".date('H:i:s');
					}
					else
						echo "not started";
				}
			}
		}
	}
	if ($_POST['log'] == "s")
	{
		//$_SESSION['logfile']="dati/log.txt";
		//$_SESSION['logfile_open_mode']="a+";
		if (!$_SESSION['log_open'])
		$_SESSION['log_file'] = fopen($_SESSION['logfile'], $_SESSION['logfile_open_mode']);
		$risposta_log=str_ireplace("<br>"," ",$risposta);
		$risposta_log=str_ireplace("&&","",$risposta_log);
		fwrite($_SESSION['log_file'], "SCHEDULE  ** ".$risposta_log."\n");
	}
	echo $risposta;
	
	function check_watch($pos_control)
	{
		$ret_value="";
		$postfix=($_SESSION['survey']['control_d_a'][$pos_control] =="a") ? 0 : 1;
		####################  COSTRUZIONE PACCHETTO   #########################
		$packet=$_SESSION['survey']['control_d_a'][$pos_control].
		$_SESSION['survey']['control_pin'][$pos_control]."#".$postfix;
		#################################################################
		$readval=send_value($packet);
		$read_val_array=explode("%",$readval);
		switch ($_SESSION['survey']['control_operator'][$pos_control])
		{
			case ">":
			$check_cond=(int)$read_val_array[0] > (int)$_SESSION['survey']['control_value'][$pos_control];
			break;
			
			case "<":
			$check_cond=(int)$read_val_array[0] < (int)$_SESSION['survey']['control_value'][$pos_control];
			break;
			
			case "=":
			$check_cond=(int)$read_val_array[0] == (int)$_SESSION['survey']['control_value'][$pos_control];
			break;
			
			default:
			$check_cond=(int)$read_val_array[0] > (int)$_SESSION['survey']['control_value'][$pos_control];
			break;
		}
		$control=
		$_SESSION['survey']['control_d_a'][$pos_control].
		$_SESSION['survey']['control_pin'][$pos_control].
		$_SESSION['survey']['control_operator'][$pos_control].
		$_SESSION['survey']['control_value'][$pos_control];
		$pin_to_print =	$_SESSION['survey']['control_d_a'][$pos_control].
		$_SESSION['survey']['control_pin'][$pos_control];
		if ($check_cond)
		{
			##  PREPARIAMO IL MESSAGIO PER IL CHIAMANTE  O E' START O E' STOP
			$ret_value="<br>".date('H:i')." ".$_SESSION['lang_control_label']." ".($arr_len+1).") ".$control."<br>".
			$_SESSION['lang_pin_sampled']." ".$pin_to_print." :".$read_val_array[0]."  Watch :".$_SESSION['survey']['control_value'][$pos_control];
		}
	return $ret_value;
	}
	
	?>											