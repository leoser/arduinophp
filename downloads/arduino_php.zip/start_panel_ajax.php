<?php
	session_start();
	include("/lang/lang_".$_SESSION['lang'].".php");
	
	if ($_SESSION['level'] !="Admin")
	include($_SESSION['status_services']);
	
	function show_opt()
	{
		echo '<p name="SESSION_your_opt">'.$_SESSION['your_opt'].':<br>
		<font size="2">
		<ul>';
		for($x=0;$x<count($_SESSION['options_prog']);$x++)
		{
			if (substr($_SESSION['mask'],$x,1)== 1)
			echo "<li><a href='".$_SESSION['options_prog'][$x]."' target='".$_SESSION['options_window_name'][$x]."' onclick='close_services_for_app();' <span name='SESSION_lang_options$x'> ".$_SESSION['lang_options'][$x]."</span></a></li>";
			}
		echo "</ul></font></p>";
	}
?>
<html>
	<head>
		<title><?php echo $_SESSION['lang_core_page_title'];?></title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<!--script type="text/javascript" src="script/jquery-ui-timepicker-addon.js"></script-->
		<!--script type="text/javascript" src="script/jquery-ui-sliderAccess.js"></script-->
		
		<script>
		    // GLOBAL ARRAY_LANG and FILL IT with $_SESSION_lang
			window.array_lang =[];
			function fill_lang_array(lang)
			{
				$.ajax({
					type: "POST",
					url: "change_lang.php",
					data: 'lang='+lang+'&force=y',
					async: false,
					success: function(msg)
					{
						if (msg!='')
						window.array_lang = msg.split('@@@');
					},
					error: function(msg){
					}
				})
			}
			fill_lang_array('<?php echo $_SESSION['lang'];?>');
		</script>
		
		<link rel="stylesheet" href="css/base/jquery.ui.tabs.css">
		
		<style>
			body {margin-top:0; padding-top:0; font-family: arial; font-size:12px; }
			td { font-family: arial; font-size:12px; border:1px solid; vertical-align:top; }
			INPUT { font-family: arial; font-size:12px; }
			
			/* IE  */
			INPUT[type="text"] {font-family: Arial; font-size:12px}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		
		<?php include"jquery_services_e.php"; ?>
		
	</head>
	<body>
		<br>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>	
				<td style="border:none;" align="center" >
					<table width="50%" border="0">
						<tr>
							<td width="90%" style="border:none;">
								<span style="position:absolute;top:3px;">
								<img style="margin-top:10px;" id="img_lang_it" src="<?php echo ($_SESSION['lang']=='it') ?  'img/it.jpg': 'img/it_off.jpg';?>" onclick="change_array_lang('it');">&nbsp;<img style="margin-top:10px;"  id="img_lang_en" src="<?php echo($_SESSION['lang']=='en')? 'img/en.jpg':  'img/en_off.jpg';?>" onclick="change_array_lang('en');"></span>
							</span>
							<center><img src="img/quadro_small.jpg">
						</td>
					</tr>
					<tr>
						<td height="253"  bgcolor="#e2e2e2" >
							<font size="8"><center>
								<strong>DOMINO</strong>
							</center></font>
							
							<span id="welcome" name="SESSION_lang_pre_welcome"><?php echo $_SESSION['lang_pre_welcome'];?></span>
								<?php echo $_SESSION['level'];?>
							<span id="post_welcome" name="SESSION_lang_post_welcome"><?php echo $_SESSION['lang_post_welcome'];?></span>
							<?php echo gmstrftime("%d %b %a, %Y, %X time zone: %Z",time());?><br>
							Arduino on <b><?php echo $_SESSION['com'];?></b> (dati/config.php)
							
							<table border="0" width="100%">
											<tr>
											<?php echo $msg_port_header;?>
											<br>
										</tr>
										
										<?php 
											switch ($_SESSION['level'])
											{
												case "Admin":
												#echo "<tr><td width='50%'>";
												#echo ($_SESSION['start']) ? "<b>L'accesso esterno e' attivato</b></td>
												#<td><input type='button' id='button_stop_session' value='STOP'>
												#<input type='button' id='button_start_session' value='START' disabled>" : 
												#"<b>L'accesso esterno non e' attivato.</b></td>
												#<td><input type='button' id='button_stop_session' value='STOP' disabled>
												#<td><input type='button' id='button_start_session' value='START'></td>";
												#echo "</td></tr>";
												
												
												echo "<tr><td width='60%'>";
												echo ($_SESSION['watch_running']) ? 
												"<b><span name='SESSION_watch_running' id='watch_running'><span id='lang_watch_is_started' name='SESSION_lang_watch_is_started'>".$_SESSION['lang_watch_is_started'].".</span></span></b></td>
												<td><input type='button' id='button_stop_survey' name='SESSION_button_stop_survey' value='STOP'>
												<input type='button' id='button_start_survey' name='SESSION_button_start_survey' value='START' disabled>" : 
												"<b><span name='SESSION_watch_running' id='watch_running'><span id='lang_watch_is_not_started' name='SESSION_lang_watch_is_not_started'>".$_SESSION['lang_watch_is_not_started'].".</span></span></b></td>
												<td><input type='button' id='button_stop_survey' name='SESSION_button_stop_survey' value='STOP' disabled>
												<input type='button' id='button_start_survey' name='SESSION_button_start_survey' value='START'></td>";
												echo "</td></tr>";
												
												echo "<tr><td width='60%'>";
												echo ($_SESSION['schedule_running']) ? 
												"<b><span name='SESSION_schedule_running' id='schedule_running'><span id='lang_schedule_is_started' name='SESSION_lang_schedule_is_started'>".$_SESSION['lang_schedule_is_started'].".</span></span></b></td>
												<td><input type='button' id='button_stop_schedule' name='SESSION_button_stop_schedule' value='STOP'>
												<input type='button' id='button_start_schedule' name='SESSION_button_start_schedule' value='START' disabled>" : 
												"<b><span name='SESSION_schedule_running' id='schedule_running'><span id='lang_schedule_is_not_started' name='SESSION_lang_schedule_is_not_started'>".$_SESSION['lang_schedule_is_not_started'].".</span></span></b>
												<td><input type='button' id='button_stop_schedule' name='SESSION_button_stop_schedule' value='STOP' disabled>
												<input type='button' id='button_start_schedule' name='SESSION_button_start_schedule' value='START'></td>";
												echo "</td></tr></table>";
												
												show_opt();
												break;
												
												default:
												echo "<tr><td width='50%'>";
												echo ($_SESSION['com_port_open']) ? 
												"<b><span name='SESSION_lang_port_open_ok'>".$_SESSION['lang_port_open_ok'].".</span></b></td>" :
												"<b><span name='SESSION_lang_port_open_not_ok'>".$_SESSION['lang_port_open_not_ok'].".</span></b></td>";
												echo "</tr>";
												
												echo "<tr><td width='50%'>";
												echo ($_SESSION['start']) ? 
												"<b><span name='SESSION_lang_session_is_started'>".$_SESSION['lang_session_is_started'].".</span></b></td>" :
												"<b><span name='SESSION_lang_session_is_not_started'>".$_SESSION['lang_session_is_not_started'].".</span></b></td>";
												echo "</tr>";
												
												
												echo "<tr><td width='50%'>";
												echo ($_SESSION['watch_running']) ? 
												"<b><span name='SESSION_lang_watch_is_started'>".$_SESSION['lang_watch_is_started'].".</span></b></td>"	: 
												"<b><span name='SESSION_lang_watch_is_not_started'>".$_SESSION['lang_watch_is_not_started'].".</span></b></td>";
												echo "</tr>";
												
												echo "<tr><td width='50%'>";
												echo ($_SESSION['schedule_running']) ? 
												"<b><span name='SESSION_lang_schedule_is_started'>".$_SESSION['lang_schedule_is_started'].".</span></b></td>" : 
												"<b><span name='SESSION_lang_schedule_is_started'>".$_SESSION['lang_schedule_is_not_started'].".</span></b></td>";
												echo "</tr></table>";
												echo "<input type='button' value='Refresh' onclick='window.location.reload();'>";
												
												
												if (($_SESSION['start']) && ($_SESSION['com_port_open']))
												show_opt();
												else
												echo '<p>Sorry.'.$_SESSION['lang_try_later'].'<br></p>';
											}	
										?>
										<p>
											&nbsp;
										</p>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<form name="close_me" method="post" action="index.php">
					<input type="hidden" name="close_me" value="close">
				</form>
				<script>
					function close_services()
					{
						$("#button_stop_schedule").click();
						$("#button_stop_survey").click();
						$("#button_stop_session").click();
					}
					
					function close_services_for_app()
					{
					$("#button_stop_schedule").click();
					$("#button_stop_survey").click();
					//$("#button_stop_dump").click();
					}
					
					
					function change_array_lang(lang)
					{
					if (lang == 'it')
					{
					$('#img_lang_it').attr("src","img/it.jpg");
					$('#img_lang_en').attr("src","img/en_off.jpg");
					}
					else
					{
					$('#img_lang_it').attr("src","img/it_off.jpg");
					$('#img_lang_en').attr("src","img/en.jpg");
					}
					$.ajax({
					type: "POST",
					url: "change_lang.php",
					data: 'lang='+lang,
					async: false,
					success: function(msg)
					{
					if (msg!='')
					{
					window.array_lang = msg.split('@@@');
					change_lang_tags();
					}	
					
					},
					error: function(msg){
					}
					})
					}	
					
					function return_lang_string(string)
					{
						var ret_str='';
						/* cerca la stringa passata e restituisce la stringa nel linguaggio impostato */
						for (var i = 0; i < window.array_lang.length; i++) 
						{
							var n=window.array_lang[i].search(string);
							if (n > -1)
							{
								var a=window.array_lang[i].split('|');
								ret_str=a[1];
								break;
							}
						}
						return ret_str;
					}
					
					function change_lang_tags()
					{
						/* qui si devono andare a cambiare tutte le <span name="SESSION_lang_  e i val input*/
						for (var i = 0; i < array_lang.length; i++) 
						{
							if (array_lang[i].indexOf('|') >-1)
							{
								var a=array_lang[i].split('|');
								if (a[1] !='')
								{
									//$("input[@name=myname]"):
									var z="[name="+a[0]+"]";
									if (a[1].indexOf("array")>-1)
									{ 
									/* e' un array; dobbiamo ciclarne i valori e metterli nelle name*/
									var z_arr=a[1].substring(6).split(',');
										for (var x=0;x<z_arr.length;x++)
										{ 
										var z="[name="+a[0]+x+"]";
										$(z).html(z_arr[x].substring(1,z_arr[x].length-1));
										}
									}
									else
									{
									$(z).html(a[1]);
									$//(z).val(a[1]);
									}
									//ret_str=a[1];
								}
							}
						}
					}
					</script>
					</body>
					</html> 
										