<?php
	session_start();
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
	
	if ($_SESSION['level'] !="Admin")
	include($_SESSION['status_services']);
	
	function show_opt()
	{
		echo '<p>Queste sono le opzioni per il tuo livello:<br>
		<font size="2">
		<ul>';
		for($x=0;$x<count($_SESSION['options']);$x++)
		{
			if (substr($_SESSION['mask'],$x,1)== 1)
			echo "<li><a href='".$_SESSION['options_prog'][$x]."' target='".$_SESSION['options_window_name'][$x]."' onclick='close_services_for_app();'>".$_SESSION['options'][$x]."</a></li>";
		}
		echo "</ul></font></p>";
	}
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - CORE WINDOW</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<script type="text/javascript" src="script/jquery1-8.js"></script>
		<script type="text/javascript" src="script/jquery-ui1-9.js"></script>
		<script type="text/javascript" src="script/jquery-ui-timepicker-addon.js"></script>
		<script type="text/javascript" src="script/jquery-ui-sliderAccess.js"></script>

		<link rel="stylesheet" href="css/base/jquery.ui.tabs.css">

		<style>
			body {margin-top:0; padding-top:0; font-family: arial; font-size:12px; }
			td { font-family: arial; font-size:12px; border:1px solid; vertical-align:top; }
			INPUT { font-family: arial; font-size:12px; }
			
			/* IE  */
			INPUT[type="text"] {font-family: Arial; font-size:12px}
			
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
		
		<?php  include"jquery_services_e.php"; ?>
		
	</head>
	<body>
		<br>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>	
				<td style="border:none;" align="center" >
					<table width="50%" border="0">
						<tr>
							<td width="90%" style="border:none;">
								<img src="img/quadro.jpg">
							</td>
						</tr>
						<tr>
							<td height="253"  bgcolor="#e2e2e2" >
								<font size="8"><center>
									<strong>DOMINO</strong>
								</center></font>
								Benvenuto <?php echo $_SESSION['level'];?>.La data del server e' <?php echo(gmstrftime("%d %b %a, %Y, %X time zone: %Z",time()));?><br>
								<table border="0" width="65%">
									<tr>
									<?php echo $msg_port_header;?></b><br>
										
								</tr>
								
								
							
							<?php 
								switch ($_SESSION['level'])
								{
									case "Admin":
									#echo "<tr><td width='50%'>";
									#echo ($_SESSION['start']) ? "<b>L'accesso esterno e' attivato</b></td>
									#<td><input type='button' id='button_stop_session' value='STOP'>
									#<input type='button' id='button_start_session' value='START' disabled>" : 
									#"<b>L'accesso esterno non e' attivato.</b></td>
									#<td><input type='button' id='button_stop_session' value='STOP' disabled>
									#<td><input type='button' id='button_start_session' value='START'></td>";
									#echo "</td></tr>";
									
									
									
									echo "<tr><td width='50%'>";
									echo ($_SESSION['watch_running']) ? 
									"<b><span id='watch_running'>Il Watchdog e' avviato.</span></b></td>
									<td><input type='button' id='button_stop_survey' name='button_stop_survey' value='STOP'>
									<input type='button' id='button_start_survey' name='button_start_survey' value='START' disabled>" : 
									"<b><span id='watch_running'>Il Watchdog non e' avviato.</span></b>
									<td><input type='button' id='button_stop_survey' name='button_stop_survey' value='STOP' disabled>
									<input type='button' id='button_start_survey' name='button_start_survey' value='START'></td>";
									echo "</td></tr>";
									
									echo "<tr><td width='50%'>";
									echo ($_SESSION['schedule_running']) ? 
									"<b><span id='schedule_running'>Lo Schedule e' avviato.</span></b>
									<td><input type='button' id='button_stop_schedule' name='button_stop_schedule' value='STOP'>
									<input type='button' id='button_start_schedule' name='button_start_schedule' value='START' disabled>" : 
									"<b><span id='schedule_running'>Lo Schedule non e' avviato.</span></b>
									<td><input type='button' id='button_stop_schedule' name='button_stop_schedule' value='STOP' disabled>
									<input type='button' id='button_start_schedule' name='button_start_schedule' value='START'></td>";
									echo "</td></tr></table>";
									
									show_opt();
									break;
									
									default:
									echo "<tr><td width='50%'>";
									echo ($_SESSION['com_port_open']) ? 
									"<b><span>La com port e' aperta</span></b></td>" :
									"<b><span>La com port non e' aperta</span></b></td>";
									echo "</tr>";
									
									echo "<tr><td width='50%'>";
									echo ($_SESSION['start']) ? 
									"<b><span>La sessione e' avviata</span></b></td>" :
									"<b><span>La sessione non e' avviata</span></b></td>";
									echo "</tr>";
									
									
									echo "<tr><td width='50%'>";
									echo ($_SESSION['watch_running']) ? 
									"<b><span>Il Watchdog e' avviato.</span></b></td>"	: 
									"<b><span>Il Watchdog non e' avviato.</span></b></td>";
									echo "</tr>";
									
									echo "<tr><td width='50%'>";
									echo ($_SESSION['schedule_running']) ? 
									"<b><span>Lo Schedule e' avviato.</span></b></td>" : 
									"<b><span>Lo Schedule non e' avviato.</span></b></td>";
									echo "</tr>
									</table>";
									echo "<input type='button' value='Refresh' onclick='window.location.reload();'>";
									if (($_SESSION['start']) && ($_SESSION['com_port_open']))
										show_opt();
									else
										echo '<p>Sorry. La com port e/o la sessione non risultano attive.Try later!<br></p>';
								}	
							?>
							<p>
								&nbsp;
							</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<form name="close_me" method="post" action="index.php">
		<input type="hidden" name="close_me" value="close">
	</form>
	<script>
		function close_services()
		{
			$("#button_stop_schedule").click();
			$("#button_stop_survey").click();
			$("#button_stop_session").click();
		}
		
		function close_services_for_app()
		{
			$("#button_stop_schedule").click();
			$("#button_stop_survey").click();
			//$("#button_stop_dump").click();
		}
	</script>
</body>
</html> 
