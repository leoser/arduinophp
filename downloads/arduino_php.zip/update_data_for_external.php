<?php
	session_start();
	$counter=0;
	switch ($_POST['save'])
	{
		case 'sc':
		// save schedule for external  ogni 60 sec; e' comandato dal timer di jquery_schedule.php
		$array_stack="<?php\n$"."_SESSION['schedule']=array(\n";
		foreach($_SESSION['schedule'] as $key => $element)
		{
			$array_stack.="'".$key."'=>array(";
			foreach($element as $subkey => $subelement)
			{
				if (($key == 'flag_action') || ($key == 'date_time_started'))
					$quote="";
				else
					$quote="'";
				
				#if ($subelement!='')
				$array_stack.=$quote.$subelement.$quote;
				$array_stack.=($counter == 19) ? "":",";
				//$array_stack.=$quote.$subelement.$quote.",";
				$counter++;
			} 
			$array_stack.="),\n";
			$counter=0;
		}
		$array_stack.=");\n?>";
		file_put_contents($_SESSION['data_for_external_domo'], $array_stack);
		save_dump();
		echo "success";
		break;
		
		case 'su':
		// save survey for external  ogni 10 sec; e' comandato dal timer di jquery_survey.php
		$array_stack="<?php\n$"."_SESSION['survey']=array(\n";
		foreach($_SESSION['survey'] as $key => $element)
		{
			$array_stack.="'".$key."'=>array(";
			foreach($element as $subkey => $subelement)
			{
				if (($key == 'control_value') || ($key == 'flag_action') || ($key == 'elapse'))
					$quote="";
				else
					$quote="'";
				
				#if ($subelement!='')
				$array_stack.=$quote.$subelement.$quote;
				$array_stack.=($counter == 9) ? "":",";
				//$array_stack.=$quote.$subelement.$quote.",";
				$counter++;
			} 
			$array_stack.="),\n";
			$counter=0;
		}
		$array_stack.=");\n?>";
		file_put_contents($_SESSION['data_for_external_watch'], $array_stack);
		save_dump();
		echo "success";
		break;
	}
	
	function save_dump()
		{
		// save dump dei valori di sessione for external  ogni 2 minuti circa; e' comandato dal timer di start_panel.php e panel.phpj
		$arr_name=array('val_digital_pin','val_analog_pin','survey','schedule');
		$arr_limit=array('13','5','9','19');
		// DIGITAL
		$array_stack="<?php \n";
		for ($x=0;$x<4;$x++)
		{
		$counter=0;
		$array_stack.="$"."_SESSION['".$arr_name[$x]."']=array(\n";
		foreach($_SESSION[$arr_name[$x]] as $key => $element)
		{
			$array_stack.="'".$key."'=>array(";
			foreach($element as $subkey => $subelement)
			{
				switch ($x)
				{
				case 0:
					if (($key == 'stato') || ($key == 'valore'))
						$quote="";
					else
						$quote="'";
				break;
				case 1:
					if (($key == 'stato') || ($key == 'valore'))
						$quote="";
					else
						$quote="'";
				break;
				case 2:
					 if (($key == 'control_value') || ($key == 'flag_action') || ($key == 'elapse'))
					$quote="";
				else
					$quote="'";
				break;
				case 3:
				 if (($key == 'flag_action')  || ($key == 'date_time_started'))
					$quote="";
				else
					$quote="'"; 
				break;
				}	
				#if ($subelement!='')
				$array_stack.=$quote.$subelement.$quote;
				$array_stack.=($counter == $arr_limit[$x]) ? "":",";
				//$array_stack.=$quote.$subelement.$quote.",";
				$counter++;
			} 
			$array_stack.="),\n";
			$counter=0;
		}
		$array_stack.=");\n";
		}
		$array_stack.="\n?>";
		file_put_contents($_SESSION['data_for_external_session'], $array_stack);
	}
		
?>				