<?php
?>
<script>
	$(document).ready(function()
	{
		var ajax_cancelled_survey = false,opened=false;
		/* interval 10 sec */
		var Id_survey= null,refreshId_survey= null,interval_survey=5000,msg='';
		var window_realtime_watch="",window_watch_map="";
		$("#start_survey").click(function() {
			if (!opened)
			{
				$.ajax({
					type: "POST",
					url: "update_watch.php",
					data: "mode=0",
					async: false,
					success: function(msg){
					}
				});
				window_realtime_watch=window.open("watch10.php", 'window_realtime_watch');
				opened=true;
			}
			else
			$('#watch_running',window_realtime_watch.document).text('Running');
			
			$('#survey').html(' ');
			ajax_cancelled_survey=false;
			$("#watch_running").val('1');
			$('#start_survey').attr("disabled", true);
			$('#stop_survey').attr("disabled", false);
			$('#start_survey').val('*RUNNING');
			$('#stop_survey').val('STOP');
			Id_survey=setInterval(function() {
				data=($('#log_survey').is(':checked'))? 's' : 'n';
				refreshId_survey=$.ajax({
					type: "POST",
					url: "survey.php",
					async: false,
					data : "log="+data ,
					success: function(msg) {
						if (!ajax_cancelled_survey)
						{
							var newmsg="";
							// mettiamo in risposte tuti i messaggi arrivati (delimitati con &&)
							var risposte_arrivate = msg.split('&&');
							for (z=0;z<risposte_arrivate.length-1;z++)
							{
								var risposta_temp = risposte_arrivate[z].split('%');
								if (risposta_temp.length == 1)
								{
									newmsg+=risposte_arrivate[z];
								}
								else
								{	
									var was_digital=false;
									var risposta = risposta_temp[0].split('#');
									$('#msg_dialog').html(risposta_temp[1]);
									if (parseInt(risposta[2].substr(1)) > 13)
									{
										var was_digital=true;
										risposta[2]="a"+(parseInt(risposta[2].substr(1))-13).toString();
									}
									if (risposta.length < 5)
									{
										$("#valore_pin_"+risposta[1]).text(risposta[2]);
										$("#last_valore_pin_"+risposta[1]).html(risposta[3]);
									}
									else
									{
										$('#msg_dialog').html(risposta_temp[1]);
										if (risposta.length < 5)
										{
											$("#valore_pin_"+risposta[1]).text(risposta[2]);
											$("#last_valore_pin_"+risposta[1]).html(risposta[3]);
										}
										else
										{
											$("#valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).text(risposta[4]);
											$("#last_valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).html(risposta[5]);
											$("#valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text(risposta[3]);
											$("#last_valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).html(risposta[5]);
											(risposta[0].indexOf("WARNING")>0) ? $( '#green_'+risposta[1]).attr('src','img/red.png') : 	$( '#green_'+risposta[1]).attr('src','img/off.png');
											switch (risposta[2].charAt(0))
											{
												case 'a':
												$("#buttons_map_con_"+risposta[2]).hide();
												$("#block_map_"+risposta[2]).hide();
												$("#block_con_"+risposta[2]).hide();
												$("#send_"+risposta[2]).hide();
												$("#label_"+risposta[2]).hide();
												$("#block_send_"+risposta[2]).show();
												if ((was_digital) && ($('#slider_tipo_'+risposta[2]).val()==0))	
												$('#slider_tipo_'+risposta[2]).slider({value: 1 });
												
												$('#slider_hilo_'+risposta[2]).show();	
												break;
												
												case 'p':	
												risposta[2]="d"+risposta[2].substr(1)
												if ($("#block_pwm_"+risposta[2]).is(":hidden"))
												{
													$("#block_send_"+risposta[2]).hide();
													$("#block_pwm_"+risposta[2]).show();
													$('#slider_pwm_'+risposta[2]).show();
												}
												$('#slider_pwm_'+risposta[2]).slider({value:+risposta[3] });
												if ($('#slider_tipo_'+risposta[2]).val()==0)	
												$('#slider_tipo_'+risposta[2]).slider({value: 1 });
												break;
												
												case 'd':	
												/* se e' digitale potrebbe avere lo slider pwm attivo....orbiamolo*/
												//if (document.getElementById('block_pwm_'+risposta[2]).style.display=="block")
												if ($("#block_pwm_"+risposta[2]).is(":hidden"))
												{
													$("#block_pwm_"+risposta[2]).hide();
													$("#block_send_"+risposta[2]).show();
													if ($('#slider_tipo_'+risposta[2]).val()==0)	
													$('#slider_tipo_'+risposta[2]).slider({value: 0 });
													$('#slider_hilo_'+risposta[2]).show();	
												}
												$('#slider_hilo_'+risposta[2]).slider({value:+risposta[3] });
												break;
												
												default:
												break;		
											}
											
										}
									}
									newmsg+=risposta[0];
								}
							}
							$("#survey").html(newmsg);	
							// scriviamo i dati per le applicazioni esterne
							$.ajax({
								type: "POST",
								url: "update_data_for_external.php",
								data: "save=su",
								async: false,
								success: function(msg1){
									
								}
							});
						}
						
					},
					error: function(){
						$('#survey').html("<font color='red'> Com port down o errore di sintassi in survey.php.");
					}
				});
			}, interval_survey);
		});
		
		//stoppiamo
		$("#stop_survey").click(function() 
		{
			clearInterval(Id_survey);
			Id_survey=null;
			if (refreshId_survey!= null)
			{
				refreshId_survey.abort();
				refreshId_survey=null;
				ajax_cancelled_survey = true;
			}
			$('#stop_survey').attr("disabled", true);
			$('#start_survey').attr("disabled", false);
			$('#stop_survey').val('* STOPPED');
			$('#start_survey').val('START');
			$("#watch_running").val('0');
			$('#survey').text('WATCH STOPPED');
			
			opened=false;
			if (window_realtime_watch != "")
			{
				window_realtime_watch.close();
				window_realtime_watch="";
			}
			
			$.ajax({
				type: "POST",
				url: "update_watch.php",
				data: "watch= &mode=s",
				async: false,
				success: function(msg){
					/* risponde con tutti i pin resettati */
					if (msg !='')
					{
						var risposta=msg.split(';');
						for (var z=0; z < risposta.length-1; z++)
						{
							$("#valore_pin_"+risposta[z]).text('0');
							$("#green_"+risposta[z]).attr('src','img/off.png');
							//$("#last_valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).html(risposta[3]);
							//$('#light_'+risposta[1],domo.document).attr('src','img/lightbulb_on.png');
							//$("#valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text(risposta[3]);
							//$("#last_valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text=risposta[5];
							//(risposta[0].indexOf("WARNING")>0) ? $( '#green_'+risposta[1]).attr('src','img/red.png') : 	$( '#green_'+risposta[1]).attr('src','img/off.png');
							switch (risposta[z].charAt(0))
							{
								case 'a':
								$("#buttons_map_con_"+risposta[z]).show();
								$("#block_map_"+risposta[z]).hide();
								$("#block_con_"+risposta[z]).hide();
								$("#block_send_"+risposta[z]).hide();
								$('#slider_hilo_'+risposta[z]).hide();	
								$("#send_"+risposta[z]).show();
								$("#label_"+risposta[z]).show();
								break;
								
								case 'p':	
								risposta[z]="d"+risposta[z].substr(1)
								if ($("#block_pwm_"+risposta[z]).is(":hidden"))
								{
									$("#block_send_"+risposta[z]).hide();
									$("#block_pwm_"+risposta[z]).show();
									$('#slider_pwm_'+risposta[z]).show();
								}
								$('#slider_pwm_'+risposta[z]).slider({value:+risposta[3] });
								if ($('#slider_tipo_'+risposta[z]).val()==0)	
								$('#slider_tipo_'+risposta[z]).slider({value: 1 });
								break;
								
								case 'd':	
								/* se e' digitale potrebbe avere lo slider pwm attivo....orbiamolo*/
								//if (document.getElementById('block_pwm_'+risposta[2]).style.display=="block")
								if ($("#block_pwm_"+risposta[z]).is(":hidden"))
								{
									$("#block_pwm_"+risposta[z]).hide();
									$("#block_send_"+risposta[z]).show();
									if ($('#slider_tipo_'+risposta[z]).val()==0)	
									$('#slider_tipo_'+risposta[z]).slider({value: 0 });
									$('#slider_hilo_'+risposta[z]).show();	
								}
								$('#slider_hilo_'+risposta[z]).slider({value: 0 });
								break;
								
								default:
								break;	
							}
						}
					}
				},
				error: function(msg){
					
				}
			});
			
		});
		
		$("#save_watch").click(function() 
		{
			var string_watch=set_watch();
			var val_num_control=$("#watch_numbers_present").val();
			var val_mode_Array=string_watch.split(';');
			var val_position='';
			// se mode_watch e' blank allora e' un inserimento
			if ($("#watch_mode").val()=='')
			{
				if (val_num_control<10)
				{
					val_num_control++;
					val_position=val_num_control;
					var data= "watch=" + string_watch;
				}
				else
				{
					alert('Raggiunto il limite di controlli')
					return false;
				}
			}
			else
			{
				/* modifica o cancella zione */
				val_position=$("#watch_position").val();
				var data= "watch=" + string_watch +"&pos="+val_position+"&mode="+$("#watch_mode").val();
			}
			// Effettuo la chiamata Ajax a update_watch.php per mettere nella $_SESSION i valori
			$.ajax({
				type: "POST",
				url: "update_watch.php",
				data: data,
				async: false,
				success: function(msg){
					$('#msg_setup_watch').html(msg);
					human_watch=msg.split(';');
					if ($("#watch_mode").val()=='d')
					{
						// dobbiamo scalare il cancellato
						for (var x=parseInt(val_position);x<10;x++)
						{
							$('#name_watch_'+x).text($('#name_watch_'+parseInt(x+1)).text());
							$('#control_watch_'+x).text($('#control_watch_'+parseInt(x+1)).text());
							$('#elapse_watch_'+x).text($('#elapse_watch_'+parseInt(x+1)).text());
							$('#human_watch_'+x).text($('#human_watch_'+parseInt(x+1)).text());
						}
						$('#name_watch_10').text('');
						$('#control_watch_10').text('');
						$('#elapse_watch_10').text('10');
						$('#human_watch_10').text('');
						val_num_control--;
					}
					else
					{
						$('#name_watch_'+val_position).text(val_mode_Array[2]);
						$('#elapse_watch_'+val_position).text(val_mode_Array[1]);
						$('#human_watch_'+val_position).text(human_watch[1]);
						$('#control_watch_'+val_position).val(val_mode_Array[0])+";"+$('#elapse_watch_'+val_position).text()+";"+$('#name_watch_'+val_position).text();
						/* dobbiamo aggiornare la label del  watch */
						$.ajax({
							type: "POST",
							url: "functions_values.php",
							data: "item=" + val_position + "&mode=sv",
							async: false,
							success: function(msg1){
								$("#name_watch_"+val_position).attr('title', msg1);
							}
						});
					}
					$("#watch_numbers_present").val(val_num_control);
					$("#watch_position").val('');
					$("#watch_mode").val('');
					$("#message_table_watch").html("<u><font color='blue'>INSERIMENTO</font></u>/MODIFICA/CANCELLAZIONE CONTROLLI");
					$("#img_tabwatch_c").attr('src', 'img/c.png');
					$("#img_tabwatch_m").attr('src', 'img/m.png');
					panel_watch_clear();
					
					if (window_watch_map != "")
					window_watch_map.location.reload();
				},
				error: function(msg){
					$('#msg_setup_watch').html(msg);
					document.getElementById('watch_mode').value='';
					document.getElementById('watch_position').value='';
				}
			});
		});	
		
		$("#watch_map").click(function() 
		{
			window_watch_map=window.open("watch_map.php", 'window_watch_map');
		});
		
		$("#realtime_watch").click(function() 
		{
			window_realtime_watch=window.open("watch10.php", 'window_realtime_watch');
		});
		
		//if (<?php echo $watch_running;?> == 1)
		//	$("#start").click();
		//else
		//	$("#stop").click();
		
	});
	
	function set_watch()
	{
	var separator="#";
	string_watch='if'+separator;
	if ($("#c_type_d").is(':checked') )
	string_watch+="d"+separator;
	else if ($("#c_type_a").is(':checked') )
	string_watch+="a"+separator;
	else
	string_watch+="p"+separator;
	
	string_watch+=$("#c_numeropin").val()+separator;
	if ($("#c_\\=").is(':checked'))
	string_watch+='='+separator;
	else if ($("#c_lt").is(':checked'))
	string_watch+='<'+separator;
	else
	string_watch+='>'+separator;
	string_watch+=$("#c_val_compara").val()+separator;
	
	if ($("#a_type_d").is(':checked') )
	string_watch+="d"+separator;
	else if ($("#a_type_a").is(':checked') )
	string_watch+="a"+separator;
	else
	string_watch+="p"+separator;
	
	string_watch+=$("#a_numeropin").val()+separator;
	if ($("#a_high").is(':checked'))
	string_watch+='1#1'+separator;
	else  if ($("#a_low").is(':checked'))
	string_watch+='1#0'+separator;
	else
	string_watch+="1#"+$("#as_val_numeropin").val()+separator;
	if ($("#a_rst_high").is(':checked'))
	string_watch+='1#1'+separator;
	else if ($("#a_rst_low").is(':checked')) 
	string_watch+='1#0'+separator;
	else
	string_watch+="1#"+$("#as_rst_val_numeropin").val()+separator;
	/* ATTENZIONE!! il samplig e name passano con terminatore    ;    */
	string_watch+=";"+$("#sampling_val").val();
	string_watch+=";"+$("#nome_watch").val();
	return string_watch;
	}
	
	function panel_watch_clear()
	{
		$("#nome_watch").val('');
		$("#sampling_val").val('10');
		$("#c_type_d").attr('checked',false);
		$("#c_type_p").attr('checked',false);
		$("#c_type_a").attr('checked',true);
		$("#c_numeropin").val('');
		$("#c_gt").attr('checked',true);
		$("#c_lt").attr('checked',false);
		$("#c_\\=").attr('checked',false);
		$("#c_val_compara").val('');
		$("#a_type_d").attr('checked',true)
		$("#a_type_a").attr('checked',false)
		$("#a_type_p").attr('checked',false)
		$("#a_numeropin").val('');
		$("#a_high").attr('checked',true)
		$("#a_low").attr('checked',false)
		$("#a_val").attr('checked',false)
		$("#as_val_numeropin").val('');
		$("#a_rst_low").attr('checked',true)
		$("#a_rst_high").attr('checked',false)
		$("#a_rst_val").attr('checked',false)
		$("#as_rst_val_numeropin").val('');
		$("#save_watch").val('SALVA');
		$('#slider_sampling_val').slider({value: 10 });
		$("#img_tabwatch_c").attr('src', 'img/c.png') ;
		$("#img_tabwatch_m").attr('src','img/m.png');
		$("#message_table_watch").html("<u><font color='blue'>INSERIMENTO</font></u>/MODIFICA/CANCELLAZIONE CONTROLLI");
		$('#val_set').hide();
		$('#val_rst_set').hide();
	}
	
	function mod_watch(a , mode)
	{
		$("#watch_mode").attr('value', mode);
		$("#watch_position").attr('value', a);
		var comp_Array = new Array("gt",'=',"lt");
		var command=$("#control_watch_"+a).val();
		if (command == '')
		return ;
		
		$("#sampling_val").val($("#elapse_watch_"+a).html());
		$("#nome_watch").val($("#name_watch_"+a).html());
		
		//0                                            7  8   9   10
		//if#a#3#&gt;#50#d#9#1#1#1#0
		var command_Array=command.split('#');
		
		if (command_Array[1]=='d')
		$("#c_type_d").attr('checked',true);
		else if (command_Array[1]=='a')
		$("#c_type_a").attr('checked',true);
		else
		$("#c_type_p").attr('checked',true);
		
		dropdown_filter("c",command_Array[1],command_Array[2]);
		if (command_Array[3] == "=")
		command_Array[3]="\\"+command_Array[3];
		
		for (x=0;x<3;x++)
		{
			if (command_Array[3].indexOf(comp_Array[x])>0)
			break;
		}		
		(x == 1 ? $("#c_\\"+comp_Array[x]).attr('checked',true): $("#c_"+comp_Array[x]).attr('checked',true)) ;
		$("#c_val_compara").val(command_Array[4]);
		
		if (command_Array[5]=='d')
		$("#a_type_d").attr('checked',true);
		else if (command_Array[5]=='a')
		$("#a_type_a").attr('checked',true) ;
		else
		$("#a_type_p").attr('checked',true) ;
		
		dropdown_filter("a",command_Array[5],command_Array[6]);
		
		if (command_Array[8] > 1)
		{
			$("#a_val").attr('checked',true);
			$("#as_val_numeropin").val(command_Array[8]);
		}
		else if (command_Array[8]==1)
		$("#a_high").attr('checked',true);
		else 
		$("#a_low").attr('checked',true);
		
		$('#val_set').hide();
		$('#val_rst_set').hide();
		if (command_Array[10] > 1)
		{
			$('#val_set').show();
			$('#val_rst_set').show();
			$("#a_rst_val").attr('checked',true);
			$("#as_rst_val_numeropin").val(command_Array[10]);
		}
		else if (command_Array[10]==1)
		$("#a_rst_high").attr('checked',true);
		else 
		$("#a_rst_low").attr('checked',true);
		$("#save_watch").val((mode =='d' ?  'ELIMINA' : 'SALVA'));
		$('#slider_sampling_val').slider({value: $("#sampling_val").val() });
		(mode =='d' ? $("#message_table_watch").html("INSERIMENTO/MODIFICA/<u><font color='blue'>CANCELLAZIONE</font></u> CONTROLLI") : $("#message_table_watch").html("INSERIMENTO/<u><font color='blue'>MODIFICA</font></u>/CANCELLAZIONE CONTROLLI"));
	}
	
</script>									