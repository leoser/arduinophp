<?php
?>
<script>
	$(document).ready(function()
	{
		$("#save_comando_rapido").click(function() 
		{
			var string_comando_rapido=set_comando_rapido();
			var val_num_comando_rapido=$("#comando_rapido_numbers_present").val();
			var val_mode_Array=string_comando_rapido.split(';');
			var val_position='';
			// se mode_comando_rapido e' blank allora e' un inserimento
			if ($("#comando_rapido_mode").val()=='')
			{
				if (val_num_comando_rapido<20)
				{
					val_num_comando_rapido++;
					val_position=val_num_comando_rapido;
					var data= "comando_rapido=" + string_comando_rapido;
				}
				else
				{
					alert("<?php echo $_SESSION['limits_of_command'];?>")
					return false;
				}
			}
			else
			{
				/* modifica o cancella zione */
				val_position=$("#comando_rapido_position").val();
				var data= "comando_rapido=" + string_comando_rapido +"&pos="+val_position+"&mode="+$("#comando_rapido_mode").val();
			}
			// Effettuo la chiamata Ajax a update_comando_rapido.php per mettere nella $_SESSION i valori
			$.ajax({
				type: "POST",
				url: "update_comandi_rapidi.php",
				data: data,
				async: false,
				success: function(msg){
					$('#msg_setup_comando_rapido').html(msg);
					human_comando_rapido=msg.split('@@');
					if ($("#comando_rapido_mode").val()=='d')
					{
						// dobbiamo scalare il cancellato
						for (x=parseInt(val_position);x<20;x++)
						{
							$('#name_comando_rapido_'+x).text($('#name_comando_rapido_'+parseInt(x+1)).text());
							$('#command_comando_rapido_'+x).text($('#command_comando_rapido_'+parseInt(x+1)).text());
						}
						$('#name_comando_rapido_20').text('');
						$('#command_comando_rapido_20').text('');
						val_num_comando_rapido--;
					}
					else
					{
						$('#name_comando_rapido_'+val_position).text(val_mode_Array[0]);
						$('#command_comando_rapido_'+val_position).text(val_mode_Array[1]);
					}
					$("#control_comando_rapido_"+val_position).val(val_mode_Array[0]+";"+val_mode_Array[1]);
					$("#img_tabcomando_rapido_s"+val_position).attr('onclick','send_value("'+val_mode_Array[1]+'")');
					$("#comando_rapido_numbers_present").val(val_num_comando_rapido);
					$("#comando_rapido_position").val('');
					$("#comando_rapido_mode").val('');
					$("#message_table_comando_rapido").html(return_lang_string('ins_mod_del_I_short'));
					$("#img_tabcomando_rapido_c").attr('src', 'img/c.png');
					$("#img_tabcomando_rapido_m").attr('src', 'img/m.png');
					panel_comando_rapido_clear();
					
				},
				error: function(msg){
					$('#msg_setup_comando_rapido').html(msg);
					document.getElementById('comando_rapido_mode').value='';
					document.getElementById('comando_rapido_position').value='';
				}
			});
		});	
		
	});
	
	function set_comando_rapido()
	{
		var separator=";";
		var string_comando_rapido= $("#nome_comando_rapido").val()+separator;
		string_comando_rapido+= $("#command_comando_rapido").val()+separator;
		return string_comando_rapido;
	}
	
	function panel_comando_rapido_clear()
	{
		$("#nome_comando_rapido").val('');
		$("#command_comando_rapido").val('');
		$("#message_table_comando_rapido").html(return_lang_string('ins_mod_del_I_short'));
		$("#save_comando_rapido").val(return_lang_string('save'));
	}
	
	function mod_comando_rapido(a , mode)
	{
		$("#comando_rapido_mode").attr('value', mode);
		$("#comando_rapido_position").attr('value', a);
		var command=$("#control_comando_rapido_"+a).val();
		if (command == '')
		return ;
		var command_Array=command.split(';');
		$("#nome_comando_rapido").val(command_Array[0]);
		$("#command_comando_rapido").val(command_Array[1]);
		$("#save_comando_rapido").val((mode =='d' ?  return_lang_string('delete') : return_lang_string('save')));
		(mode =='d' ? $("#message_table_comando_rapido").html(return_lang_string('ins_mod_del_D_short')) : $("#message_table_comando_rapido").html(return_lang_string('ins_mod_del_M_short')));
	}
	
</script>													