<?php
session_start();
$_SESSION['lang']=strtolower(substr($_REQUEST['lang'],0,2));
include("lang/lang_".$_SESSION['lang'].".php");

	function send_value($opt)
	{
		if (strrpos($opt, ";"))
			$commands=explode(";",$opt);
		else
			$commands[0]=$opt;
	
		## prima di inviare check connection con arduino per il ready
		##  inviamo * e attendiamo **
		##
		$content='{"items":  [{ ';
		$a=WriteSS("*");
		
		$a=ReadSS("");
		if (strrpos($a, "**") != 0)
		{
			$content.='"arduino_ready" : "'.$_SESSION['lang_arduino_not_ready'].'",';
		}
		else
			$content.='"arduino_ready" : "'.$_SESSION['lang_arduino_ready'].'",';
		
		for ($arr_len=0;$arr_len < count($commands); $arr_len++)
		{
			$orario=date('d-m-y')."-".date('h:i:s');
			# JSON ORARIO--------------------------------
			$content.='"date_time" : "'.$orario.'",';
			#----------------------------------------------
			$opt=$commands[$arr_len];
			$a_d_p_Array=explode("#",$opt);
			$ana_dig=substr($a_d_p_Array[0],0,1);
			$pin_no=(int)substr($a_d_p_Array[0], 1);
			$mode = substr($a_d_p_Array[1],0,1);
			$valore=substr($a_d_p_Array[1],1,10);
			
			//$packet='';
			######################################
			###    COSTRUZIONE PACCHETTO PER ANALOGICO 
			######################################
			//if (($ana_dig =='a') && ($_POST['data']))
			//{
				# se il pin e' analogico mandiamo anche map constrain e vref
				# se sono a zero non verranno considerati da arduino
				$map=explode(":",$_SESSION['val_analog_pin']['map'][$pin_no]);
				$constrain=explode(":",$_SESSION['val_analog_pin']['constrain'][$pin_no]);
			//	if (count($map)>0)
			//		$packet.="*".$map[0]."*".$map[1]."*".$map[2]."*".$map[3]."*";
			//	else
			//		$packet.="*****";
				
				##  qui ci andrebbe il vref, per adesso mettiamo 1 che e' DEFAULT ( 5v )
			//	$packet.="1";
				
			//	if (count($constrain)>0)
			//		$packet.="*".$constrain[0]."*".$constrain[1]."*";
			//	else
			//		$packet.="***";
			//	$opt.=$packet;
			//}
			#######################################################
			##  se il delay e' maggiore di 0 e' una ripetizione
			//if ($_POST['delay'] > 0)
			//	usleep($_POST['delay']);
			#######################################################
			
			# PRIMA DI MANDARE FACCIAMO UN CHECK SE IL PIN E' DISABILITATO
			# il check e' utile per le richieste inviate non dalla slider (che viene disabilita) ma da survey e dai comandi globali
			//$enabled=($ana_dig == "d") ? $_SESSION['val_digital_pin']['stato'][$pin_no] : $_SESSION['val_analog_pin']['stato'][$pin_no];
			
			//if ($enabled == 0)
			//{
				##  la write puo avere (per adesso) solo un errore nell'interpretazione zend_parse_parameters. risponde l'estensione
				$a=WriteSS($opt);
				if (strrpos($a, "-"))
				{
					$val=substr($a, strrpos($a,"-"));
					//if (count($commands) >0)
					//$_SESSION['msg_dialog'].=date('h:i:s').$_SESSION['lang_include_send_error_command']. $opt ." rc_EXT=".$val."  ";
					//else
					$_SESSION['msg_dialog'].=
					$content.='"from_extension" : "'.$_SESSION['lang_include_send_error_command']. $opt ." rc_EXT=".$val.'",';
				}
				else
				{
					//if (count($commands) >0)
					//$_SESSION['msg_dialog'].=date('h:i:s').$_SESSION['lang_include_send_command_sent']. $opt ." rc_EXT=".$a."  ";
					//else
					//$_SESSION['msg_dialog'].=date('h:i:s').$_SESSION['lang_include_send_command_sent']. $opt ." rc_EXT=".$a."  ";
					$content.='"from_extension" : "'.$_SESSION['lang_include_send_command_sent']. $opt ." rc_EXT=".$a.'",';
				}
				
				## cosa risponde arduino al comando? ##
				$a=ReadSS("");
				
				# la read puo' ritornare , oltre il return_code, anche il valore letto nel formato return_code;valore
				if (strrpos($a,";")!=0)
				{
					## c'e un valore;e' dopo il ; mettiamolo in val; il return_code e' prima del ;
					$val=(int)substr($a, strrpos($a, ";")+1);
					$a=substr($a, 0,strrpos($a, ";")-1);
				}
				else
				{
					## era una impostazione , non c'e val;
					$val=$valore;
				}
				$a=trim($a);
				$content.='"value" : "'.$val.'", "rcode" :"'.$a.'",';
				
				## e' un digitale i pwm?
				if ($ana_dig =='p') 
					$ana_dig="d"; 
				
				## e' un analogico in digitale? 
				if ($pin_no > 13) 
					$ana_dig="a"; 

								
				## aggioniamo gli array con valore ultima lettura e current_type
				if ($ana_dig == "d")
				{
					$_SESSION['val_digital_pin']['valore'][$pin_no]=$val;
					$_SESSION['val_digital_pin']['last'][$pin_no]=$orario;
				}
				else
				{
					###  e' un analogico camuffato da digitale? 
					####   fare cambiare anche il current type ####
					($pin_no > 13) ? $_SESSION['val_analog_pin']['current_type'][($pin_no-14)]='d' : $_SESSION['val_analog_pin']['current_type'][$pin_no]='a';
					$pin_no=($pin_no > 13) ? $pin_no-14 : $pin_no ;
					$_SESSION['val_analog_pin']['valore'][$pin_no]=$val;
					$_SESSION['val_analog_pin']['last'][$pin_no]=$orario;
				}
				
				//$_SESSION['msg_dialog'].= date()."=> Arduino reply: rc=$a  value:$val<br>";
				$content.='"arduino_reply" : " Arduino reply: rc='.$a.' value: '.$val.'"}';
			//}
			//else
			//{
				## il pin e' disabilitato. dobbiamo comunque rimandare i valori e quindi usiamo quelli correnti negli array
			//	$val=($ana_dig == "d") ? $_SESSION['val_digital_pin']['valore'][$pin_no] : $_SESSION['val_analog_pin']['valore'][$pin_no];
			//	$orario=($ana_dig == "d") ? $_SESSION['val_digital_pin']['last'][$pin_no] : $_SESSION['val_analog_pin']['last'][$pin_no];
			//	$a="-";
			//	$_SESSION['msg_dialog'].= date()." Pin n. ".$pin_no. $_SESSION['include_send_is_disabled'].$_SESSION['command'].$opt. $_SESSION['include_send_not_sended']. $opt ." rc=$a  value:$val<br>";
			//}	
			
			//$ret_val=$val."%".$orario."%".$_SESSION['msg_dialog'];

			return $content.']}';
		}	
	}

	function values_pin_in_schedule($item)
	{
		$ret_string='*'.$_SESSION["schedule"]["name"][$item].'\n
'.$_SESSION['lang_functions_values_arduino_pin'].': '.$_SESSION["schedule"]["command_pin"][$item].'<br>
'.$_SESSION['lang_date_set'].': '.$_SESSION["schedule"]["date_start"][$item].' - '.$_SESSION["schedule"]["date_end"][$item].'\n
'.$_SESSION['lang_timing'].'&nbsp;&nbsp;&nbsp;Start ';

		if ($_SESSION["schedule"]["time_at"][$item] == '0')
			$ret_string.=$_SESSION["schedule"]["time_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["time_end"][$item].'\n';
		else
			$ret_string.=$_SESSION["schedule"]["time_at"][$item].'\n';
		
		if ($_SESSION["schedule"]["start_stop"][$item] =='')
		{
			$ret_string.=''.$_SESSION['lang_functions_values_action_values'].'&nbsp;&nbsp;&nbsp;Start: ';
			$ret_string.=($_SESSION["schedule"]["action_start"][$item] == 0) ? 'LOW' : 'HIGH';
		}
		else
		{
			$ret_string.=''.$_SESSION['lang_functions_values_start_at'].': '.str_ireplace("$","#",$_SESSION["schedule"]["start_stop"][$item]);
		}
		
		if ($_SESSION["schedule"]["start_stop"][$item] =='')
		{
		$ret_string.='&nbsp;&nbsp;&nbsp;Stop: ';
		if ($_SESSION["schedule"]["action_end"][$item] > 1)  
			$ret_string.=$_SESSION["schedule"]["action_end"][$item];
		else
			$ret_string.=($_SESSION["schedule"]["action_end"][$item] == 0) ? 'LOW' : 'HIGH';
		}
		$ret_string.='\n'.$_SESSION['lang_days'].' ';
		$giorni=explode('@',$_SESSION["schedule"]["days"][$item]);
		if (count($giorni)-1 > 0)
		{
			for ($x=0; $x < count($giorni)-1; $x++)
				$ret_string.= $_SESSION["giorni_name"][$giorni[$x]].' ';
		}
		else
			$ret_string.=($_SESSION["schedule"]["days"][$item] == 7) ? $_SESSION['lang_all'] : $_SESSION['lang_none'];

		$ret_string.='\n'.$_SESSION['lang_functions_values_control_watch'].'&nbsp;&nbsp;&nbsp;Start: '.$_SESSION["schedule"]["watch_start"][$item].'&nbsp;&nbsp;&nbsp;Stop: '.$_SESSION["schedule"]["watch_stop"][$item];
#'STATO CORRENTE<br>'.
#'Running :'.$_SESSION["schedule"]["flag_action"][$item].'  dalle ore :'.$_SESSION["schedule"]["date_time_started"][$item].'\n'.
#'Ultimo passaggio :'.$_SESSION["schedule"]["last"][$item].'  Tempo trascordo dall"avvio :'.$_SESSION["schedule"]["elapse"][$item];
		return $ret_string;
	}
	
	function values_pin_in_survey($item)
	{
$ret_string='

*'.$_SESSION["survey"]["name"][$item].'-'.$_SESSION['lang_command'].' : '.$_SESSION["survey"]["command"][$item].'\n
 Human Read : '.$_SESSION["survey"]["human"][$item].'\n
'.$_SESSION['lang_sampling_time'].' : '.$_SESSION["survey"]["elapse"][$item].' sec.\n
'.$_SESSION['lang_functions_values_arduino_control_pin'].' : '.$_SESSION["survey"]["control_d_a"][$item].$_SESSION["survey"]["control_pin"][$item].'\n
'.$_SESSION['lang_operator'].' : '.$_SESSION["survey"]["control_operator"][$item] .' '.$_SESSION['lang_compare_value'].' : '.$_SESSION["survey"]["control_value"][$item].'\n
'.$_SESSION['lang_action_label'].'
Pin : '.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'   Set :  '.$_SESSION["survey"]["action_set_pin"][$item].'
Value : ';
	if ($_SESSION["survey"]["action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["action_value"][$item];
	else
		$ret_string.=($_SESSION["survey"]["action_value"][$item] == 0) ? 'LOW' : 'HIGH';
	$ret_string.='\n'.$_SESSION['lang_reaction_label'].' Pin : '.$_SESSION["survey"]["action_d_a"][$item].$_SESSION["survey"]["action_pin"][$item].'   Set :  '.$_SESSION["survey"]["re_action_set_pin"][$item].'   Value :  ';
	if ($_SESSION["survey"]["re_action_value"][$item] > 1)  
		$ret_string.=$_SESSION["survey"]["re_action_value"][$item];
	else
		$ret_string.=($_SESSION["survey"]["re_action_value"][$item] == 0) ? 'LOW' : 'HIGH';
	$ret_string.='\n'.$_SESSION['lang_status'].' : ';
	$ret_string.=($_SESSION["survey"]["flag_action"][$item] == 0)? 'Not Running':'Running';
return $ret_string;
}

	function array2json($arr) { 
    if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality. 
    $parts = array(); 
    $is_list = false; 

    //Find out if the given array is a numerical array 
    $keys = array_keys($arr); 
    $max_length = count($arr)-1; 
    if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
        $is_list = true; 
        for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
            if($i != $keys[$i]) { //A key fails at position check. 
                $is_list = false; //It is an associative array. 
                break; 
            } 
        } 
    } 

    foreach($arr as $key=>$value) { 
		
        if(is_array($value)) { //Custom handling for arrays 
            if($is_list) $parts[] = array2json($value); /* :RECURSION: */ 
            else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */ 
        } else { 
            $str = ''; 
            if(!$is_list) $str = '"' . $key . '":'; 
            //Custom handling for multiple data types 
            if(is_numeric($value)) $str .= $value; //Numbers 
            elseif($value === false) $str .= 'false'; //The booleans 
            elseif($value === true) $str .= 'true'; 
            else $str .= '"' . addslashes($value) . '"'; //All other things 
            // :TODO: Is there any more datatype we should be in the lookout for? (Object?) 

            $parts[] = $str; 
        } 
    } 
    $json = implode(',',$parts); 
     
    if($is_list) return '[' . $json . ']';//Return numerical JSON 
    return '{' . $json . '}';//Return associative JSON 
}


$content="";
switch ($_REQUEST['s'])
{
	case 'pwd':
		$content=file_get_contents("dati/pwd.txt");
		break;
		
	case 'control':
		include ("dati/data_for_external_session.php");
		$content=send_value($_REQUEST['command']);
		break;
		
	case 'status':
		$get_content=file_get_contents("dati/status_services.php");
		$content='{"items":  [ ';
		$get_content=str_ireplace("<?php","",$get_content);
		$get_content=str_ireplace("\$_SESSION['",'{ "',$get_content);
		$get_content=str_ireplace("']",'" : ',$get_content);
		$get_content=str_ireplace("=" , '" ',$get_content);
		$get_content=str_ireplace(";",'"},',$get_content);
		$get_content=str_ireplace("?>",'',$get_content);
		$get_content.= '{"none" : "none" }';
		$content.=$get_content."]}";
		break;
		
	case 'domo_coords':
		$get_coords=file_get_contents("dati/map_domo.txt");
		$get_coords=explode("@@",$get_coords);
		$content='{"items":  [ ';
		for ($x=0;$x<count($get_coords)-1;$x++)
			{
				$items=explode("#",$get_coords[$x]);
				$content.='{ "pin" : "'.$items[0].'", "left" :"'.$items[1].'", "top" :"'.$items[2].'"}';
				if ($x < count($get_coords)-2)
					$content.=",";
			}
		$content.=']}';

		break;
		
	case 'watch_coords':
		$get_coords=file_get_contents("dati/map_watch.txt");
		$get_coords=explode("@@",$get_coords);
		$content.='{"items":  [ ';
		for ($x=0;$x<count($get_coords)-1;$x++)
			{
				$items=explode("#",$get_coords[$x]);
				$content.='{ "pin" : "'.$items[0].'", "left" :"'.$items[1].'", "top" :"'.$items[2].'"}';
				if ($x < count($get_coords)-2)
					$content.=",";
			}
		$content.=']}';
		break;
	
	case 'domo':
		$content=file_get_contents("dati/status_services.php");
		if ( (strpos($content,"start']=false") >-1) || (strpos($content,"schedule_running']=false") >-1))
		{
			if (stripos($content,"SESSION['start']=false") > -1)
			{
				$content=$_SESSION['lang_schedule_is_not_started'];
			}
			else if (stripos($content,"SESSION['schedule_running']=false") > -1)
			{
				$content=$_SESSION['lang_schedule_is_not_started'];
			}
		}
		else
		{
			session_start();
			include ("dati/data_for_external_session.php");
			include ("dati/data_for_external_domo.php");
			## prepariamo la json string
			$active=0;
			while ($_SESSION[schedule][name][$active]!='') 
				$active++;
			$content='{"items":  [ ';
			
			for ($x=0;$x<$active;$x++)
				{
				$rows=1;
				$content.='{';
				foreach($_SESSION[schedule] as $key=>$value) 
				{
					$content.='"'.$key.'" : "'.$value[$x].'",';
					//$content.=($rows == count(array_keys($_SESSION[survey]))) ? '' :',';
					$rows++;

				}
				$content.= '"valore" : "';
				$content.= $_SESSION[val_digital_pin][valore][substr($_SESSION[schedule][command_pin][$x],1)] ;
				$content.= '"';
				$content.=($x<$active-1) ? "}," : "}";
				//$content.="<br>";
			}
			$content.=']}';
		}
		break;	
		
	case 'survey':
		$content=file_get_contents("dati/status_services.php");
		
		if ( (strpos($content,"start']=false") >-1) || (strpos($content,"watch_running']=false") >-1))
		{
			if (stripos($content,"SESSION['start']=false") > -1)
			{
				$content=$_SESSION['lang_watch_is_not_started'];
			}
			else if (stripos($content,"SESSION['watch_running']=false") > -1)
			{
				$content=$_SESSION['lang_watch_is_not_started'];
			}
		}
		else
		{
			session_start();
			include ("dati/data_for_external_session.php");
			include ("dati/data_for_external_watch.php");
			## prepariamo la json string
			$active=0;
			while ($_SESSION[survey][name][$active]!='') 
				$active++;
			$content='{"items":  [ ';
			
			for ($x=0;$x<$active;$x++)
				{
				$rows=1;
				$content.='{';
				foreach($_SESSION[survey] as $key=>$value) 
				{
					$content.='"'.$key.'" : "'.$value[$x].'",';
					//$content.=($rows == count(array_keys($_SESSION[survey]))) ? '' :',';
					$rows++;

				}
				$content.= '"valore" : "';
				$content.=($_SESSION[survey][control_d_a][$x] =="a") ? $_SESSION[val_analog_pin][valore][$_SESSION[survey][control_pin][$x]] : $_SESSION[val_digital_pin][valore][$_SESSION[survey][control_pin][$x]] ;
				$content.= '"';
				$content.=($x<$active-1) ? "}," : "}";
				//$content.="<br>";
				
			}
			$content.=']}';
		}
		break;	
		
	case 'dump':
		$content=file_get_contents("dati/status_services.php");
		if ( (strpos($content,"start']=false") >-1) || (strpos($content,"dump_running']=false") >-1))
		{
			if (stripos($content,"SESSION['start']=false") > -1)
			{
				$content=$_SESSION['lang_dump_is_not_started'];
			}
			else if (stripos($content,"SESSION['dump_running']=false") > -1)
			{
				$content=$_SESSION['lang_dump_is_not_started'];
				$content=json_encode($_SESSION[survey]);
			}
		}
		else
		{
			session_start();
			include ("dati/data_for_external_session.php");
			$content=json_encode($_SESSION['val_digital_pin']);
			$content.=json_encode($_SESSION['val_analog_pin']);
			$content.=json_encode($_SESSION[survey]);
			$content.=json_encode($_SESSION[schedule]);

		}
		break;
		
	default:
		break;
	}
	
print $content;

?> 