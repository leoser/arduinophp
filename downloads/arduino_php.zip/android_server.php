<?php
session_start();
//$databasehost = "localhost";
//$databasename = "php_control";
//$databaseusername ="root";
//$databasepassword = "";
$query = file_get_contents("php://input"); 
//$sth = mysql_query($query);
//if (mysql_errno()) { 
//    header("HTTP/1.1 500 Internal Server Error");
//  echo $query.'\n';
// echo mysql_error(); 
//}
//else
//{
//   $rows = array();
//    while($r = mysql_fetch_assoc($sth)) {
//        $rows[] = $r;
//    }
//    print json_encode($rows);
//}
?> 