<?php
	session_start();
	include("/lang/lang_".$_SESSION['lang'].".php");
	switch ($_POST['type'])
	{
		case "s":
		$to_search="SESSION['schedule']";
		$array_to_work_to="schedule";
		break;
		
		case "w":
		$to_search="SESSION['survey']" ;
		$array_to_work_to="survey";
		break;
		
		case "c":
		$to_search="SESSION['comandi_rapidi']" ;
		$array_to_work_to="comandi_rapidi";
		break;
	} 	
	
	$file_content = file_get_contents($_SESSION['configfile']);
	$array_stack=explode("\n",$file_content);
	$indice=0;
	
	if ($_POST['mode'] =="s")
	{
		while ($indice <= count($array_stack) )
		{ 
			if (stripos($array_stack[$indice],$to_search)>-1)
			{
				$indice++;
				foreach($_SESSION[$array_to_work_to] as $key => $element)
				{
					$array_stack[$indice]="'".$key."'=>array(";
					foreach($element as $subkey => $subelement)
					{
						if (($key == 'control_value') || ($key == 'flag_action') || ($key == 'watch_start') || ($key == 'watch_stop') || ($key == 'date_time_started'))
						$quote="";
						else
						$quote="'";
						
						if (($key == 'elapse') && ($array_to_work_to=="schedule")) 
						$quote="";
						else
						$quote="'";
						
						//if ($subelement!='')
						$array_stack[$indice].=$quote.$subelement.$quote.",";
					} 
					$array_stack[$indice].="),";
					$indice++;
				}
			}
			$indice++;
		}	
		$file_content = implode("\n", $array_stack);
		file_put_contents($_SESSION['configfile'], $file_content);
		echo "Array ".$array_to_work_to." ".$_SESSION['saved'];
	}
	else
	{ 
		// il load non e' ancora scritto;
			while ($indice <= count($array_stack) )
			{ 
				if (stripos($array_stack[$indice],$to_search))
				{
					$indice++;
					foreach($_SESSION[$array_to_work_to] as $key => $element)
					{
						$array_stack[$indice]="'".$key."'=>array(";
						foreach($element as $subkey => $subelement)
						{
							if (($key == 'control_value') || ($key == 'flag_action') || ($key == 'elapse'))
							$quote="";
							else
							$quote="'";
							//if ($subelement!='')
							$array_stack[$indice].=$quote.$subelement.$quote.",";
						} 
						$array_stack[$indice].="),";
						$indice++;
					}
				}
				$indice++;
			}	
		}
	?>					