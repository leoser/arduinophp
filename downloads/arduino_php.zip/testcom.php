<?php
$msg_port.="<select>";
for ($z=1;$z <= 20; $z++)
{
$fp = fopen('COM'.$z, 'r');
	if($fp)
	{
		$msg_port.="<option value=".$z.">Port COM".$z." ".$_SESSION['lang_available'].".</option>";
		fclose($fp);
	}
}
$msg_port.="</select>";
if ($_POST['from_ajax'])
	echo $msg_port;
?>