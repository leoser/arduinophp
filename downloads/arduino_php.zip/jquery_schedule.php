<?php
?>
<script>
	$(document).ready(function()
	{
		var ajax_cancelled_schedule = false,opened=false;
		/* interval 1 minuto scarso */
		var Id_schedule = null,refreshId_schedule = null,interval_schedule=59000,msg_schedule='';
		var window_realtime_domo="", window_domo_map="";
		$("#start_schedule").click(function() {
			if (!opened)
			{
				$.ajax({
					type: "POST",
					url: "update_schedule.php",
					data: "mode=0",
					async: false,
					success: function(msg){
					}
				});
				window_realtime_domo=window.open("domo60.php", 'window_realtime_domo');
				opened=true;
			}
			else
			$('#schedule_running',window_realtime_domo.document).text('Running');
			
			$('#schedule').html(' ');
			ajax_cancelled_schedule=false;
			$("#schedule_running").val('1');
			$('#start_schedule').attr("disabled", true);
			$('#stop_schedule').attr("disabled", false);
			$('#start_schedule').val('*RUNNING');
			$('#stop_schedule').val('STOP');
			Id_schedule=setInterval(function() {
				data=($('#log_schedule').is(':checked'))? 's' : 'n';
				refreshId_schedule=$.ajax({
					type: "POST",
					url: "schedule.php",
					async: false,
					data : "log="+data ,
					success: function(msg_schedule) {
						if (!ajax_cancelled_schedule)
						{
							var newmsg="";
							// mettiamo in risposte tuti i messaggi arrivati (delimitati con &&)
							var risposte_arrivate = msg_schedule.split('&&');
							for (z=0;z<risposte_arrivate.length-1;z++)
							{
								var risposta_temp = risposte_arrivate[z].split('%');
								if (risposta_temp.length == 1)
								{
									newmsg+=risposte_arrivate[z];
								}
								else
								{	
									var was_digital=false;
									var risposta = risposta_temp[0].split('#');
									$('#msg_dialog').html(risposta_temp[0]);
									if (parseInt(risposta[1].substr(1)) > 13)
									{
										var was_digital=true;
										risposta[1]="a"+(parseInt(risposta[1].substr(1))-13).toString();
									}
									
									$('#msg_dialog').html(risposta_temp[0]);
									//$("#valore_pin_"+risposta[1]).text(risposta[2]);
									//$("#last_valore_pin_"+risposta[1]).html(risposta[3]);
									
									$("#valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).text(risposta[2]);
									$("#last_valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).html(risposta[3]);
									$('#light_'+risposta[1],window_realtime_domo.document).attr('src','img/lightbulb_on.png');
									//$("#valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text(risposta[3]);
									//$("#last_valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text=risposta[5];
									//(risposta[0].indexOf("WARNING")>0) ? $( '#green_'+risposta[1]).attr('src','img/red.png') : 	$( '#green_'+risposta[1]).attr('src','img/off.png');
									switch (risposta[1].charAt(0))
									{
										case 'a':
										$("#buttons_map_con_"+risposta[1]).hide();
										$("#block_map_"+risposta[1]).hide();
										$("#block_con_"+risposta[1]).hide();
										$("#send_'"+risposta[1]).hide();
										$("#label_'"+risposta[1]).hide();
										$("#block_send_"+risposta[1]).show();
										if ((was_digital) && ($('#slider_tipo_'+risposta[1]).val()==0))	
										$('#slider_tipo_'+risposta[1]).slider({value: 1 });
										
										$('#slider_hilo_'+risposta[1]).show();	
										break;
										
										case 'p':	
										risposta[1]="d"+risposta[1].substr(1)
										if ($("#block_pwm_"+risposta[1]).is(":hidden"))
										{
											$("#block_send_"+risposta[1]).hide();
											$("#block_pwm_"+risposta[1]).show();
											$('#slider_pwm_'+risposta[1]).show();
										}
										$('#slider_pwm_'+risposta[1]).slider({value:+risposta[2] });
										if ($('#slider_tipo_'+risposta[1]).val()==0)	
										$('#slider_tipo_'+risposta[1]).slider({value: 1 });
										break;
										
										case 'd':	
										/* se e' digitale potrebbe avere lo slider pwm attivo....orbiamolo*/
										//if (document.getElementById('block_pwm_'+risposta[2]).style.display=="block")
										if ($("#block_pwm_"+risposta[2]).is(":hidden"))
										{
											$("#block_pwm_"+risposta[2]).hide();
											$("#block_send_"+risposta[2]).show();
											if ($('#slider_tipo_'+risposta[2]).val()==0)	
											$('#slider_tipo_'+risposta[2]).slider({value: 0 });
											$('#slider_hilo_'+risposta[2]).show();	
										}
										$('#slider_hilo_'+risposta[1]).slider({value:+risposta[2] });
										break;
										
										default:
										break;		
									}
									newmsg+=risposta[0];
								}
							}
							$("#schedule").html(newmsg);	
							// scriviamo i dati per le applicazioni esterne
							$.ajax({
								type: "POST",
								url: "update_data_for_external.php",
								data: "save=sc",
								async: false,
								success: function(msg1){
									
								}
							});
						}
					},
					error: function(){
						$('#schedule').html(return_lang_string('com_down_error_schedule'));
					}
				});
			}, interval_schedule);
		});
		
		//stoppiamo
		$("#stop_schedule").click(function() 
		{
			clearInterval(Id_schedule);
			Id_schedule=null;
			if(refreshId_schedule != null ) 
			{
				refreshId_schedule.abort();
				refreshId_schedule=null;
				ajax_cancelled_schedule = true;
			}
			$('#stop_schedule').attr("disabled", true);
			$('#start_schedule').attr("disabled", false);
			$('#schedule').text('SCHEDULE STOPPED');
			$('#stop_schedule').val('* STOPPED');
			$('#start_schedule').val('START');
			$("#schedule_running").val('0');
			
			opened=false;
			if (window_realtime_domo != "")
			{
				window_realtime_domo.close();
				window_realtime_domo="";
			}
			
			/* andiamo a mettere  flag0 a tutti gli schedule */
			$.ajax({
				type: "POST",
				url: "update_schedule.php",
				data: "schedule= &mode=s",
				async: false,
				success: function(msg){
					/* risponde con tutti i pin resettati */
					if (msg !='')
					{
						var risposta=msg.split(';');
						for (var z=0; z < risposta.length-1; z++)
						{
							$("#valore_pin_"+risposta[z]).text('0');
							//$("#last_valore_pin_"+(risposta[1].charAt(0) =="p" ? "d"+risposta[1].substr(1): risposta[1])).html(risposta[3]);
							//$('#light_'+risposta[1],domo.document).attr('src','img/lightbulb_on.png');
							//$("#valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text(risposta[3]);
							//$("#last_valore_pin_"+(risposta[2].charAt(0) =="p" ? "d"+risposta[2].substr(1): risposta[2])).text=risposta[5];
							//(risposta[0].indexOf("WARNING")>0) ? $( '#green_'+risposta[1]).attr('src','img/red.png') : 	$( '#green_'+risposta[1]).attr('src','img/off.png');
							switch (risposta[z].charAt(0))
							{
								case 'a':
								$('#slider_hilo_'+risposta[z]).hide();	
								$("#buttons_map_con_"+risposta[z]).show();
								$("#block_map_"+risposta[z]).show();
								$("#block_con_"+risposta[z]).show();
								$("#send_'"+risposta[z]).show();
								$("#label_'"+risposta[z]).show();
								$("#block_send_"+risposta[z]).show();
								break;
								
								case 'p':	
								risposta[0]="d"+risposta[z].substr(1)
								$("#block_pwm_"+risposta[z]).hide();
								$('#slider_pwm_'+risposta[z]).hide();
								$("#block_send_"+risposta[z]).show();
								$('#slider_hilo_'+risposta[z]).show();	
								$('#slider_hilo_'+risposta[z]).slider({value: 0 });
								break;
								
								case 'd':	
								$("#block_pwm_"+risposta[z]).hide();
								$("#block_send_"+risposta[z]).show();
								$('#slider_hilo_'+risposta[z]).show();	
								$('#slider_hilo_'+risposta[z]).slider({value: 0 });
								break;
								
								default:
								break;		
							}
						}
					}
				},
				error: function(msg){
					
				}
			});
		});
		
		$("#save_schedule").click(function() 
		{
			var string_schedule=set_schedule();
			var val_num_schedule=$("#schedule_numbers_present").val();
			var val_mode_Array=string_schedule.split('#');
			var val_position='';
			// se mode_schedule e' blank allora e' un inserimento
			if ($("#schedule_mode").val()=='')
			{
				if (val_num_schedule<20)
				{
					val_num_schedule++;
					val_position=val_num_schedule;
					var data= "schedule=" + string_schedule;
				}
				else
				{
					alert(return_lang_string('lang_limits_of_schedule'));
					return false;
				}
			}
			else
			{
				/* modifica o cancella zione */
				val_position=$("#schedule_position").val();
				var data= "schedule=" + string_schedule +"&pos="+val_position+"&mode="+$("#schedule_mode").val();
			}
			// Effettuo la chiamata Ajax a update_schedule.php per mettere nella $_SESSION i valori
			$.ajax({
				type: "POST",
				url: "update_schedule.php",
				data: data,
				async: false,
				success: function(msg){
					$('#msg_setup_schedule').html(msg);
					human_schedule=msg.split('@@');
					if ($("#schedule_mode").val()=='d')
					{
						// dobbiamo scalare il cancellato
						for (x=parseInt(val_position);x<20;x++)
						{
							$('#name_schedule_'+x).text($('#name_schedule_'+parseInt(x+1)).text());
							$('#time_start_schedule_'+x).text($('#time_start_schedule_'+parseInt(x+1)).text());
							$('#time_end_schedule_'+x).text($('#time_end_schedule_'+parseInt(x+1)).text());
							$('#enabled_schedule_'+x).text($('#enabled_schedule_'+parseInt(x+1)).text());
							$('#control_schedule_'+x).attr('value',string_schedule);
						}
						$('#name_schedule_20').text('');
						$('#time_start_schedule_20').text('00:00');
						$('#time_end_schedule_20').text('00:00');
						$('#enabled_schedule_20').text('');
						$('#control_schedule_20').attr('value','');
						val_num_schedule--;
					}
					else
					{
						$('#name_schedule_'+val_position).text(val_mode_Array[0]);
						if (val_mode_Array[11]!='')
						{
							$('#time_end_schedule_'+val_position).text('')
							$('#time_start_schedule_'+val_position).html("<font color=red>*</font>"+val_mode_Array[12]);
						}
						else
						{
							$('#time_end_schedule_'+val_position).text(val_mode_Array[6])
							$('#time_start_schedule_'+val_position).text(val_mode_Array[4]);
						}
						$('#enabled_schedule_'+val_position).text((val_mode_Array[13] == "s" ? return_lang_string('lang_enabled_short') : return_lang_string('lang_disabled_short')));
						$('#name_schedule_'+val_position).attr('title',human_schedule[1]);
						$('#control_schedule_'+val_position).attr('value',human_schedule[2]);
						/* dobbiamo aggiornare la label dello schedule */
						$.ajax({
							type: "POST",
							url: "functions_values.php",
							data: "item=" + val_position + "&mode=sc",
							async: false,
							success: function(msg1){
								$("#name_schedule_"+val_position).attr('title', msg1);
							}
						});
					}
					
					$("#schedule_numbers_present").val(val_num_schedule);
					$("#schedule_position").val('');
					$("#schedule_mode").val('');
					$("#message_table_schedule").html(return_lang_string('ins_mod_del_I'));
					$("#img_tabschedule_c").attr('src', 'img/c.png');
					$("#img_tabschedule_m").attr('src', 'img/m.png');
					panel_schedule_clear();
					
					if (window_domo_map != "")
					window_domo_map.location.reload();
				},
				error: function(msg){
					$('#msg_setup_schedule').html(msg);
					document.getElementById('schedule_mode').value='';
					document.getElementById('schedule_position').value='';
				}
			});
		});	
		
		$("#domo_map").click(function() 
		{
			window_domo_map=window.open("domo_map.php", 'window_domo_map');
		});
		
		$("#realtime_domo").click(function() 
		{
			window_realtime_domo=window.open("domo60.php", 'window_realtime_domo');
			//$('#domo_running',window_realtime_domo.document).text('Running');
		});
		
		//if (<?php echo $schedule_running;?> == 1)
		//	$("#start").click();
		//else
		//	$("#stop").click();
		
	});
	
	function set_schedule()
	{
		var separator="#";
		// appunti
		// se arrivano valorizzati sia  $("#schedule_start_stop_value_num").val()  che  $("#schedule_start_stop_value").val() 
		// il primo ha la precedenza
		if (($("#schedule_start_stop_value_num").val() != '*' ) && ($("#schedule_start_stop_value").val() != '' ))
			$("#schedule_start_stop_value").val('');
			
		var string_schedule=$("#nome_schedule").val()+separator;
		
		if ($("#schedule_type_d").is(':checked') )
		string_schedule+="d";
		else if ($("#schedule_type_a").is(':checked') )
		string_schedule+="a";
		else
		string_schedule+="p";
		
		string_schedule+=$("#s_numeropin").val()+separator;
		string_schedule+=$("#datepick_1").val()+separator;
		string_schedule+=$("#datepick_2").val()+separator;
		
		if ($("#timepick_at").val() =='')
			string_schedule+=$("#timepick_1").val()+separator;
		else
			string_schedule+=''+separator;
		
		if (($("#schedule_start_stop_value_num").val() == '*' ) && ($("#schedule_start_stop_value").val() == '' ))
		{
			string_schedule+=($("#schedule_start_value_hi").is(':checked')) ?"1"+separator : "0"+separator;
				//else 
				//string_schedule+="0"+separator;
				//else
				//string_schedule+=$("#schedule_start_value_val").val()+separator;
		}
		else
			string_schedule+=""+separator;
		
		if ($("#timepick_at").val() =='')
			string_schedule+=$("#timepick_2").val()+separator;
		else
			string_schedule+=''+separator;
		
		if (($("#schedule_start_stop_value_num").val() == '*' ) && ($("#schedule_start_stop_value").val() == '' ))
		{
			string_schedule+=($("#schedule_stop_value_hi").is(':checked')) ?"1"+separator : "0"+separator;
		}
		else
			string_schedule+=""+separator;
		//else
		//string_schedule+=$("#schedule_stop_value_val").val()+separator;
		
		//$_SESSION['schedule']['days'][$schedulati]=$controls[9];
		
		if ($("#dd7").is(':checked') )
		string_schedule+="7";		
		else if ($("#dd8").is(':checked') )
		string_schedule+="8";		
		else
		{
			for (var z=0;z<7;z++)
			{
				if ($("#dd"+z).is(':checked') )
				{
					string_schedule+=z+'@';		
				}
			}
		}
		string_schedule+=separator;
		
		string_schedule+=($("#numero_controllo_start").val() !='*') ? $("#numero_controllo_start").val()+separator :''+separator;
		
		string_schedule+=($("#numero_controllo_stop").val() !='*') ? $("#numero_controllo_stop").val()+separator :	''+separator;
		
		
		if ($("#schedule_start_stop_value_num").val() != '*' )
		{
			string_schedule+=$("#schedule_start_stop_value_num").val()+separator;
		}
		else if ( $("#schedule_start_stop_value").val() != '')
			{
				// dobbiamo sostituire le # dentro la stringa digitata con qualcosa d'altro perche altrimenti, sullo split successivo, viene fuori casino
			var t_string=$("#schedule_start_stop_value").val().replace(/#/g,'$');
			string_schedule+=t_string+separator
			}
		else
			string_schedule+=''+separator;
			
		if ($("#timepick_at").val() !="")
			string_schedule+=$("#timepick_at").val()+separator;
		else 
			string_schedule+=''+separator;
			
		string_schedule+=($("#schedule_abilitato").is(":checked")) ? 's' : 'n';
		return string_schedule;
	}
	
	function panel_schedule_clear()
	{
		$("#nome_schedule").val('');
		$("#datepick_1").val('');
		$("#datepick_2").val('');
		$("#timepick_1").val('');
		$("#timepick_2").val('');
		$("#timepick_at").val('');
		$("#schedule_type_d").attr('checked',true); 
		$("#schedule_type_a").attr('checked',false);
		$("#schedule_type_p").attr('checked',false);
		$("#dd7").attr('checked',true);
		$("#dd0").attr('checked',false);
		$("#dd1").attr('checked',false);
		$("#dd2").attr('checked',false);
		$("#dd3").attr('checked',false);
		$("#dd4").attr('checked',false);
		$("#dd5").attr('checked',false);
		$("#dd6").attr('checked',false);
		$("#dd8").attr('checked',false);
		$("#s_numeropin").val('');
		$("#schedule_start_value_hi").attr('checked',false);
		$("#schedule_start_value_lo").attr('checked',false);
		//$("#schedule_start_value_v").attr('checked',false);
		$("#schedule_start_value_val").val('');
		$("#schedule_stop_value_hi").attr('checked',false);
		$("#schedule_stop_value_lo").attr('checked',false);
		$("#schedule_start_stop_value").val('');
		$("#schedule_start_stop_value_num").val('');
		//$("#schedule_stop_value_v").attr('checked',false);
		$("#schedule_stop_value_val").val('');
		$("#numero_controllo_start").val('');
		$("#numero_controllo_stop").val('');
		$("#schedule_start_stop_value_num").val('');
		$("#schedule_start_stop_value").val('');
		$("#schedule_abilitato").attr('checked',true);
		$("#schedule_disabilitato").attr('checked',false);
		$("#save_schedule").val(return_lang_string('save'));
		$("#message_table_schedule").html(return_lang_string('ins_mod_del_I'));
	}
	
	function mod_schedule(a , mode)
	{
		$("#schedule_mode").attr('value', mode);
		$("#schedule_position").attr('value', a);
		
		var command=$("#control_schedule_"+a).val();
		if (command == '')
		return ;
		
		var command_Array=command.split('#');
		$("#nome_schedule").val(command_Array[0]);
		if (command_Array[1].substr(0,1)=="p")
		$("#schedule_type_p").attr('checked',false);
		else
		(command_Array[1].substr(0,1)=="d" ? $("#schedule_type_d").attr('checked',true): $("#schedule_type_a").attr('checked',true));
		dropdown_filter("s",command_Array[1].substr(0,1),command_Array[1].substr(1));
		$("#datepick_1").val(command_Array[2]);
		$("#datepick_2").val(command_Array[3]);
		
		if (command_Array[12] == "")
			$("#timepick_1").val(command_Array[4]);
		
		if (command_Array[11]=='')
		{
		if (command_Array[5]< 2) 
		(command_Array[5] == 1 ? $("#schedule_start_value_hi").attr('checked',true): $("#schedule_start_value_lo").attr('checked',true)) ;
		//else
		//{
			//$("#schedule_start_value_v").attr('checked',true);
			//$("#schedule_start_value_val").val(command_Array[5]);
		//}	
		}	
		
		if (command_Array[12] == "")
			$("#timepick_2").val(command_Array[6]);
		
		if (command_Array[11]=='')
		{
		if (command_Array[7]< 2)
		(command_Array[7] == 1 ? $("#schedule_stop_value_hi").attr('checked',true): $("#schedule_stop_value_lo").attr('checked',true)) ;
		//else
		//{
		//	$("#schedule_stop_value_v").attr('checked',true);
		//	$("#schedule_stop_value_val").val(command_Array[7]);
		//}	
		}
		
		/* se ci sono i punti e virgola allora sono solo giorni */
		if (command_Array[8].indexOf("@")>0)
		{ 
			var dd=command_Array[8].split('@');
			for (var z=0; z<dd.length;z++)
			$("#dd"+dd[z]).attr('checked',true);
		}
		else 
		{
			(command_Array[8] == 7 ? ($("#dd7").attr('checked',true)) : ($("#dd8").attr('checked',false)));
		}
		
		
		$("#numero_controllo_start").val(command_Array[9]);
		$("#numero_controllo_stop").val(command_Array[10]);

		if (command_Array[11].indexOf('$') >-1) 
			command_Array[11]=command_Array[11].replace(/\$/g,'#');
		
		(command_Array[11].length < 2 ) ? $("#schedule_start_stop_value_num").val(command_Array[11]): $("#schedule_start_stop_value").val(command_Array[11]) ;
		
		$("#timepick_at").val(command_Array[12]);
		
		$("#save_schedule").val((mode =='d' ?  return_lang_string('delete') : return_lang_string('save')));
		$('#slider_sampling_val').slider({value: $("#sampling_val").val() });
		
		(command_Array[13] == "s" ? $("#schedule_abilitato").attr('checked',true): $("#schedule_disabilitato").attr('checked',true)) ;
		(mode =='d' ? $("#message_table_schedule").html(return_lang_string('ins_mod_del_D')) : $("#message_table_schedule").html(return_lang_string('ins_mod_del_M')));
	}
	
</script>													