<?php
##TIMEZONE
date_default_timezone_set("Europe/Rome");
setlocale(LC_TIME,"en_EN");
?>