<?php 
$_SESSION['com_port_open']=false;
$_SESSION['start']=false;
$_SESSION['dump_running']=false;
$_SESSION['watch_running']=false;
$_SESSION['schedule_running']=false;
?>