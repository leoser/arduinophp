<?php 
$_SESSION['com_port_open']=true;
$_SESSION['start']=true;
$_SESSION['dump_running']=true;
$_SESSION['watch_running']=false;
$_SESSION['schedule_running']=false;
?>