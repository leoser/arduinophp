<?php

##TIMEZONE
date_default_timezone_set("Europe/Rome");
setlocale(LC_TIME,"it_IT");
?>