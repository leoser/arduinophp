<?php
$_SESSION['survey']=array(
'name'=>array('Controllo 1','Controllo 2','Controllo 3','','','','','','',''),
'command'=>array('if#a#1#>#50#d#9#1#1#1#0#','if#a#2#>#50#d#10#1#1#1#0#','if#a#3#>#50#d#11#1#1#1#0#','','','','','','',''),
'control_d_a'=>array('a','a','a','','','','','','',''),
'control_pin'=>array('1','2','3','','','','','','',''),
'control_operator'=>array('>','>','>','','','','','','',''),
'control_value'=>array(50,50,50,0,0,0,0,0,0,0),
'action_d_a'=>array('d','d','d','','','','','','',''),
'action_pin'=>array('9','10','11','','','','','','',''),
'action_set_pin'=>array('1','1','1','','','','','','',''),
'action_value'=>array('1','1','1','','','','','','',''),
're_action_set_pin'=>array('1','1','1','','','','','','',''),
're_action_value'=>array('0','0','0','','','','','','',''),
'flag_action'=>array(1,0,0,0,0,0,0,0,0,0),
'elapse'=>array(10,10,10,10,10,10,10,10,10,10),
'last'=>array('1353780535','1353780535','1353780535','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00'),
'human'=>array('Analog 1 > 50 >> Digital 9 HIGH else  LOW','Analog 2 > 50 >> Digital 10 HIGH else  LOW','Analog 3 > 50 >> Digital 11 HIGH else  LOW',),
'enable'=>array('s','s','s','s','s','s','s','s','s','s'),
);
?>