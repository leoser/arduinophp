<?php
#COM PORT
$_SESSION['com']="COM1";
$_SESSION['speed']=115200;
$_SESSION['bits']=8;
$_SESSION['stop']=1;
$_SESSION['parity']=0; ##  0.....4 = none,odd,even,mark,space  ##

#SERVER NAME E ACCESSI
$_SESSION['server_name']="www.arduino.home";
$_SESSION['trusted_ip_admin']=array('127.0.0.1','10.0.0.1','192.168.0.1');
$_SESSION['trusted_ip_external_full']=array('10.0.0.4'); ##  non ancora implementato
$_SESSION['trusted_ip_external_monitor']=array('10.0.0.2');
$_SESSION['trusted_ip_external_monitor_text']=array('10.0.0.3');
$_SESSION['options']=array("Gestione Applicazione","Monitor Watch Grafico","Monitor Watch Testo","Monitor Domo Grafico","Monitor Domo Testo","Monitor Dump Testo","Monitor Dump",);
$_SESSION['options_prog']=array("arduino_ajax.php","watch10_e.php","watch10txt_e.php","domo60_e.php","domo60txt_e.php","dumptxt_e.php","dump_e.php");

#ARRAY
$_SESSION['val_digital_pin']=array(
'name'=>array('Pin0','Pin1','Pin2','Pin3','Pin4','Pin5','Pin6','Prova9','Pin8','Pin9','Pin10','Pin11','Pin12','Pin13'),
'valore'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0),
'default_type'=>array('d','d','d','d','d','d','d','d','d','d','d','d','d','d'),
'current_type'=>array('d','d','d','d','d','d','d','d','d','d','d','d','d','d'),
'last'=>array('00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00'),
'stato'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0),
		);
		
$_SESSION['val_analog_pin']=array(
		'name'=>array('Pin0','Pin1','Pin2','Pin3','Pin4','Pin5'),
		'valore'=>array(0,0,0,0,0,0),
		'default_type'=>array('a','a','a','a','a','a'),
		'current_type'=>array('a','a','a','a','a','a'),
		'map'=>array('0:0:0:0','0:0:0:0','0:0:0:0','0:0:0:0','0:0:0:0','0:0:0:0'),
		'constrain'=>array('0:0','0:0','0:0','0:0','0:0','0:0'),
		'vref'=>array('1','1','1','1','1','1'),
		'last'=>array('00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00'),
		'stato'=>array(0,0,0,0,0,0),
		);
		
$_SESSION['survey']=array(
'name'=>array('Controllo 1','','','','','','','','',''),
'command'=>array('if#a#1#>#50#d#9#1#1#1#0#','','','','','','','','',''),
'control_d_a'=>array('a','','','','','','','','',''),
'control_pin'=>array('1','','','','','','','','',''),
'control_operator'=>array('>','','','','','','','','',''),
'control_value'=>array(50,0,0,0,0,0,0,0,0,0),
'action_d_a'=>array('d','','','','','','','','',''),
'action_pin'=>array('9','','','','','','','','',''),
'action_set_pin'=>array('1','','','','','','','','',''),
'action_value'=>array('1','','','','','','','','',''),
're_action_set_pin'=>array('1','','','','','','','','',''),
're_action_value'=>array('0','','','','','','','','',''),
'flag_action'=>array(0,0,0,0,0,0,0,0,0,0),
'elapse'=>array(10,10,10,10,10,10,10,10,10,10),
'last'=>array('00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00','00:00:00<br>00:00:00'),
'human'=>array('Analog 1 > 50 >> Digital 9 HIGH else  LOW','',''),
'enable'=>array('s','s','s','s','s','s','s','s','s','s'),
		);
		
$_SESSION['schedule']=array(
'name'=>array('Antifurto Box','Acquario','Porta','Finestra','','','','','','','','','','','','','','','',''),
'command_pin'=>array('d13','d9','d10','d3','','','','','','','','','','','','','','','',''),
'date_start'=>array('9:10:2012','9:10:2012','15:11:2012','18:11:2012','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00'),
'date_end'=>array('31:12:2020','31:12:2020','30:11:2012','30:11:2012','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00','00:00:00'),
'time_start'=>array('20:30','8:30','16:00','19:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00'),
'action_start'=>array('1','1','1','1','','','','','','','','','','','','','','','',''),
'time_end'=>array('8:00','23:00','23:00','07:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00'),
'action_end'=>array('0','0','0','0','','','','','','','','','','','','','','','',''),
'days'=>array('7','7','7','7','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'),
'watch_start'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
'watch_stop'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
'flag_action'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
'date_time_started'=>array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
'elapsed'=>array('00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00','00:00'),
'last'=>array('00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00','00:00:00<br>00:00'),
'enable'=>array('s','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s','s'),
		);
		
##SCHEDULER (DOMO)
$_SESSION['schedule_running']=false;
$_SESSION['refresh_domo']=60;
$_SESSION['mapfile_domo']="dati/map_domo.txt";
$_SESSION['mapfile_domo_open_mode']="r";
$_SESSION['mapfile_domo_open_mode_rw']="w+";  ## w+ : overwrite	a+ : append
$_SESSION['map_domo']="img/pianta.jpg";
$_SESSION['data_for_external_domo']="dati/data_for_external_domo.php";

##WATCHDOG (CONTROLLI)
$_SESSION['watch_running']=false;
$_SESSION['refresh_watch']=10;
$_SESSION['mapfile_watch']="dati/map_watch.txt";
$_SESSION['mapfile_watch_open_mode']="r";
$_SESSION['mapfile_watch_open_mode_rw']="w+";  ## w+ : overwrite	a+ : append
$_SESSION['map_watch']="img/pianta.jpg";
$_SESSION['data_for_external_watch']="dati/data_for_external_watch.php";

##CONFIG (questo file)
$_SESSION['configfile']="dati/config.php";
$_SESSION['configfile_open_mode']="a+";  ## w+ : overwrite	a+ : append
$_SESSION['configfile_open_mode_rw']="w+";  ## w+ : overwrite	a+ : append

##LOG
$_SESSION['logfile']="dati/log.txt";
$_SESSION['logfile_open_mode']="a+";  ## w+ : overwrite	a+ : append
$_SESSION['logfile_open_mode_rw']="w+";  ## w+ : overwrite	a+ : append
$_SESSION['logfile_max_size']="1024";  ##  in kb

##DUMP
$_SESSION['refresh_dump']=10;
$_SESSION['refresh_dump_e']=240;
$_SESSION['data_for_external_session']="dati/data_for_external_session.php";

##COMANDI RAPIDI
"READ ANALOG 0@a0#0";
"READ ANALOG 3@a3#0";
"HIGH PIN12@d12#11";
"LOW PIN12@d12#10";
"BLINK PIN12 3 VOLTE@d12#11*3*0*500*";		
		
##ALTRO
$_SESSION['start']=true;
$control_last_command=false;
$_SESSION['msg_dialog']="";
$_SESSION['msg_error=']="";
$_SESSION['bgcolor']=array("white","#77E83F");
$_SESSION['giorni_name']=array("Lun","Mar","Mer","Gio","Ven","Sab","Dom");
?>