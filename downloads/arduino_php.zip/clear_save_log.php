<?php
session_start();
if ($_POST['mode']=='s')
   {
	$filename_out = $_SESSION['logfile']."_".date("d.m.Y").".txt";
	$handle = fopen($_SESSION['logfile'], "r");
	$handle1 = fopen($filename_out, "w+");
	$contents='';
	while (!feof($handle)) 
	{
		$contents = fgets($handle);
		fputs($handle1,$contents );
	}
	fclose($handle);
	fclose($handle1);
	}
else
	{
	file_put_contents($_SESSION['logfile'], '');
	}
echo $_POST['mode'];
?>