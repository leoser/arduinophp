<?php
	session_start();	
	include("lang/lang_".$_SESSION['lang'].".php");
	###########################################
	##  SYSTEM COMMAND
	##  arrivano qui tutti comandi SYSTEM
	###########################################
	//$string_data=explode(";",$_POST['data']);

	switch ($_POST['command'])
	{
		case '*':
		//check per arduino ready
		$a=WriteSS("*");
		$a=ReadSS("");
		// echo (strrpos($a, "**") != 0) ? "Arduino non risponde!<br>" : "Arduino READY<br>";
		if (strrpos($a, "**") != 0)
			echo $_SESSION['lang_arduino_not_ready']."!<br>";
		else
			echo $_SESSION['lang_arduino_ready'].".<br>";
		break;
		
		case '?':
		//check com port risponde la dll
		$a=IsOpenSS();
		if ($a)
			echo $_SESSION['lang_port_opened'].".<br>";
		else
			echo $_SESSION['lang_port_problem'].".<br>";
		break;
		
		case 'e':
		## close  com port
		## end run su arduino
		$a=WriteSS("e");
		sleep(1);
		$a=CloseSS();
		$_SESSION = array();
		unset($_SESSION);
		if ($a==0)
		{
			echo $_SESSION['lang_port_closed']."<br>";
		}
		elseif ($a==6)
		{
			echo $_SESSION['lang_port_closing_overlap']."<br>";
		}
		elseif ($a==9)
		{

			echo $_SESSION['lang_port_closing_parm_error']."<br>";
		}
		else
		{
			echo $_SESSION['lang_port_closing_problem']."<br>";
		}
		break;
		
	case 'a':
		echo $_SESSION['lang_port_opened']."<br>";
		break;
		
		default:
		echo "hummm";
		break;
	}
	
?>