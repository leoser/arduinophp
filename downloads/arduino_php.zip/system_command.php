<?php
	session_start();	
	###########################################
	##  SYSTEM COMMAND
	##  arrivano qui tutti comandi SYSTEM
	###########################################
	//$string_data=explode(";",$_POST['data']);

	switch ($_POST['command'])
	{
		case '*':
		//check per arduino ready
		$a=WriteSS("*");
		$a=ReadSS("");
		// echo (strrpos($a, "**") != 0) ? "Arduino non risponde!<br>" : "Arduino READY<br>";
		if (strrpos($a, "**") != 0)
			echo "Arduino non risponde!<br>";
		else
			echo "Arduino READY<br>";
		break;
		
		case '?':
		//check com port risponde la dll
		$a=IsOpenSS();
		if ($a)
			echo "Porta Ok<br>";
		else
			echo "Problemi con la porta com.<br>";
		break;
		
		case 'e':
		## close  com port
		## end run su arduino
		$a=WriteSS("e");
		sleep(1);
		$a=CloseSS();
		$_SESSION = array();
		unset($_SESSION);
		if ($a==0)
		{
			echo "Porta chiusa<br>";
		}
		elseif ($a==6)
		{
			echo "Overlap in chiusura<br>";
		}
		elseif ($a==9)
		{
			echo "Parametro chiusura errato<br>";
		}
		else
		{
			echo "Problema in chiusura porta<br>";
		}
		break;
		
	case 'a':
		echo "Porta Aperta<br>";
		break;
		
		default:
		echo "hummm";
		break;
	}
	
?>