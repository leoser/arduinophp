<?php
?>
<script>
	$(document).ready(function()
	{
		var ajax_cancelled_survey = false, ajax_cancelled_schedule = false ,ajax_cancelled_dump = false;
		var msg_survey='',msg_schedule='',msg_dump='',data_survey='',data_schedule='';
		/* interval 10 sec */
		var Id_survey= null,refreshId_survey= null,interval_survey=5000,msg='';
		/* interval 1 minuto scarso */
		var Id_schedule = null,refreshId_schedule = null,interval_schedule=59000,msg_schedule='';
		/* interval 2 minuti scarsi 
		var Id_dump = null,refreshId_dump= null,interval_dump=10000;
		
		$("#button_start_dump").click(function() {
				$.ajax({
					type: "POST",
					url: "update_dump.php",
					data: "mode=0",
					async: false,
					success: function(msg_dump){
					}
				});
			ajax_cancelled_dump =false;
			$('#button_start_dump').attr("disabled", true);
			$('#button_stop_dump').attr("disabled", false);
			$('#button_start_dump').val('*RUNNING');
			$('#button_stop_dump').val('STOP');
			$('#dump_running').text("Il Dump dei dati e' avviato.");
			Id_dump=setInterval(function() {
				$.ajax({
					type: "POST",
					url: "update_data_for_external.php",
					data: "save=du",
					async: false,
					success: function(msg_dump){
					}
				});
			}, interval_dump);
		});
		
		//stoppiamo
		$("#button_stop_dump").click(function() 
		{
			clearInterval(Id_dump);
			Id_dump=null;
			if (refreshId_dump!= null)
			{
				refreshId_dump.abort();
				refreshId_dump=null;
				ajax_cancelled_dump = true;
			}
			$('#button_stop_dump').attr("disabled", true);
			$('#button_start_dump').attr("disabled", false);
			$('#button_stop_dump').val('* STOPPED');
			$('#button_start_dump').val('START');
			$('#dump_running').text("Il Dump dei dati non e' avviato.");
			$.ajax({
				type: "POST",
				url: "update_dump.php",
				data: "mode=s",
				async: false,
				success: function(msg_dump){
				},
				error: function(msg_dump){
				}
			});
			
		});
		*/
		
		$("#button_start_survey").click(function() {
				$.ajax({
					type: "POST",
					url: "update_watch.php",
					data: "mode=0",
					async: false,
					success: function(msg_survey){
					}
				});
		
			ajax_cancelled_survey =false;
			$('#button_start_survey').attr("disabled", true);
			$('#button_stop_survey').attr("disabled", false);
			$('#button_start_survey').val('*RUNNING');
			$('#button_stop_survey').val('STOP');
			$('#watch_running').text("Il Watchdog e' avviato.");
			Id_survey=setInterval(function() {
				data_survey=($('#log_survey').is(':checked'))? 's' : 'n';
				refreshId_survey=$.ajax({
					type: "POST",
					url: "survey.php",
					async: false,
					data : "log="+data_survey ,
					success: function(msg_survey) {
						if (!ajax_cancelled_survey)
						{
							// scriviamo i dati per le applicazioni esterne
							$.ajax({
								type: "POST",
								url: "update_data_for_external.php",
								data: "save=su",
								async: false,
								success: function(msg1){
									
								}
							});
						}
						
					},
					error: function(msg_survey){
						$('#survey').html("<font color='red'> Com port down o errore di sintassi in survey.php.");
					}
				});
			}, interval_survey);
		});
		
		//stoppiamo
		$("#button_stop_survey").click(function() 
		{
			clearInterval(Id_survey);
			Id_survey=null;
			if (refreshId_survey!= null)
			{
				refreshId_survey.abort();
				refreshId_survey=null;
				ajax_cancelled_survey = true;
			}
			$('#button_stop_survey').attr("disabled", true);
			$('#button_start_survey').attr("disabled", false);
			$('#button_stop_survey').val('* STOPPED');
			$('#button_start_survey').val('START');
			$('#watch_running').text("Il Watchdog non e' avviato.");
			$.ajax({
				type: "POST",
				url: "update_watch.php",
				data: "watch= &mode=s",
				async: false,
				success: function(msg_survey){
				},
				error: function(msg_survey){
				}
			});
			
		});
		
		$("#button_start_schedule").click(function() {
				$.ajax({
					type: "POST",
					url: "update_schedule.php",
					data: "mode=0",
					async: false,
					success: function(msg_schedule){
					}
				});
			
			ajax_cancelled_schedule=false;
			$('#button_start_schedule').attr("disabled", true);
			$('#button_stop_schedule').attr("disabled", false);
			$('#button_start_schedule').val('*RUNNING');
			$('#button_stop_schedule').val('STOP');
			$('#schedule_running').text("Lo Schedule e' avviato.");
			Id_schedule=setInterval(function() {
				data_schedule=($('#log_schedule').is(':checked'))? 's' : 'n';
				refreshId_schedule=$.ajax({
					type: "POST",
					url: "schedule.php",
					async: false,
					data : "log="+data_schedule ,
					success: function(msg_schedule) {
						if (!ajax_cancelled_schedule)
						{
							// scriviamo i dati per le applicazioni esterne
							$.ajax({
								type: "POST",
								url: "update_data_for_external.php",
								data: "save=sc",
								async: false,
								success: function(msg_schedule){
									
								}
							});
						}
					},
					error: function(msg_schedule){
						$('#schedule').html("<font color='red'> Com port down o errore di sintassi in schedule.php.");
					}
				});
			}, interval_schedule);
		});
		
		//stoppiamo
		$("#button_stop_schedule").click(function() 
		{
			clearInterval(Id_schedule);
			Id_schedule=null;
			if(refreshId_schedule != null ) 
			{
				refreshId_schedule.abort();
				refreshId_schedule=null;
				ajax_cancelled_schedule = true;
			}
			$('#button_stop_schedule').attr("disabled", true);
			$('#button_start_schedule').attr("disabled", false);
			$('#button_stop_schedule').val('* STOPPED');
			$('#button_start_schedule').val('START');
			$('#schedule_running').text("Lo Schedule non e' avviato.");
			/* andiamo a mettere  flag0 a tutti gli schedule */
			$.ajax({
				type: "POST",
				url: "update_schedule.php",
				data: "schedule= &mode=s",
				async: false,
				success: function(msg_schedule){
					/* risponde con tutti i pin resettati */
				},
				error: function(msg_schedule){
					
				}
			});
		});

	});
	
</script>									