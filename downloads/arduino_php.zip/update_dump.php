<?php
	session_start();	
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
	// PRIMO SPLIT 
	// STRINGA  if#a#3#>#50#d#0#1#1#1#0#;15;Controllo 112&pos=1&mode=u
	//$string_watch[0]=if#a#3#>#50#d#0#1#1#1#0# (command)
	//$string_watch[1]= elapse
	//$string_watch[2]= name
	
	switch ($_POST['mode'])
	{
		case '0':
		$_SESSION['dump_running']=true;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"dump_running']=false")>-1)
		{
			$content=str_ireplace("['dump_running']=false","['dump_running']=true",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		break;

		case 's':
		$_SESSION['dump_running']=false;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"dump_running']=true")>-1)
		{
			$content=str_ireplace("['dump_running']=true","['dump_running']=false",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		break;
	}		