<?php
	session_start();
	if ($_POST['data'])
	{
		$opt=$_POST['data'];
		$dati_ajax=send_value($opt);
		echo $dati_ajax;
	}

	function send_value($opt)
	{
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
		if (strrpos($opt, ";"))
			$commands=explode(";",$opt);
		else
			$commands[0]=$opt;
		
		## prima di inviare check connection con arduino per il ready
		##  inviamo * e attendiamo **
		##
		$a=WriteSS("*");
		
		$a=ReadSS("");
		if (strrpos($a, "**") != 0)
		{
			$_SESSION['msg_error']="Arduino non risponde! - ";
			break;
		}
		else
		$_SESSION['msg_dialog']="Arduino READY - ";
		
		for ($arr_len=0;$arr_len < count($commands); $arr_len++)
		{
			$orario=date('d-m-y')."<br>".date('h:i:s');
			$opt=$commands[$arr_len];
			$a_d_p_Array=explode("#",$opt);
			$ana_dig=substr($a_d_p_Array[0],0,1);
			$pin_no=(int)substr($a_d_p_Array[0], 1);
			$mode = substr($a_d_p_Array[1],0,1);
			$valore=substr($a_d_p_Array[1],1,10);
			
			$packet='';
			######################################
			###    COSTRUZIONE PACCHETTO PER ANALOGICO 
			######################################
			if (($ana_dig =='a') && ($_POST['data']))
			{
				# se il pin e' analogico mandiamo anche map constrain e vref
				# se sono a zero non verranno considerati da arduino
				$map=explode(":",$_SESSION['val_analog_pin']['map'][$pin_no]);
				$constrain=explode(":",$_SESSION['val_analog_pin']['constrain'][$pin_no]);
				if (count($map)>0)
					$packet.="*".$map[0]."*".$map[1]."*".$map[2]."*".$map[3]."*";
				else
					$packet.="*****";
				
				##  qui ci andrebbe il vref, per adesso mettiamo 1 che e' DEFAULT ( 5v )
				$packet.="1";
				
				if (count($constrain)>0)
					$packet.="*".$constrain[0]."*".$constrain[1]."*";
				else
					$packet.="***";
				$opt.=$packet;
			}
			#######################################################
			##  se il delay e' maggiore di 0 e' una ripetizione
			if ($_POST['delay'] > 0)
				usleep($_POST['delay']);
			#######################################################
			
			# PRIMA DI MANDARE FACCIAMO UN CHECK SE IL PIN E' DISABILITATO
			# il check e' utile per le richieste inviate non dalla slider (che viene disabilita) ma da survey e dai comandi globali
			$enabled=($ana_dig == "d") ? $_SESSION['val_digital_pin']['stato'][$pin_no] : $_SESSION['val_analog_pin']['stato'][$pin_no];
			
			if ($enabled == 0)
			{
				##  la write puo avere (per adesso) solo un errore nell'interpretazione zend_parse_parameters. risponde l'estensione
				$a=WriteSS($opt);
				if (strrpos($a, "-"))
				{
					$val=substr($a, strrpos($a,"-"));
					if (count($commands) >0)
					$_SESSION['msg_dialog'].=date('h:i:s')." Errore nel comando inviato ad Arduino (risposta dell'estensione) : ". $opt ." rc_EXT=".$val."  ";
					else
					$_SESSION['msg_dialog'].="Errore nel comando inviato ad Arduino (risposta dell'estensione) : ". $opt ." rc_EXT=".$val."  ";
				}
				else
				{
					if (count($commands) >0)
					$_SESSION['msg_dialog'].=date('h:i:s')." Comando inviato ad Arduino : ". $opt ." rc_EXT=".$a."  ";
					else
					$_SESSION['msg_dialog'].=date('h:i:s')." Comando inviato ad Arduino : ". $opt ." rc_EXT=".$a."  ";
				}
				
				##  NON E' NECESSARIO MA SU COMANDI PARTICOLARMENTE LUNGHI
				##  diamogli respiro....
				//if (count($commands) > 10)
				//sleep(1);
				
				## cosa risponde arduino al comando? ##
				$a=ReadSS("");
				
				# la read puo' ritornare , oltre il return_code, anche il valore letto nel formato return_code;valore
				if (strrpos($a,";")!=0)
				{
					## c'e un valore;e' dopo il ; mettiamolo in val; il return_code e' prima del ;
					$val=(int)substr($a, strrpos($a, ";")+1);
					$a=substr($a, 0,strrpos($a, ";")-1);
				}
				else
				{
					## era una impostazione , non c'e val;
					$val=$valore;
				}
				
				## e' un digitale i pwm?
				if ($ana_dig =='p') 
					$ana_dig="d"; 
				
				## e' un analogico in digitale? 
				if ($pin_no > 13) 
					$ana_dig="a"; 

								
				## aggioniamo gli array con valore ultima lettura e current_type
				if ($ana_dig == "d")
				{
					$_SESSION['val_digital_pin']['valore'][$pin_no]=$val;
					$_SESSION['val_digital_pin']['last'][$pin_no]=$orario;
				}
				else
				{
					###  e' un analogico camuffato da digitale? 
					####   fare cambiare anche il current type ####
					($pin_no > 13) ? $_SESSION['val_analog_pin']['current_type'][($pin_no-14)]='d' : $_SESSION['val_analog_pin']['current_type'][$pin_no]='a';
					$pin_no=($pin_no > 13) ? $pin_no-14 : $pin_no ;
					$_SESSION['val_analog_pin']['valore'][$pin_no]=$val;
					$_SESSION['val_analog_pin']['last'][$pin_no]=$orario;
				}
				$_SESSION['msg_dialog'].= date()."=> Arduino reply: rc=$a  value:$val<br>";
			}
			else
			{
				## il pin e' disabilitato. dobbiamo comunque rimandare i valori e quindi usiamo quelli correnti negli array
				$val=($ana_dig == "d") ? $_SESSION['val_digital_pin']['valore'][$pin_no] : $_SESSION['val_analog_pin']['valore'][$pin_no];
				$orario=($ana_dig == "d") ? $_SESSION['val_digital_pin']['last'][$pin_no] : $_SESSION['val_analog_pin']['last'][$pin_no];
				$a="-";
				$_SESSION['msg_dialog'].= date()." Pin n. ".$pin_no." disabilitato. Il comando ".$opt." non e' stato inviato ". $opt ." rc=$a  value:$val<br>";
			}	
			$ret_val=$val."%".$orario."%".$_SESSION['msg_dialog'];
			
			//  forse e' meglio metterlo alla fine di tutto, magari chiamato con AJAX IN ASYNC perche' rallenta un po'
			if ($_POST['log'] == "s")
			{
			$_SESSION['logfile']="dati/log.txt";
			$_SESSION['logfile_open_mode']="a+";
			if (!$_SESSION['log_open'])
				$_SESSION['log_file'] = fopen($_SESSION['logfile'], $_SESSION['logfile_open_mode']);

			fwrite($_SESSION['log_file'], "ARDUINO ** ".$ret_val."\n");
			}
			// ------------------------------------------------------------------------
			return $ret_val;
		}	
	}	
?>