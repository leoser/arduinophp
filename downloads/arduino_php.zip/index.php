<?php
	##  QUESTO E' IL MINIMO DA FARE PARTIRE; 
	##  APRIRE LA PORTA COM 
	##  PER IL MOMENTO, COME AMMINISTRATORE, SI DOVREBBE FARE PARTIRE LO SCHEDULE E IL WATCH APRENDO IL PANNELLO
	## DI COMANDO
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
	
	session_start();	
	if ($_POST['close_me'])
	{
		$a=CloseSS();
		$to_write="<?php \n\$_SESSION['com_port_open']=false;\n\$_SESSION['start']=false;\n\$_SESSION['dump_running']=false;\n\$_SESSION['watch_running']=false;\n\$_SESSION['schedule_running']=false;\n?>";
		file_put_contents($_SESSION['status_services'], $to_write);
		
		$_SESSION = array();
		unset($_SESSION);
		
		include("end_panel_ajax.php");
		die();
	}
	function check_grant($r_addr)
	{
		$mask='';
		if (in_array($r_addr,$_SESSION['trusted_ip_admin'])) 
		{
			$_SESSION['level']='Admin';
			$mask="1     ";
		}	
		else if (in_array($r_addr,$_SESSION['trusted_ip_external_full'])) 
		{
			$_SESSION['level']='External Admin';
			$mask="11111  ";
		}
		else if (in_array($r_addr,$_SESSION['trusted_ip_external_monitor'])) 
		{
			$_SESSION['level']='External Monitor';	
			$mask=" 111111";
		}
		else if (in_array($r_addr,$_SESSION['trusted_ip_external_monitor_text'])) 
		{
			$_SESSION['level']='External Monitor Text';	
			$mask="  1 1 11";
		}
		
		return $mask;
	}
	
	function check_conn()
	{
		$msg="";
		$a=IsOpenSS();
		if ($a == 1)
		{
			$msg.="Porta ".$_SESSION['com']." aperta."."@";
			$a=WriteSS("*");
			$a=ReadSS("");
			if (strrpos($a, "**") != 0)
			$msg.= "Arduino non risponde!";
			else
			$msg.="Arduino READY.";
		}
		return $msg;
	}
	
	if (!$_SESSION['start'])
	{
		include_once("/dati/config.php");
		
		## VEDIAMO DA DOVE ARRIVA
		$_SESSION['mask']=check_grant($_SERVER["REMOTE_ADDR"]);
		// apriamo la porta solo se si e' in locale
		if (substr($_SESSION['level'],0,1)=="A")
		{
			## la prima condizione e' testare l'esistenza della porta 
			//$low_port = check_low_port();
			
			$a=OpenSS($_SESSION['com'],$_SESSION['speed'],$_SESSION['bits'],$_SESSION['stop'],$_SESSION['parity']);
			switch ($a)
			{
				case '0':
				## attendiamo che arduino vada in linea
				sleep(2);
				## check connessione e arduino ready
				$msg=check_conn();
				$_SESSION['start']=true;
				
				//  andiamo a scriverlO nel file 
				$content=file_get_contents($_SESSION['status_services']);
				if (strpos($content,"start']=false")>-1)
				{
					$content=str_ireplace("['start']=false","['start']=true",$content);
					$content=str_ireplace("['com_port_open']=false","['com_port_open']=true",$content);
					file_put_contents($_SESSION['status_services'], $content);
				}
				
				$msg_messages=explode("@",$msg);
				$msg_port_header="<td><b>".$msg_messages[0].$msg_messages[1]."</b></td><td colspan=2><input type='button' value='Close port, Session and say goodbye!' onclick='close_services();close_me.submit();'></td>";
				$msg_port=$msg_messages[0]."<br>";
				include_once("testcom.php");
				break;
				
				case 'e-95':
				$msg_port="Parametri PORTA errati<br>";
				$msg_port_header=$msg_port;
				break;
				
				case 'e-99':
				$msg_port="<td><b>Problemi nell'apertura porta ".$_SESSION['com'].".Porta inesistente o occupata.</b><br>1)check della connessione USB.<br>2)Stop & Start dei servizi di Wamp.</td><td colspan=2><input type='button' value='Restart' onclick='location.reload();'></td>";
				$msg_port_header=$msg_port;
				break;
				
				default:
				break;
			}
		}
	}
	else
	{
		// e' un reload o un richiamo della pagina; la connessione e arduino dovrebbero essere su.facciamo un check
		// facciamo un check della low; puo' tornare false se e' gia allocata o inisistente
		// incrociando con check_conn() possiamo capire cosa puo' essere andato storto
		if (substr($_SESSION['level'],0,1)=="A")
		{
			$msg=check_conn();
			$msg_messages=explode("@",$msg);
			
			if (count($msg_messages) == 2)
			{
				// LA SITUAZIONE NORMALE....E' APERTA E ARDUINO E' ATTACCATO
				$msg_port_header="<td><b>".$msg_messages[0].$msg_messages[1]."</b></td><td colspan=2><input type='button' value='Close port, Session and say goodbye!' onclick='close_services();close_me.submit()'>";;
				$msg_port=$msg_messages[0]."<br>";
			}
			else
			{
				if ($msg=='')
				{
					// LA CHECK_CONN HA RITORNATO NIENTE
					$msg_port_header="<td><b>Problemi nell'apertura porta ".$_SESSION['com'].".Porta inesistente o occupata.</b><br>1)check della connessione USB.<br>2)Stop & Start dei servizi di Wamp.</td><td colspan=2><input type='button' value='Restart' onclick='location.reload();'><td>";
					$a=CloseSS();
					unset ($_SESSION['start']);
				}
			}
		}
	}
	
	//$watch_running=($_POST['watch_running']) ? $_POST['watch_running'] : 0;
	include("start_panel_ajax.php");
	
	//include("panel_ajax.php");
	
?>