COSA SERVE
WAMP server. La mia versione e' la 2.0i(apache 2.2.11 + php 5.3.0). La puoi scaricare da http://sourceforge.net/projects/wampserver/files/WampServer%202/WampServer%202.0/ e' la 2.0i (la prima).Non ho ancora testato con altre versioni; per adesso usate questa.
Un servizio di DNS dinamico (se volete accedere da remoto al server).
Com port disponibile (nativa o usb).

INSTALLAZIONE
0) Installa WAMP server

Con WAMP inattivo:
1) Estraete lo zip in una cartella locale
2) Create una sottocartella in wamp/www (esempio: arduino) e copiateci tutto il contenuto della cartella arduino dello zip
3) Copiate il file php_simple_serial.dll nella cartella wamp/bin/php/php5.3.0/ext
4) Aprite il file php.ini che trovate nella cartella wamp/bin/php/php5.3.0
Cercate la stringa Windows Extensions Troverete a seguire una lista di estensioni.
Andate alla fine delle estensioni e aggiungete una nuova riga con questo contenuto:<br/> 
<b>extension=php_simple_serial.dll  (senza niente alla fine!)
Salvate e chiudete.
5) Ripetete la stessa cosa con il file phpForApache.ini che trovate nella stessa cartella.
6) Ora lanciate WAMP , cliccate sulla sua icona nella barra in basso a sinitra e Selezionate PHP->PHP EXTENSION; si aprira' una lista di estensioni.Cercate la php_simple_serial (dovrebbe essere non selezionata e cliccateci sopra).Wamp dovrebbe rifare il restart; se volete chiudetelo e fatelo ripartire.
7) Ora controllate che nella pagina iniziale ci sia, tra le estensioni caricate, anche la php_simple_serial.dll
E, come si dice, YOU HAVE DONE!

Buon divertimento!

Vi sarei grato per ogni feedback su bug, nuove funzionalita', ecc. : leoser[at]altervista.org