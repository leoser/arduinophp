<?php
	session_start();	
	date_default_timezone_set("Europe/Rome");
	setlocale(LC_TIME,"it_IT");
	$string_schedule=explode(";",$_POST['schedule']);
	
	switch ($_POST['mode'])
	{
		case '0':
		$_SESSION['schedule_running']=true;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"schedule_running']=false")>-1)
		{
			$content=str_ireplace("['schedule_running']=false","['schedule_running']=true",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		break;
		
		case 's':
		$reset_pins='';
		include_once("include_send.php");
		$_SESSION['schedule_running']=false;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"schedule_running']=true")>-1)
		{
			$content=str_ireplace("['schedule_running']=true","['schedule_running']=false",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		for ($x=0;$x<21;$x++)
		{
			if ($_SESSION['schedule']['flag_action'][$x] >0)
			{	
				$opt= $_SESSION['schedule']['command_pin'][$x]."#1".$_SESSION['schedule']['action_end'][$x];
				send_value($opt);
				$reset_pins.=$_SESSION['schedule']['command_pin'][$x].";";
				$_SESSION['schedule']['flag_action'][$x]=0;
			}
		}
		echo $reset_pins;
		break;
		
		case 'd':
		for ($x=$_POST['pos']-1;$x<21;$x++)
		{
			$_SESSION['schedule']['name'][$x]=$_SESSION['schedule']['name'][$x+1];
			$_SESSION['schedule']['command_pin'][$x]=$_SESSION['schedule']['command_pin'][$x+1];
			$_SESSION['schedule']['date_start'][$x]=$_SESSION['schedule']['date_start'][$x+1];
			$_SESSION['schedule']['date_end'][$x]=$_SESSION['schedule']['date_end'][$x+1];
			$_SESSION['schedule']['time_start'][$x]=$_SESSION['schedule']['time_start'][$x+1];
			$_SESSION['schedule']['action_start'][$x]=$_SESSION['schedule']['action_start'][$x+1];
			$_SESSION['schedule']['time_end'][$x]=$_SESSION['schedule']['time_end'][$x+1];
			$_SESSION['schedule']['action_end'][$x]=$_SESSION['schedule']['action_end'][$x+1];
			$_SESSION['schedule']['days'][$x]=$_SESSION['schedule']['days'][$x+1];
			$_SESSION['schedule']['watch_start'][$x]=$_SESSION['schedule']['watch_start'][$x+1];
			$_SESSION['schedule']['watch_stop'][$x]=$_SESSION['schedule']['watch_stop'][$x+1];
			$_SESSION['schedule']['enable'][$x]=$_SESSION['schedule']['enable'][$x+1];
			$_SESSION['schedule']['flag_action'][$x]=$_SESSION['schedule']['flag_action'][$x+1];
			$_SESSION['schedule']['date_time_started'][$x]=$_SESSION['schedule']['date_time_started'][$x+1];
			$_SESSION['schedule']['last'][$x]=$_SESSION['schedule']['last'][$x+1];
			$_SESSION['schedule']['elapsed'][$x]=$_SESSION['schedule']['elapsed'][$x+1];
			
		}
		$_SESSION['schedule']['name'][$x]='';
		$_SESSION['schedule']['command_pin'][$x]='';
		$_SESSION['schedule']['date_start'][$x]='00:00:00';
		$_SESSION['schedule']['date_end'][$x]='00:00:00';
		$_SESSION['schedule']['time_start'][$x]='00:00';
		$_SESSION['schedule']['action_start'][$x]='';
		$_SESSION['schedule']['time_end'][$x]='00:00';
		$_SESSION['schedule']['action_end'][$x]='';
		$_SESSION['schedule']['days'][$x]='7';
		$_SESSION['schedule']['watch_start'][$x]=0;
		$_SESSION['schedule']['watch_stop'][$x]=0;
		$_SESSION['schedule']['enable'][$x]="s";
		$_SESSION['schedule']['flag_action'][$x]='';
		$_SESSION['schedule']['date_time_started'][$x]=0;
		$_SESSION['schedule']['last'][$x]='00:00:00<br>00:00';
		$_SESSION['schedule']['elapsed'][$x]='00_00';
		echo "deleted ".$_POST['pos'];
		break;
		
		default:
		if ($_POST['mode']=="u")
		{
			$start=$_POST['pos']-1;
			$end=$_POST['pos'];
		}
		else
		{
			$start=0;
			$end=21;
		}
		
		for ($schedulati=$start; $schedulati < $end; $schedulati++)
		{
			if (($_SESSION['schedule']['name'][$schedulati] != '') && ($_POST['mode']!="u"))
			{
				continue;
			}
			$_SESSION['schedule']['command_pin'][$schedulati]=substr($string_schedule[0],0,strlen($string_schedule[0])-1);
			$controls=explode("#",$string_schedule[0]);
			$_SESSION['schedule']['name'][$schedulati]=$controls[0];
			$_SESSION['schedule']['command_pin'][$schedulati]=$controls[1];
			$_SESSION['schedule']['date_start'][$schedulati]=$controls[2];
			$_SESSION['schedule']['date_end'][$schedulati]=$controls[3];
			$_SESSION['schedule']['time_start'][$schedulati]=$controls[4];
			$_SESSION['schedule']['action_start'][$schedulati]=$controls[5];
			$_SESSION['schedule']['time_end'][$schedulati]=$controls[6];
			$_SESSION['schedule']['action_end'][$schedulati]=$controls[7];
			$_SESSION['schedule']['days'][$schedulati]=$controls[8];
			$_SESSION['schedule']['watch_start'][$schedulati]=$controls[9];
			$_SESSION['schedule']['watch_stop'][$schedulati]=$controls[10];
			$_SESSION['schedule']['enable'][$x+1]=$controls[11];
			$_SESSION['schedule']['date_time_started'][$schedulati]=0;
			$_SESSION['schedule']['last'][$schedulati]='00:00:00<br>00:00';
			$_SESSION['schedule']['elapsed'][$schedulati]='00:00';
			
			$info_item=
			$_SESSION['schedule']['name'][$schedulati]."#".
			$_SESSION['schedule']['command_pin'][$schedulati]."#".
			$_SESSION['schedule']['date_start'][$schedulati]."#".
			$_SESSION['schedule']['date_end'][$schedulati]."#".
			$_SESSION['schedule']['time_start'][$schedulati]."#".
			$_SESSION['schedule']['action_start'][$schedulati]."#".
			$_SESSION['schedule']['time_end'][$schedulati]."#".
			$_SESSION['schedule']['action_end'][$schedulati]."#".
			$_SESSION['schedule']['days'][$schedulati]."#".
			$_SESSION['schedule']['watch_start'][$schedulati]."#".
			$_SESSION['schedule']['watch_stop'][$schedulati]."#".
			$_SESSION['schedule']['enable'][$schedulati];
			
			
			
			$human='<b>Pin di Arduino:</b> '.$controls[1].'<br>'.
			'<b>Data Validita":</b> '.$controls[2].' - '.$controls[3].'<br>'.
			'<b>Orari</b>&nbsp;&nbsp;&nbsp;Start: '.$controls[4].'&nbsp;&nbsp;&nbsp;Stop: '.$controls[6].'<br>'.
			'<b>Valori Azioni</b>&nbsp;&nbsp;&nbsp;Start: ';
			
			if ($controls[5] > 1)  
			$human.=$controls[5];
			else
			$human.=($controls[5] == 0) ? 'LOW' : 'HIGH';
			
			$human.='&nbsp;&nbsp;&nbsp;Stop: ';
			
			if ($controls[7] > 1)  
			$human.=$controls[7];
			else
			$human.=($controls[7] == 0) ? 'LOW' : 'HIGH';
			
			$human.='<br>
			<b>Giorni di Attivazione:</b> ';
			$giorni=explode('@',$controls[8]);
			if (count($giorni)-1 > 0)
			{
				for ($x=0; $x < count($giorni)-1; $x++)
				$human.= $_SESSION["giorni_name"][$giorni[$x]].' ';
			}
			else
			$human.=($controls[8] == 7) ? 'Tutti' : 'Nessuno';
			
			$human.='<br>
			<b>Watch di Controllo</b>&nbsp;&nbsp;&nbsp;Start: '.$controls[9].'&nbsp;&nbsp;&nbsp;Stop: '.$controls[10];
			#'STATO CORRENTE<br>'.
			#'Running :'.$_SESSION["schedule"]["flag_action"][$schedulati].'  dalle ore :'.$_SESSION["schedule"]["date_time_started"][$schedulati].'<br>'.
			#'Ultimo passaggio :'.$_SESSION["schedule"]["last"][$schedulati].'  Tempo trascordo dall"avvio :'.$_SESSION["schedule"]["elapsed"][$schedulati];
			
			
			## il flag action e' necessaro allo scheduler per capire
			## se e' intervenuto un disable in fase di running
			## lo aggiornera' lui dopo il check
			# $_SESSION['schedule']['flag_action'][$schedulati]='';
			break;
		}
		echo ($schedulati < 20) ? "Schedule Salvato"."@@".$human."@@".$info_item : "Raggiunto limite schedule (20)!";
		break;
	}			