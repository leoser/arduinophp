<?php
	session_start();
	include("dati/status_services.php");
	include("dati/data_for_external_session.php");
	include("dati/data_for_external_domo.php");
	
	function last_elapsed_pin_in_schedule($last_elapsed,$pos)
	{
		include("dati/data_for_external_domo.php");
		return ($last_elapsed=='l') ? $_SESSION['schedule']['last'][$pos]: $_SESSION['schedule']['elapsed'][$pos];
	}
	
	function check_pin_in_schedule($item)
	{
		// aggiorniamo dal file remoto data_for_external_schedule.txt
		include("dati/data_for_external_domo.php");
		
		$ret_string="
		<b>*".$_SESSION['schedule']['name'][$item]."</b><br>".
		"<b>Pin di Arduino:</b> ".$_SESSION['schedule']['command_pin'][$item]."&nbsp;&nbsp;&nbsp;".
		"<b>Data Validita':</b> ".$_SESSION['schedule']['date_start'][$item]." - ".$_SESSION['schedule']['date_end'][$item]."<br>".
		"<b>Orari</b>&nbsp;&nbsp;&nbsp;Start: ".$_SESSION['schedule']['time_start'][$item]."&nbsp;&nbsp;&nbsp;Stop: ".$_SESSION['schedule']['time_end'][$item]."&nbsp;&nbsp;&nbsp;".
		"<b>Valori Azioni</b>&nbsp;&nbsp;&nbsp;Start: ";
		
		if ($_SESSION['schedule']['action_start'][$item] > 1)  
		$ret_string.=$_SESSION['schedule']['action_start'][$item];
		else
		$ret_string.=($_SESSION['schedule']['action_start'][$item] == 0) ? "LOW" : "HIGH";
		
		$ret_string.="&nbsp;&nbsp;&nbsp;Stop: ";
		
		if ($_SESSION['schedule']['action_end'][$item] > 1)  
		$ret_string.=$_SESSION['schedule']['action_end'][$item];
		else
		$ret_string.=($_SESSION['schedule']['action_end'][$item] == 0) ? "LOW" : "HIGH";
		
		$ret_string.="<br>
		<b>Giorni di Attivazione:</b> ";
		$giorni=explode("@",$_SESSION['schedule']['days'][$item]);
		if (count($giorni)-1 > 0)
		{
			for ($x=0; $x < count($giorni)-1; $x++)
			$ret_string.= $_SESSION['giorni_name'][$giorni[$x]]." ";
		}
		else
		$ret_string.=($_SESSION['schedule']['days'][$item] == 7) ? "Tutti" : "Nessuno";
		
		$ret_string.="&nbsp;&nbsp;&nbsp;
		<b>Watch di Controllo</b>&nbsp;&nbsp;&nbsp;Start: ".$_SESSION['schedule']['watch_start'][$item]."&nbsp;&nbsp;&nbsp;Stop: ".$_SESSION['schedule']['watch_stop'][$item];
		#"STATO CORRENTE<br>".
		#"Running :".$_SESSION['schedule']['flag_action'][$item]."  dalle ore :".$_SESSION['schedule']['date_time_started'][$item]."<br>".
		#"Ultimo passaggio :".$_SESSION['schedule']['last'][$item]."  Tempo trascordo dall'avvio :".$_SESSION['schedule']['elapsed'][$item];
		return $ret_string;
	}
?>
<html>
	<head>
		<title>CONTROLLO ARDUINO - ESTENSIONE PHP - STATUS DOMOTICA 60 SEC.</title>
		<?php if ($_SESSION['schedule_running']!=false)
			echo '<meta http-equiv="refresh" content="'.$_SESSION['refresh_domo_e'].'" />';
		?>
		<style>
			#containment-wrapper { width: 99%; z-index:0;}
			.label {
			display: inline-block;
			width: 5em;
			}
		</style>
	</head>
	<body>
		<div id="main">
		</div>
		<div id="containment-wrapper">
			<table cellpadding="0" cellspacing="3" width="99%">
				<tr>
					<td valign="top">
						<?php
							echo "Stato Schedule : ";
							echo ($_SESSION['schedule_running']) ? "Running<br>" : "Not Running.<font color='red'>Nothing to watch here!</font><br>";
						?>
					</td>
					<td align="center">
						<input type="button" value="Close" onclick="window.close();"><input type="button" value="Reload" onclick="window.location.reload();">
					</td>
				</tr>
			</table>
			<table cellpadding="0" cellspacing="3" width="99%">
					<?php
						if ($_SESSION['schedule_running'])
						{
							for ($z=0;$z<21;$z++)
							{
								if ($_SESSION['schedule']['name'][$z]!='')
								{
									if (fmod($z,2)==0)
									echo '<tr bgcolor="#f2f2f2">';
									else
									echo '<tr bgcolor="#d2d2d2">';
									
									$value_sched=check_pin_in_schedule($z);
									echo '
									<td>'.$value_sched.'</td>
									<td>'.last_elapsed_pin_in_schedule("e",$z).'</td>
									<td>'.last_elapsed_pin_in_schedule("l",$z).'</td>
									<td>
									<span style="font-size:12px;">';
									echo ($_SESSION['schedule']['flag_action'][$z] == 1) ? 
									'<img id="light_d'.$z.'" src="img/lightbulb_on.png">' :  
									'<img id="light_d'.$z.'" src="img/lightbulb_off.png">';
									echo '
									</span>
									</td>';
								}
								echo "</tr>";
							}
						}
						else
						echo "Lo SCHEDULE e' fermo.Nessun dato!";
					?>	
				</table>
			</div>
		</body>
	</html>																