<?php
	session_start();	
	include("/lang/lang_".$_SESSION['lang'].".php");
	
	$string_watch=explode(";",$_POST['watch']);
	// PRIMO SPLIT 
	// STRINGA  if#a#3#>#50#d#0#1#1#1#0#;15;Controllo 112&pos=1&mode=u
	//$string_watch[0]=if#a#3#>#50#d#0#1#1#1#0# (command)
	//$string_watch[1]= elapse
	//$string_watch[2]= name
	
	switch ($_POST['mode'])
	{
		case '0':
		$_SESSION['watch_running']=true;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"watch_running']=false")>-1)
		{
			$content=str_ireplace("['watch_running']=false","['watch_running']=true",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		break;

		case 's':
		$reset_pins='';
		include_once("include_send.php");
		$_SESSION['watch_running']=false;
		$content=file_get_contents($_SESSION['status_services']);
		if (strpos($content,"watch_running']=true")>-1)
		{
			$content=str_ireplace("['watch_running']=true","['watch_running']=false",$content);
			file_put_contents($_SESSION['status_services'], $content);
		}
		for ($x=0;$x<11;$x++)
		{
			if ($_SESSION['survey']['flag_action'][$x] >0)
			{	
				$tipo_pin=($_SESSION['survey']['action_d_a'][$x]=='p') ? "d" : $_SESSION['survey']['action_d_a'][$x]; 
				$opt= $tipo_pin. 
				$_SESSION['survey']['action_pin'][$x]."#".
				$_SESSION['survey']['re_action_set_pin'][$x].
				$_SESSION['survey']['re_action_value'][$x];
				send_value($opt);
				$reset_pins.=$_SESSION['survey']['control_d_a'][$x].$_SESSION['survey']['control_pin'][$x].";".
				$_SESSION['survey']['action_d_a'][$x].$_SESSION['survey']['action_pin'][$x].";";
				$_SESSION['survey']['flag_action'][$x]=0;
			}
		}
		echo $reset_pins;
		break;
		
		case 'd':
		for ($x=$_POST['pos']-1;$x<11;$x++)
		{
			$_SESSION['survey']['name'][$x]=$_SESSION['survey']['name'][$x+1];
			$_SESSION['survey']['command'][$x]=$_SESSION['survey']['command'][$x+1];
			$_SESSION['survey']['control_d_a'][$x]=$_SESSION['survey']['control_d_a'][$x+1];
			$_SESSION['survey']['control_pin'][$x]=$_SESSION['survey']['control_pin'][$x+1];
			$_SESSION['survey']['control_operator'][$x]=$_SESSION['survey']['control_operator'][$x+1];
			$_SESSION['survey']['control_value'][$x]=$_SESSION['survey']['control_value'][$x+1];
			$_SESSION['survey']['action_d_a'][$x]=$_SESSION['survey']['action_d_a'][$x+1];
			$_SESSION['survey']['action_pin'][$x]=$_SESSION['survey']['action_pin'][$x+1];
			$_SESSION['survey']['action_set_pin'][$x]=$_SESSION['survey']['action_set_pin'][$x+1];
			$_SESSION['survey']['action_value'][$x]=$_SESSION['survey']['action_value'][$x+1];
			$_SESSION['survey']['re_action_set_pin'][$x]=$_SESSION['survey']['re_action_set_pin'][$x+1];
			$_SESSION['survey']['re_action_value'][$x]=$_SESSION['survey']['re_action_value'][$x+1];
			$_SESSION['survey']['human'][$x]=$_SESSION['survey']['human'][$x+1];
			$_SESSION['survey']['elapse'][$x]=$_SESSION['survey']['elapse'][x+1];
		}
		$_SESSION['survey']['name'][10]="";
		$_SESSION['survey']['command'][10]="";
		$_SESSION['survey']['control_d_a'][10]="";
		$_SESSION['survey']['control_pin'][10]="";
		$_SESSION['survey']['control_operator'][10]="";
		$_SESSION['survey']['control_value'][10]=0;
		$_SESSION['survey']['action_d_a'][10]="";
		$_SESSION['survey']['action_pin'][10]="";
		$_SESSION['survey']['action_set_pin'][10]="";
		$_SESSION['survey']['action_value'][10]="";
		$_SESSION['survey']['re_action_set_pin'][10]="";
		$_SESSION['survey']['re_action_value'][10]="";
		$_SESSION['survey']['human'][10]="";
		$_SESSION['survey']['elapse'][10]=0;
		
		echo "deleted ".$_POST['pos'];
		break;
		
		default:
		if ($_POST['mode']=="u")
		{
			$start=$_POST['pos']-1;
			$end=$_POST['pos'];
		}
		else
		{
			$start=0;
			$end=10;
		}	
		
		
		for ($controlli=$start; $controlli < $end; $controlli++)
		{
			if (($_SESSION['survey']['command'][$controlli] != '') && ($_POST['mode']!="u"))
			{
				continue;
			}
			
			#        1  2   3  4   5   6  7  8  9  10  11
			#    if#a# 0#>#20#d#11#1#1#1#0#;20
				$_SESSION['survey']['command'][$controlli]=$string_watch[0];
				$_SESSION['survey']['elapse'][$controlli]=(int)$string_watch[1];
				$_SESSION['survey']['name'][$controlli]=$string_watch[2];
				
				$controls=explode("#",$string_watch[0]);
				// SECONDO SPLIT 
				// $string_CONTROL[0]= if
				// $string_CONTROL[1]= a
				// $string_CONTROL[2]= 0
				// $string_CONTROL[3]= >
				// $string_CONTROL[4]= 50
				// $string_CONTROL[5]= d
				// $string_CONTROL[6]= 12
				// $string_CONTROL[7]=1
				// $string_CONTROL[8]=v20
				// $string_CONTROL[9]=1
				// $string_CONTROL[10]=v0
				
				$_SESSION['survey']['control_d_a'][$controlli]=$controls[1];
				$_SESSION['survey']['control_pin'][$controlli]=trim($controls[2]);
				$_SESSION['survey']['control_operator'][$controlli]=$controls[3];
				$_SESSION['survey']['control_value'][$controlli]=$controls[4];
				$_SESSION['survey']['action_d_a'][$controlli]=$controls[5];
				$_SESSION['survey']['action_pin'][$controlli]=trim($controls[6]);
				$_SESSION['survey']['action_set_pin'][$controlli]=$controls[7];
				$_SESSION['survey']['action_value'][$controlli]=$controls[8];
				$_SESSION['survey']['re_action_set_pin'][$controlli]=$controls[9];
				$_SESSION['survey']['re_action_value'][$controlli]=$controls[10];

				
				$human='';
				$human .= ($_SESSION['survey']['control_d_a'][$controlli] =='a') ? "Analog " : "Digital ";
				$human .= 	$_SESSION['survey']['control_pin'][$controlli]." ".
				$_SESSION['survey']['control_operator'][$controlli]." ".
				$_SESSION['survey']['control_value'][$controlli];
				
				$human .=" >> ";
				$human .= ($_SESSION['survey']['action_d_a'][$controlli]=='a') ? "Analog " : ($_SESSION['survey']['action_d_a'][$controlli]=='d') ? "Digital ":"Pwm ";
				$human .= $_SESSION['survey']['action_pin'][$controlli];
				
				if ($controls[9] > 1)
				$human .= ' '.$controls[9];
				else
				$human .= ($controls[9]=='1') ? ' HIGH' :' LOW';
				
				$human.=' else ';
				#   1  2  3  4  5  6  7   8 9 10  11
				#   d#9#>#0#d#12#1#0#1#1#;10
				
				if ($controls[11]> 1)
				$human .= " ".$controls[10];
				else
				$human .= ($controls[11]=='1') ? ' HIGH' :' LOW';
				
				$_SESSION['survey']['human'][$controlli]= $human;
				break;
			}
			echo ($controlli < 10) ? $_SESSION['lang_watch_saved'].";".$human : $_SESSION['lang_limits_of_watch']." (10)!";
			break;
		}		